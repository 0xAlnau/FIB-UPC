TARGET     = $$qtLibraryTarget(bloom1)
include(../common.pro)
