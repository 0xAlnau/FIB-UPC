#!/bin/bash

# el mateix amb els .java de CLASSES, agafa les llibreries de Junit4 i els .class dels .java del domini
javac -cp "../LIBS/*:../CLASSES" -d ../CLASSES Drivers/*/*.java
