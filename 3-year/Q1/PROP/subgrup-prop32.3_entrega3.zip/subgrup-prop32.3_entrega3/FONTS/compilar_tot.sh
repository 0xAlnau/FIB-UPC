#!/bin/bash

# elimina carpeta anterior i crea una nova per guardar els .class (amb els seus packages)
rm -rf ../CLASSES
mkdir ../CLASSES

# amb -d guardem els .class generats a la carpeta CLASSES, i crea carpeta FONTS pel package FONTS
javac -d ../CLASSES */*.java

# el mateix amb els .java de CLASSES, agafa les llibreries de Junit4 i els .class dels .java del domini
javac -cp "../LIBS/*:../CLASSES/" -d ../CLASSES Drivers/*/*.java
