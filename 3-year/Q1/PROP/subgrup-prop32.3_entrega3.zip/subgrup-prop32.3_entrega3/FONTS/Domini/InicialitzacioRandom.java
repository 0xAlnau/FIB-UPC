package FONTS.Domini;

/**
 * @class InicialitzacioRandom
 * @brief Inicialització aleatòria d’un procés de clustering.
 *
 * @details Aquesta classe especialitza {@link AnalisiCluster} i s’encarrega
 *          únicament de realitzar una inicialització aleatòria dels centroides
 *          (o medoids) i una primera assignació de les respostes als clusters.
 *
 *          No executa el procés iteratiu complet de clustering, sinó que
 *          proporciona un estat inicial vàlid per a anàlisis posteriors
 *          o per a comparacions entre mètodes d’inicialització.
 */
public class InicialitzacioRandom extends AnalisiCluster {

    /**
     * @brief Constructor que executa una inicialització aleatòria del clustering.
     *
     * @param r Matriu de respostes de l'enquesta.
     * @param l Nombre de clusters (k).
     * @param nR Nombre total de respostes.
     * @param nP Nombre total de preguntes.
     *
     * @details El procés consta de les fases següents:
     *          1. Inicialització aleatòria dels centroides o medoids.
     *          2. Assignació inicial de totes les respostes al cluster més proper.
     *
     *          Aquesta classe s’utilitza principalment com a punt de partida
     *          per altres algorismes o per analitzar l’efecte de la inicialització.
     *          Es pot usar com a clustering, però dona molts mals resultats.
     *
     * @throws InvalidClusterException Si es produeix algun error durant la inicialització.
     * @throws InvalidRespostaException Si alguna resposta és invàlida.
     */
    public InicialitzacioRandom(RespostaInd[][] r, int l, int nR, int nP) throws InvalidClusterException, InvalidRespostaException {
        super(r,l,nR,nP);
        initializeRandom(); 
        assignar(); 
    }
}
