 /*
    +----------------------------------------------------------+
    |                AnalisiCluster.java                       |
    +----------------------------------------------------------+
    | Repositori:                                              |
    |   ·subgrup-prop32.3                                      |
    +----------------------------------------------------------+
    | Aquest mòdul ha sigut programat per:                     |
    |   · Angel Dominguez Buira                                |
    +----------------------------------------------------------+
    | Versió 1.0 : Funcionalitats bàsiques implementades       |
    | Versió 2.0 : Implementats tots els diferents mètodes     |
    |              de clustering                               |
    +----------------------------------------------------------+
  */

/** @file AnalisiCluster.java
    @brief Implementació d'una classe per realitzar l'anàlisi de respostes a enquestes mitjançant un algoritme de clustering (k-means).
*/

package FONTS.Domini;

import java.util.*;   //per a dividir strings
/** @class AnalisiCluster
   @brief Aquesta classe implementa un mètode de clustering (k-means) per agrupar respostes d'una enquesta en diversos grups (clusters).

   La classe gestiona les operacions associades a les respostes de l'enquesta, com la creació de centroides, l'assignació de respostes als clusters i la recalculació dels centroides.

   La classe utilitza un mètode de k-means++ per a la inicialització dels centroides i realitza un iteració contínua per a millorar la qualitat dels clusters.

   Les operacions inclouen:
   - Inicialització aleatòria dels centroides.
   - Assignació de respostes a clusters basant-se en la distància als centroides.
   - Actualització dels centroides com a mitjanes de les respostes assignades.
   - Algoritme de convergència per trobar els clusters òptims.
*/
public class AnalisiCluster {

    /** @brief Matriu de respostes, on cada fila representa una resposta i cada columna una pregunta de l'enquesta.
    * @details Aquesta matriu emmagatzema les respostes a les diferents preguntes de l'enquesta.
    */
    protected RespostaInd[][] respostes;

    /** @brief Matriu dels centroides, on cada fila representa un centroide i cada columna una pregunta
    * @details Aquesta matriu emmagatzema els centroides calculats durant el procés de clustering.
    */
    protected RespostaInd[][] centroides;

    /** @brief Atribut per assignar cada resposta a un grup del cluster.
    * @details Aquesta matriu manté la informació sobre quin cluster és assignada cada resposta.
    */
    protected Integer[] assignacions;

    /** @brief Nombre de centroides del cluster (k).
    *    @details Aquest valor és fix i indica el nombre de grups (clusters) que es volen obtenir. En aquest cas, k = 3.
    */
    protected int k;

    /** @brief Nombre de preguntes de l'enquesta a la qual es fa el cluster.
        @details Representa el nombre de preguntes que apareixen en l'enquesta, és a dir, el nombre de columnes de la matriu de respostes.
     */
    protected int nPreg;

    /** @brief Nombre de respostes totals de l'enquesta a la qual es fa el cluster.
        @details Representa el nombre de respostes (filas) que s'han obtingut per a l'enquesta.
     */
    protected int nResp;

    /** 
     * @brief Vector amb la distància màxima possible per a cada pregunta amb resposta numèrica.
     *
     * @details Aquest vector s’utilitza per normalitzar les distàncies de les 
     *          respostes numèriques durant el càlcul de k-means. Per a cada 
     *          pregunta numèrica, distMaxs[i] = valorMàxim - valorMínim.
     */
    protected float[] distMaxs;

    /** 
     * @brief Llavor utilitzada pel generador de nombres aleatoris.
     * @details Permet obtenir resultats reproduïbles en la inicialització
     *          aleatòria dels centroides.
     */
    protected long seed = 1235;

    /**
     * @brief Retorna el vector d'assignacions de cada resposta al seu cluster.
     *
     * @details Cada posició del vector conté l'índex del cluster (de 0 a k-1)
     * al qual ha estat assignada la resposta corresponent. El vector té
     * longitud igual al nombre total de respostes de l'enquesta.
     *
     * @return Un vector d'enters on cada element indica el cluster assignat a la resposta associada.
     */
    public Integer[] getAssignacions() {
        return assignacions;
    }

    /**
     * @brief Retorna la matriu de centroides calculada pel procés de clustering.
     *
     * @details La matriu és de dimensions k × nPreg, on k és el nombre de
     * clusters i nPreg el nombre de preguntes. Cada fila representa un
     * centroide i cada columna una resposta tipus RespostaInd que correspon
     * a la posició d'aquella pregunta dins el centroide.
     *
     * @return Una matriu de RespostaInd amb els centroides finals del clustering.
     */
    public RespostaInd[][] getCentroides() {
        return centroides;
    }

    /** 
     * @brief Funció per calcular la distància entre dues respostes (un centroide i una resposta).
     * @param c Una llista de respostes que representa un centroide.
     * @param r Una llista de respostes que representa una resposta de l'enquesta.
     * @return La distància entre el centreide i la resposta, normalitzada per al nombre de preguntes.
     * @throws InvalidClusterException Si hi ha errors en el càlcul de distància.
     */
    protected float distancia(RespostaInd[] c, RespostaInd[] r) throws InvalidClusterException, InvalidRespostaException {
        try {
            //distància euclideana
            float distTotal = 0;
            for (int i = 0; i < nPreg; ++i) {
                float d = r[i].calcularDistancia(c[i]);
                if (r[i] instanceof RespostaNum && distMaxs[i] != 0) d = d / distMaxs[i];
                distTotal += Math.pow(d, 2);
            }
            return (float)((Math.sqrt(distTotal)) / nPreg);
        } catch (Exception e) {
            throw new InvalidClusterException("Error inesperat en el càlcul de distància: " + e.getMessage(), e);
        }
    }

    /** @brief Funció per actualitzar els centroides en base a les respostes assignades a cada grup.
        @details Aquesta funció utilitza el mètode k-medoid per actualitzar els centroides com la resposta més propera a totes les respostes de cada centroide.
     */
    protected boolean updateCentroidsKmedoids() throws InvalidClusterException, InvalidRespostaException {
        
        boolean canvis = false;
        //divideixo les respostes per clusters
        List<List<RespostaInd[]>> clusters = new ArrayList<>();
        for (int i = 0; i < k; i++) {
            clusters.add(new ArrayList<>());
        }
        for (int i = 0; i < nResp; i++) {
            int clusterId = assignacions[i];
            clusters.get(clusterId).add(respostes[i]);
        }

        for (int i = 0; i < k; ++i) {
            float dMin = 0;
            List<RespostaInd[]> llista = clusters.get(i);
            for (RespostaInd[] comparat:llista) {
                dMin += distancia(centroides[i], comparat);
            }
            for (RespostaInd[] seleccionat:llista) {
                float d = 0;
                for (RespostaInd[] comparat:llista) {
                    d += distancia(seleccionat, comparat);
                }
                if (d < dMin) {
                    dMin = d;
                    canvis = true;
                    centroides[i] = seleccionat;
                }
            }
        }
        return canvis;
    }

    /** @brief Funció per actualitzar els centroides en base a les respostes assignades a cada grup.
        @details Aquesta funció utilitza el mètode k-means per actualitzar els centroides com la mitjana de les respostes assignades a cada cluster.
     */
    protected void updateCentroidsKmeans() throws InvalidClusterException, InvalidRespostaException {
        int t = 0;
        for (int i = 0; i < nPreg; ++i) {
            RespostaInd r1 = respostes[t][i].clone();

            if (r1 instanceof RespostaNum) {

                //sumatori total de les respostes de cada centroide
                float[] results = new float[k];

                //numero total de les respostes de cada centroide
                int[] numSumants = new int[k];

                for (int j = 0; j < nResp; ++j) {
                    RespostaNum rn = (RespostaNum) respostes[j][i];
                    float n = rn.getValor();
                    results[assignacions[j]] += n;
                    numSumants[assignacions[j]] += 1;    
                }

                //mitjana numerica de totes les respostes a la pregunta i per a cada centroide
                for (int l = 0; l < k; ++l) {
                    float res = 0;
                    if (numSumants[l] > 0) res = (results[l]/numSumants[l]);
                    RespostaNum r2 = (RespostaNum) r1.clone();
                    r2.setValor(res);
                    centroides[l][i] = r2;
                }

            } else if (r1 instanceof RespostaText) {

                //Inicialitzo array de map, cada element de l'array marca la freqüencia de strings de cada cluster
                ArrayList<HashMap<String, Integer>> llista = new ArrayList<>();
                for (int l = 0; l < k; l++) {
                    llista.add(new HashMap<>());
                }

                for (int j = 0; j < nResp; ++j) {
                    int a = assignacions[j];
                    Map<String, Integer> frequencyMap = llista.get(a);
                    RespostaText rn = (RespostaText) respostes[j][i];
                    String n = rn.getValor();
                    //convertim a minúscules i treiem signes de puntuació, possible implementacio de ometre signes extranys
                    String cleaned = n.toLowerCase();
                    String[] words = cleaned.split("\\s+");


                    for (String word : words) {
                        if (!word.isBlank()) {
                            Integer f = frequencyMap.get(word);
                            if (f == null) { // no estava l'string enregistrat
                                frequencyMap.put(word, 1);
                            }
                            else {
                                frequencyMap.put(word, f+1);
                            }
                        }
                    }
                }

                // Busquem la paraula més freqüent de cada cluster
                for (int l = 0; l < k; l++) {
                    HashMap<String, Integer> frequencyMap = llista.get(l);
                    String res = null;
                    int freq = Integer.MIN_VALUE;

                    for (Map.Entry<String, Integer> e : frequencyMap.entrySet()) {
                        if (e.getValue() > freq) {
                            freq = e.getValue();
                            res = e.getKey();
                        }
                    }
                    RespostaText r2 = (RespostaText) r1.clone();
                    centroides[l][i] = new RespostaText(r2.getPreguntaAssociada(), "null", res);
                }
            } else if (r1 instanceof RespostaMultichoice) {
                ArrayList<HashMap<Integer, Integer>> llista = new ArrayList<>();
                for (int l = 0; l < k; l++) {
                    llista.add(new HashMap<>());
                }

                for (int j = 0; j < nResp; ++j) {
                    RespostaMultichoice r = (RespostaMultichoice) respostes[j][i];
                    Set<Integer> resp = r.getValor();
                    HashMap<Integer, Integer> contador = llista.get(assignacions[j]);

                    for (Integer num : resp) {
                        contador.put(num, contador.getOrDefault(num, 0) + 1);
                    }
                }

                // Trobar freqüencia maxima de cada cluster
                for (int l = 0; l < k; l++) {  
                    Map<Integer, Integer> contador = llista.get(l);

                    int maxFreq = 0;
                    for (int freq : contador.values()) {
                        if (freq > maxFreq) maxFreq = freq;
                    }

                    // Retornar resultats
                    Set<Integer> res = new HashSet<>();
                    for (Map.Entry<Integer, Integer> e : contador.entrySet()) {
                        if (e.getValue() == maxFreq) {
                            res.add(e.getKey());
                        }
                    }
                    RespostaMultichoice r2 = (RespostaMultichoice) r1.clone();
                    centroides[l][i] = new RespostaMultichoice((PreguntaMultichoice)r2.getPreguntaAssociada(), "null", res);
                }
            }
        }
    }

    /**
     * @brief Calcula la distància màxima possible per a cada pregunta numèrica.
     *
     * @details Recorre totes les respostes i determina el rang (max - min)
     *          per cada pregunta numèrica. Aquest valor serveix per 
     *          normalitzar les distàncies, de manera que cap pregunta
     *          numèrica domini el càlcul del clustering, els altres tipus 
     *          de resposta ja queden normalitzats al calcular la distància.
     *
     * @throws InvalidClusterException Si es produeix algun error inesperat.
     * @throws InvalidRespostaException Si alguna resposta és invàlida.
     */
    protected void initializeDistMax() throws InvalidClusterException, InvalidRespostaException {
        distMaxs = new float[nPreg];
        int t = 0;
        for(int i = 0; i < nPreg; ++i) {
            //els altres tipus de respostes ja venen normalitzades
            
            if (respostes[t][i] instanceof RespostaNum) {
                float max = 0;
                float min = 0;
                for (int j = 0; j < nResp; ++j) {
                    //if (!nullList[j]) {
                    RespostaNum rn = (RespostaNum) respostes[j][i];
                    float r = rn.getValor();
                    if (j == 0) {max = r; min = max;}
                    else if (max < r) max = r;
                    else if (min > r) min = r;
                }
                distMaxs[i] = max - min;
            }
            
        }
    }

    /**
     * @brief Inicialitza els centroides de manera aleatòria.
     *
     * @details Selecciona k respostes diferents de forma aleatòria
     *          i les utilitza com a centroides inicials.
     */
    protected void initializeRandom() throws InvalidClusterException, InvalidRespostaException {
        centroides = new RespostaInd[k][nPreg];
        Random rand = new Random(seed);

        Integer n;
        ArrayList<Integer> c = new ArrayList<>();
        for (Integer i = 0; i < nResp; ++i) {
            c.add(i);
        }
        for (int i = 0; i < k && c.size() > 0; ++i) {
            int r = rand.nextInt(c.size());   
            n = c.get(r);
            c.remove(r);
            for (int j = 0; j < nPreg; j++) {
                centroides[i][j] = respostes[n][j].clone();
            }
        }
    }

    /** @brief Funció que executa la inicialització k-means++ per establir els centroides inicials.
        @details Aquesta funció inicialitza els centroides seleccionant aleatòriament el primer i els següents es col·loquen per maximitzar la distància entre ells.
     */
    protected void initializeKmeans() throws InvalidClusterException, InvalidRespostaException {
        centroides = new RespostaInd[k][nPreg];
        Random rand = new Random(seed);

        //inicialització random primer centroid
        int n;
        n = rand.nextInt(nResp);
        for (int i = 0; i < nPreg; i++) {
            centroides[0][i] = respostes[n][i].clone();
        }

        float[] distancies = new float[nResp];

        // Distancia minima al centroide més proper
        for (int i = 1; i < k; i++) {
            for (int j = 0; j < nResp; j++) {
                float minDist = 0;
                for (int c = 0; c < i; ++c) {
                    float d = distancia(centroides[c],respostes[j]);
                    if (c == 0 || d < minDist) minDist = d;
                }
                distancies[j] = minDist * minDist;
            }

            // Distribució acumulada
            float sum = 0;
            for (float d2 : distancies) sum += d2;

            float r = rand.nextFloat() * sum;

            // Escollir seguent centroide amb la probabilitat acumulada
            float acumulada = 0;
            for (int s = 0; s < nResp; s++) {
                acumulada += distancies[s];
                if (acumulada >= r) {
                    for (int t = 0; t < nPreg; t++) {
                        centroides[i][t] = respostes[s][t].clone();
                    }
                    break;
                }
            }
        }
    }

    /**
     * @brief Constructor principal de la classe AnalisiCluster.
     *
     * @param r Matriu de respostes de l’enquesta.
     * @param l Nombre de clusters (k) a generar.
     * @param nulL Vector que indica quines respostes són nul·les.
     * @param nR Nombre total de respostes.
     * @param nP Nombre total de preguntes.
     *
     * @details Inicialitza les estructures internes, executa k-means++ per 
     *          inicialitzar centroides, i després aplica l’algoritme k-means 
     *          fins a la convergència.
     *
     * @throws InvalidClusterException Si hi ha problemes durant el càlcul.
     * @throws InvalidRespostaException Si hi ha respostes mal formades.
     */
    public AnalisiCluster(RespostaInd[][] r, int l, int nR, int nP) throws InvalidClusterException, InvalidRespostaException {
        k = l;
        respostes = r; 
        nPreg = nP;
        nResp = nR;
        //nullList = nulL;
        initializeDistMax();

        assignacions = new Integer[nResp];
        for (int i = 0; i < nResp; i++) {
            /*if (!nullList[i])*/ assignacions[i] = 0;
        }
    }

    /**
     * @brief Assigna cada resposta al cluster més proper.
     *
     * @details Calcula la distància entre cada resposta i tots els centroides,
     *          assignant-la al cluster amb menor distància.
     *
     * @return Cert si alguna assignació ha canviat; fals en cas contrari.
     */
    protected boolean assignar() throws InvalidClusterException, InvalidRespostaException {
        boolean canvis = false;
        for (int i = 0; i < nResp; ++i) {
            float minDist = 0;
            Integer c = 0;
            for (Integer j = 0; j < k; ++j) {
                float dist = distancia(centroides[j],respostes[i]);
                if (j == 0 || minDist > dist) {
                    minDist = dist;
                    c = j;
                }
            }
            if(assignacions[i] != c) {
                assignacions[i] = c;
                canvis = true;
            }
        }
        return canvis;
    }


        /**
     * @brief Calcula el Coeficient de Silhouette global del clustering.
     *
     * @details Per cada resposta no nul·la:
     *   - a(i): distància mitjana entre la resposta i la resta del seu cluster (cohesió).
     *   - b(i): distància mitjana mínima entre la resposta i qualsevol altre cluster (separació).
     * 
     * El coeficient individual és:
     *     s(i) = (b(i) - a(i)) / max(a(i), b(i))
     *
     * S retorna la mitjana de tots els s(i).
     *
     * @return Valor global del coeficient de silhouette (entre -1 i 1).
     *
     * @throws InvalidClusterException Si hi ha algun error en càlculs de distància.
     * @throws InvalidRespostaException Si alguna resposta no pot calcular distància.
     */
    public float calculaSilhouette() throws InvalidClusterException, InvalidRespostaException {
        float sumaSilhouette = 0;
        int comptador = 0;

        for (int i = 0; i < nResp; i++) {

            int clusterActual = assignacions[i];

            float sumaDistMateixCluster = 0;
            int numCompanys = 0;

            for (int j = 0; j < nResp; j++) {
                if (j != i && assignacions[j] == clusterActual) {
                    sumaDistMateixCluster += distancia(respostes[i], respostes[j]);
                    numCompanys++;
                }
            }

            float a_i;
            if (numCompanys == 0) a_i = 0;   // Un únic element al cluster -> cohesió 0
            else a_i = sumaDistMateixCluster / numCompanys;


            float millorSeparacio = Float.MAX_VALUE;

            for (int c = 0; c < k; c++) {
                if (c == clusterActual) continue;

                float sumaDistCluster = 0;
                int numElems = 0;

                for (int j = 0; j < nResp; j++) {
                    if (assignacions[j] == c) {
                        sumaDistCluster += distancia(respostes[i], respostes[j]);
                        numElems++;
                    }
                }

                if (numElems > 0) {
                    float separacioMitjana = sumaDistCluster / numElems;
                    if (separacioMitjana < millorSeparacio)
                        millorSeparacio = separacioMitjana;
                }
            }

            float b_i = millorSeparacio;

            float s_i;
            if (a_i == 0 && b_i == 0) s_i = 0;
            else s_i = (b_i - a_i) / Math.max(a_i, b_i);

            sumaSilhouette += s_i;
            comptador++;
        }

        if (comptador == 0) return 0;

        return sumaSilhouette / comptador;
    }


}

