/*
    +----------------------------------------------------------+
    |                    CtrlDominio.java                      |
    +----------------------------------------------------------+ 
    | Repositori:                                              |
    |   ·subgrup-prop32.3                                      |
    +----------------------------------------------------------+
    | Aquest mòdul ha sigut programat per:                     |
    |   ·Gabriel Alegre Conchello                              |
    |   ·Santiago Lluzar Frías                                 |
    |   ·Arnau Cullell Martínez                                |
    +----------------------------------------------------------+
    | *Versió 1.0: Funcionalitats bàsiques fetes.              |
    |                                                          |
    +----------------------------------------------------------+
  */

package FONTS.Domini;

import java.util.*;
import FONTS.Persistencia.CtrlPersistencia;

public class CtrlDominio {

    // --- ATRIBUTS ---
    private HashMap<String, Usuari> usuaris; 
    private HashMap<String, Enquesta> titol2Enquesta;
    
    private CtrlPersistencia CPers;

    // --- CONSTRUCTORA ---
    public CtrlDominio() {
        usuaris = new HashMap<String, Usuari>();
        titol2Enquesta = new HashMap<String, Enquesta>();
        CPers = new CtrlPersistencia();
    }

    // =========================================================================
    //   NOUS MÈTODES GETTERS PER A LA GUI (VISTAS)
    // =========================================================================

    /** @brief Retorna un Set amb els títols de totes les enquestes (per als ComboBox). */
    public Set<String> getLlistaTitolEnquestes() {
        if (titol2Enquesta == null) return new HashSet<>();
        return titol2Enquesta.keySet();
    }

    /** @brief Retorna els títols de les enquestes creades per un usuari concret. */
    public Set<String> getEnquestesDeUsuari(String name) {
        Usuari u = usuaris.get(name);
        if (u == null) return new HashSet<>();
        return u.getTitulosEnquesta(); 
    }

    /** @brief Retorna l'objecte Enquesta (necessari per a VistaContestar/Cluster). */
    public Enquesta getEnquesta(String titol) {
        return titol2Enquesta.get(titol);
    }

    /** @brief Retorna un usuari registrat. */
    public Usuari getUsuari(String name) {
        return usuaris.get(name);
    }

    // =========================================================================
    //   GESTIÓ D'USUARIS
    // =========================================================================

    /** @brief Retorna un boolean que indica si un nom ja està en ús. */
    public boolean nombreEnUso(String name) {
        if (usuaris == null) return false;
        return usuaris.containsKey(name);
    }

    /** @brief Crea a l'Usuari amb nom "name" */
    public void crearUsuari(String name, String password) {
        Usuari u = new Usuari(name, password);
        usuaris.put(name, u);
        // u.setPassword(password); // Ja es fa al constructor si cal
    }

    /** @brief Comprova si la password posada pel usuari és correcta*/
    public boolean comprovarPassword(String name, String password) {
        Usuari u = usuaris.get(name);
        if (u == null) return false;
        return u.checkPassword(password);
    }

    // =========================================================================
    //   GESTIÓ D'ENQUESTES (CREACIÓ I EDICIÓ)
    // =========================================================================

    /** @brief Retorna un boolean que indica si existeix l'enquesta "titol". */
    public boolean existeEnquesta(String titol) {
        return titol2Enquesta.containsKey(titol);
    }
    
    /** @brief Una altra forma de veure si existeix una enquesta.*/
    public boolean existeixEnquesta(String titol) {
        return existeEnquesta(titol);
    }
    
    /** @brief Retorna un boolean que indica si no existeix l'enquesta "titol".*/
    public boolean noExisteixEnquesta(String titol) {
        return !titol2Enquesta.containsKey(titol);
    }

    /** @brief Crea una enquesta buida. */
    public void crearEnquestaBuida(String titol, String name, int k) {
        Usuari u = usuaris.get(name);
        if (u != null) {
            Enquesta enq = new Enquesta(titol, u, k);
            u.crearEnquesta(titol, enq);
            titol2Enquesta.put(titol, enq);
        }
    }

    /** @brief Crea una enquesta normal amb valors estandards. */
    public void crearEnquesta(String titol) {
        // Per defecte assignem 'admin' o null si no especifiquem usuari, i K=3
        Enquesta enq = new Enquesta(titol, null, 3);
        titol2Enquesta.put(titol, enq);
    }
    /** @brief Mètode pont per afegir preguntes des de la GUI (VistaCrear).
     * Tradueix els Strings de la vista a objectes Pregunta. */
    public void afegirPregunta(String titolEnquesta, String enunciat, String tipus, int maxOpcions, String[] opcions) {
        Enquesta enq = titol2Enquesta.get(titolEnquesta);
        if (enq == null) return;

        try {
            if (tipus.equals("TEXT")) {
                // Pregunta lliure text (false = no numèrica)
                crearPreguntaLliure(titolEnquesta, enunciat, 0, false);
            } 
            else if (tipus.equals("NUM")) {
                // Pregunta lliure numèrica (true = numèrica)
                crearPreguntaLliure(titolEnquesta, enunciat, 0, true);
            } 
            else { 
                // Multichoice
                List<String> listaOps = new ArrayList<>();
                if (opcions != null) {
                    for(String s : opcions) {
                        if(!s.trim().isEmpty()) listaOps.add(s.trim());
                    }
                }
                crearPreguntaMultichoice(titolEnquesta, enunciat, listaOps, maxOpcions);
            }
        } catch (Exception e) {
            System.err.println("Error afegint pregunta: " + e.getMessage());
        }
    }

    /** @brief Crea una pregunta lliure. */
    public void crearPreguntaLliure(String titol, String resp, int n, boolean bNumerica) throws InvalidPreguntaException {
        PreguntaLliure preg = new PreguntaLliure(resp, 20, bNumerica);
        if (titol2Enquesta.get(titol) != null) {
            titol2Enquesta.get(titol).registrarPregunta(preg);     
        }
    }

    /** @brief Crea una pregutna multichoice. */
    public void crearPreguntaMultichoice(String titol, String resp, List<String> opcions, int max_opcions) {
        try {
            PreguntaMultichoice preg = new PreguntaMultichoice(resp, opcions, max_opcions);
            if (titol2Enquesta.get(titol) != null) {
                titol2Enquesta.get(titol).registrarPregunta(preg);
            }
        }
        catch (InvalidPreguntaException e) {
            System.err.println(e.getMessage());
        }
    }

    /** @brief Elimina una enquesta "name". */
    public void eliminarEnquesta(String name, String titol) 
    {
        Usuari u = usuaris.get(name);
        if (u != null) {
            u.eliminarEnquesta(titol);
        }
        titol2Enquesta.remove(titol);

        String path = "../FONTS/Persistencia/Enquestes/" + titol + ".csv";
        CPers.eliminarEnquesta(path);
        
        System.out.println("Enquesta '" + titol + "' eliminada correctament (memòria i disc).");
    }
    
    /** @brief Elimina una pregunta d'una enquesta "titol". */
    public void eliminarPreguntes(String titol, String preg) {
        if (titol2Enquesta.get(titol) != null)
            titol2Enquesta.get(titol).eliminarPregunta(preg);
    }

    /** @brief Retorna la llista de capçaleres per a la taula de resultats. */
    public ArrayList<String> getCapcalerasResultats(String titol) {
        Enquesta enq = titol2Enquesta.get(titol);
        if (enq == null) return new ArrayList<>();

        ArrayList<String> headers = new ArrayList<>();
        headers.add("Usuari"); 
        
        int n = enq.getNumPreguntes();
        Pregunta[] pregs = enq.getPreguntes();
        for(int i = 1; i <= n; i++) {
            if (pregs[i] != null) headers.add(pregs[i].getText());
            else headers.add("P" + i);
        }
        
        headers.add("Cluster"); 
        return headers;
    }

    /** @brief Retorna la matriu de dades de l'enquesta en format String. */
    public ArrayList<ArrayList<String>> getDadesResultats(String titol) {
         Enquesta enq = titol2Enquesta.get(titol);
         if (enq == null) return new ArrayList<>();
         return enq.getRespostesPrimitives();
    }
    
    // =========================================================================
    //   CLUSTERING I RESULTATS
    // =========================================================================

    /** @brief Generar cluster (Versió GUI: rep el Set directament). */
    public void generarCluster(String titol, Set<Integer> preguntes, int opc_k_means, int opc_tipus) {
        try {
            if (titol2Enquesta.get(titol) != null) {
                titol2Enquesta.get(titol).generarCluster(preguntes, opc_k_means, opc_tipus);
                System.out.println("Cluster generat correctament!");
            }
        } catch(InvalidClusterException e) {
            System.err.println(e.getMessage());
        }
    }

    /** @brief Retorna el prototipus com a String per a la GUI. */
    public String getPrototipus(String titol, String name) {
        Enquesta enq = titol2Enquesta.get(titol);
        
        if (enq != null) {
            String res = null;
            try {
                res = enq.getPrototipus(name);
            } catch (Exception e) {
                return "Error: No has contestat aquesta enquesta (o dades corruptes).";
            }
            if (res == null || res.equalsIgnoreCase("NULL")) {
                return "Error: Encara no s'ha calculat el teu prototip (fes el Clustering primer).";
            }
            
            if (res.equals("NO_RESPONSE")) {
                return "Error: No has contestat aquesta enquesta.";
            }
            if (res.equals("NO_PROTOTYPE")) {
                return "Error: No s'ha assignat cap prototip.";
            }
            return "Pertanys al grup: " + res;
        }
        return "Error: Enquesta no trobada.";
    }

    /** @brief Permet veure els resultats d'una enquesta. */
    public void veureResultatsEnquesta(String titol) {
        if (titol2Enquesta.get(titol) != null) {
            titol2Enquesta.get(titol).veureRespostes();
        }
    }

    /** @brief Permet imputar els nulls. */
    public void imputarNulls(String titol) {
        if (titol2Enquesta.get(titol) != null) {
            titol2Enquesta.get(titol).imputacioRespostes();
        }
    }

    /** @brief Assigna el valor K a una enquesta. */
    public void setValorK(String titol, int k) {
        Enquesta enq = titol2Enquesta.get(titol);
        if (enq != null) enq.setValorK(k);
    }

    /** @brief Retorna una llista amb els enunciats de les preguntes. */
    public ArrayList<String> getLlistaEnunciatsPreguntes(String titol) {
        Enquesta enq = titol2Enquesta.get(titol);
        ArrayList<String> llista = new ArrayList<>();
        if (enq == null) return llista;

        Pregunta[] pregs = enq.getPreguntes();
        int num = enq.getNumPreguntes();
        
        for (int i = 1; i <= num; i++) {
            if (pregs[i] != null) {
                llista.add(pregs[i].getText());
            }
        }
        return llista;
    }

    /** @brief Retorna el coeficient de Silhouette. */
    public float getSilhouette(String titol) {
        Enquesta enq = titol2Enquesta.get(titol);
        return (enq != null) ? enq.getSilhouette() : 0.0f;
    }

    // =========================================================================
    //   PERSISTÈNCIA (INTEGRACIÓ AMB CTRL PERSISTENCIA)
    // =========================================================================

    /** @brief Exportar l'enquesta "titol" a la carpeta Enquestes. */
    public void exportarEnquesta(String titol, String nomNouFitxer, Scanner sc) {
        Enquesta enq = titol2Enquesta.get(titol);
        if (enq == null) return;
        
        String[] adminData = { enq.getAdmin().getName(), enq.getAdmin().getPassword() };
        ArrayList<String> headers = enq.getPreguntesPrimitives();
        ArrayList<ArrayList<String>> respuestas = enq.getRespostesPrimitives();

        String path = "../FONTS/Persistencia/Enquestes/" + nomNouFitxer + ".csv";
        
        // Cridem al nou CtrlPersistencia
        CPers.guardarEnquesta(path, enq.getValorK(), adminData, headers, respuestas);
        
        System.out.println("Enquesta exportada correctament.");
    }
    
    // Sobrecàrrega sense Scanner per a la GUI
    public void exportarEnquesta(String titol, String nomNouFitxer) {
        exportarEnquesta(titol, nomNouFitxer, null);
    }

    /** @brief Agafa les enquestes de la carpeta Enquestes. */
    public void importaEnquestes() throws ExcepcioObrirArxiu {
        // Obtenim llista de fitxers del CtrlPersistencia
        ArrayList<String> ficheros = CPers.fitxersEnEnquestes();

        for (String nombreFichero : ficheros) {
            String titolEnq = nombreFichero.replace(".csv", "");
            String path = "../FONTS/Persistencia/Enquestes/" + nombreFichero;
            
            // Carreguem les dades primitives
            Vector<Vector<String>> dades = CPers.carregarEnquesta(path);
            
            if (dades != null) {
                // Reconstruïm l'objecte Enquesta
                Enquesta e = new Enquesta(titolEnq, dades, usuaris);
                titol2Enquesta.put(titolEnq, e);
            }
        }
        System.out.println("Totes les enquestes s'han importat correctament.");
    }

    /** @brief Exporta totes les enquestes de l'aplicatiu. */
    public void exportarEnquestes() {
        for (HashMap.Entry<String, Enquesta> entry : titol2Enquesta.entrySet()) {
            exportarEnquesta(entry.getKey(), entry.getKey(), null);
        }
        System.out.println("S'han exportat totes les enquestes.");
    }

    /** @brief Importa els usuaris de la carpeta Usuaris. */
    public void importaUsuaris() {
        ArrayList<String> lista = CPers.carregarUsuaris();
        if (lista == null) return;
        
        for (String linea : lista) {
            String[] parts = linea.split(",");
            if (parts.length >= 2) {
                String nombre = parts[0].trim();
                String pass = parts[1].trim();
                
                Usuari u = new Usuari(nombre, pass);
                usuaris.put(nombre, u);
            }
        }
        System.out.println("Usuaris anteriors importats.");
    }

    /** @brief Guarda els usuaris a la carpeta Usuaris. */
    public void exportarUsuaris() {
        ArrayList<String> listaStrings = new ArrayList<>();
        for (HashMap.Entry<String, Usuari> entry : usuaris.entrySet()) {
            listaStrings.add(entry.getKey() + "," + entry.getValue().getPassword());
        }
        CPers.guardarUsuaris(listaStrings);
        System.out.println("S'han guardat els usuaris.");
    }

    // =========================================================================
    //   ALTRES (LEGACY / TESTS)
    // =========================================================================

    public void listarEnquestes() {
        for (String key : titol2Enquesta.keySet()) System.out.println(key);
    }

    public void listarEnquestesUsuari(String name) {
        Usuari u = usuaris.get(name);
        if (u != null) u.listarEnquestes();
    }

    public boolean existeEnquestaUsuari(String name, String titol) {
        Usuari u = usuaris.get(name);
        if (u == null) return false;
        return u.existeEnquesta(titol);
    }

    public int getNumPreguntes(String titol) {
        Enquesta e = titol2Enquesta.get(titol);
        return (e == null) ? -1 : e.getNumPreguntes(); 
    }

    public int getNumRespostes(String titol) {
        Enquesta e = titol2Enquesta.get(titol);
        return (e == null) ? -1 : e.getNumRespostes(); 
    }
}