 /*
    +----------------------------------------------------------+
    |                Cluster.java                              |
    +----------------------------------------------------------+
    | Repositori:                                              |
    |   ·subgrup-prop32.3                                      |
    +----------------------------------------------------------+
    | Aquest mòdul ha sigut programat per:                     |
    |   · Angel Dominguez Buira                                |
    +----------------------------------------------------------+
    | Versió 1.0 : Funcionalitats bàsiques implementades       |
    |                                                          |
    | Versió 2.0: Afegida la búsqueda d'outliers, la imputació |
    |              de nulls, és pot escollir entre els         |
    |              diferents algorismes de clustering          |
    +----------------------------------------------------------+

  */

package FONTS.Domini;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * @file Cluster.java
 * @brief Implementació d'una classe que gestiona la configuració i execució
 *        d'un procés de clustering sobre una enquesta.
 */

/**
 * @class Cluster
 * @brief Classe encarregada de preparar i executar l'anàlisi de clustering
 *        d'una enquesta mitjançant l'algoritme k-means.
 *
 * @details Aquesta classe és un embolcall senzill que:
 *          - Emmagatzema una instància d'Enquesta.
 *          - Permet definir el nombre de clusters (k).
 *          - Executa l'anàlisi de clustering generant un objecte AnalisiCluster.
 */
public class Cluster {

    /** @brief Enquesta sobre la qual es realitzarà el clustering. */
    private  Enquesta e;

    /** @brief Nombre de grups (clusters) que es volen generar. */
    private int k;

    /** @brief Nombre mínim de respostes necessàries per fer clustering */
    private static final int MIN_RESPOSTES = 2;

     /**
     * @brief Constructor amb paràmetre explícit del nombre de clusters.
     *
     * @param enquesta Enquesta que es vol analitzar.
     * @param r Nombre de clusters (k) que es volen generar.
     * @throws InvalidClusterException Si l'enquesta és nul·la o el nombre de clusters és invàlid.
     */
    public Cluster(Enquesta enquesta, int r) throws InvalidClusterException {
        try {
            // Validar que l'enquesta no sigui nul·la
            if (enquesta == null) {
                throw new InvalidClusterException("L'enquesta no pot ser nul·la.");
            }

            // Validar el nombre de clusters
            if (r < MIN_RESPOSTES) {
                throw new InvalidClusterException("El nombre de clusters (k) ha de ser positiu i major o igual que " + MIN_RESPOSTES + ". Valor rebut: " + r);
            }

            this.e = enquesta;
            this.k = r;
        } catch (InvalidClusterException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new InvalidClusterException("Error inesperat en el càlcul de distància: " + ex.getMessage(), ex);
        }
    }

    /**
     * @brief Constructor per defecte, amb k = 3.
     *
     * @param enquesta Enquesta que es vol analitzar.
     * @throws InvalidClusterException Si l'enquesta és nul·la o no compleix els requisits mínims.
     */
    public Cluster(Enquesta enquesta) throws InvalidClusterException {
        this(enquesta, 3);
    }


    /**
     * @brief Selecciona i executa l'estratègia d'inicialització i clustering.
     *
     * @param opcioIni Opció d'inicialització dels centroides (random o k-means++) (0 inicialització random, 1 kmeans++).
     * @param opcioCluster Opció de l'algoritme de clustering (0 cap, 1 k-means i 2 k-medoids).
     * @param respostes Matriu de respostes individuals de l'enquesta.
     * @param preguntes Vector de preguntes de l'enquesta.
     * @details Aquest mètode aplica, en ordre:
     *          - Clonació de les respostes originals
     *          - Detecció i eliminació d'outliers
     *          - Imputació de valors nuls
     *          - Execució de l'algoritme de clustering seleccionat
     *
     * @return Instància d'AnalisiCluster amb el clustering ja executat.
     * @throws InvalidClusterException Si el nombre de clusters demanat és menor que el número de respostes de l'enquesta o si no hi ha cap pregunta
     */
    public AnalisiCluster analitzaCluster(int opcioIni, int opcioCluster, RespostaInd[][] respostes, Pregunta[] preguntes) throws InvalidClusterException {
        try {
            int nPreg = preguntes.length;
            if (nPreg == 0) {
                throw new InvalidClusterException("S'ha de seleccionar almenys una pregunta");
            }
            // Validar el nombre de clusters
            int nResp = respostes.length;
            if (k >= nResp) {
                throw new InvalidClusterException("El nombre de clusters (k) ha de ser major que el número de respostes " + nResp + ". Quantitat de clusterings: " + k);
            }
            RespostaInd[][] resp;
            resp = clonarRespostes(respostes);
            lookForOutliers(resp, preguntes);
            imputacioRespostes(resp, preguntes);
            if (opcioIni == 0 && opcioCluster == 0) {InicialitzacioRandom analisi = new InicialitzacioRandom(resp, k, e.getNumRespostes(), nPreg); return (AnalisiCluster) analisi;}
            else if (opcioIni == 0 && opcioCluster == 1) {Kmeans analisi = new Kmeans(resp, k, e.getNumRespostes(), nPreg); return (AnalisiCluster) analisi;}
            else if (opcioIni == 0 && opcioCluster == 2) {Kmedoids analisi = new Kmedoids(resp, k, e.getNumRespostes(), nPreg); return (AnalisiCluster) analisi;}
            else if (opcioIni == 1 && opcioCluster == 0) {InicialitzacioKmeansPlus analisi = new InicialitzacioKmeansPlus(resp, k, e.getNumRespostes(), nPreg); return (AnalisiCluster) analisi;}
            else if (opcioIni == 1 && opcioCluster == 1) {KmeansPlus analisi = new KmeansPlus(resp, k, e.getNumRespostes(), nPreg); return (AnalisiCluster) analisi;}
            else if (opcioIni == 1 && opcioCluster == 2) {KmedoidsPlus analisi = new KmedoidsPlus(resp, k, e.getNumRespostes(), nPreg); return (AnalisiCluster) analisi;}
            else throw new InvalidClusterException("No s'ha escollit un mètode de clustering existent");
        } catch (InvalidClusterException ex) {
            // Re-llançar l'excepció de clustering
            throw ex;
        } catch (Exception ex) {
            // Capturar qualsevol altra excepció inesperada
            throw new InvalidClusterException(
                "Error inesperat durant l'anàlisi de clustering: " + ex.getMessage(),
                ex
            );
        }
    }


    /**
     * @brief Crea i retorna una còpia de la matriu de respostes de l'enquesta.
     * @param aux Matriu original de respostes a clonar.
     * @details Genera una nova matriu amb les mateixes dimensions que la matriu
     *          original de l'enquesta i copia totes les respostes. Aquesta còpia
     *          permet treballar amb les dades sense modificar directament les
     *          respostes originals emmagatzemades a l'objecte Enquesta.
     *
     * @return Una nova matriu de RespostaInd que conté les respostes de l'enquesta.
     */
    private RespostaInd[][] clonarRespostes (RespostaInd[][] aux) {
        int nResp = aux.length;
        int nPreg = aux[0].length;
        RespostaInd[][]respostes = new RespostaInd[nResp][nPreg];
        for (int i = 0; i < nResp; ++i) {
            for (int j = 0; j < nPreg; ++j) {
                respostes[i][j] = aux[i][j];
            }
        }
        return respostes;
    }

    /**
     * @brief Detecta i elimina outliers en preguntes numèriques.
     *
     * @param respostes Matriu de respostes sobre la qual s'analitzen els outliers.
     * @param preguntesDeEnquesta Vector de preguntes de l'enquesta.
     * @details Utilitza el rang interquartílic (IQR) per identificar valors
     *          extrems i substituir-los per valors nuls.
     *
     * @throws InvalidClusterException Si es produeix un error durant el procés.
    */
    private void lookForOutliers (RespostaInd[][] respostes, Pregunta[] preguntesDeEnquesta) throws InvalidClusterException {
        try {
            int nResp = e.getNumRespostes();
            int nPreg = preguntesDeEnquesta.length;
            //estableixo un mínim de dades per a poder trobar outliers
            if (nResp >= 5) {
                for(int i = 0; i < nPreg; ++i) {
                    Pregunta p = preguntesDeEnquesta[i];
                    if (p instanceof PreguntaLliure && ((PreguntaLliure)p).esNumerica()) {
                        RespostaNum[] arr = new RespostaNum[nResp];
                        int[] aux = new int[nResp];
                        for (int j = 0; j < nResp; ++j) {
                            arr[j] = (RespostaNum) respostes[j][i];
                            aux[j] = j;
                        }
                        mergeSort(arr, aux, 0, nResp - 1);
                        int pos_inf = (int) nResp/4;
                        float int_inf = arr[pos_inf].getValor();
                        int pos_sup = (int) nResp * 3/4;
                        float int_sup = arr[pos_sup].getValor();
                        float dif = int_sup - int_inf;

                        float limInf = int_inf - (dif*(3/2));
                        float limSup = int_sup + (dif*(3/2));
                        int j = 0; 
                        boolean outlier = true;
                        while (outlier && j < pos_inf) {
                            if (arr[j].getValor() < limInf) {
                                respostes[aux[j]][i] = null;
                            }
                            else outlier = false;
                            ++j;
                        }

                        j = nResp - 1;
                        outlier = true;
                        while (outlier && j > pos_sup) {
                            if (arr[j].getValor() > limSup) {
                                respostes[aux[j]][i] = null;
                            }
                            else outlier = false;
                            --j;
                        }
                    }
                }
            }
        } catch (Exception ex) {
            throw new InvalidClusterException(
                "Error inesperat durant la búsqueda d'outliers: " + ex.getMessage(),
                ex
            );
        }
    }

    /**
     * @brief Algoritme merge sort per ordenar respostes numèriques.
     *
     * @param arr Array de RespostaNum a ordenar.
     * @param aux Array auxiliar per mantenir la posició original de les respostes.
     * @param left Índex esquerre del subarray.
     * @param right Índex dret del subarray.
     *
     * @details Ordena les respostes segons el seu valor numèric.
     */
    private static void mergeSort(RespostaNum[] arr, int[] aux, int left, int right) {
        if (left >= right) return;

        int mid = (left + right) / 2;

        mergeSort(arr, aux, left, mid);
        mergeSort(arr, aux, mid + 1, right);

        merge(arr, aux, left, mid, right);
    }


    /**
     * @brief Funció auxiliar del merge sort.
     *
     * @param arr Array de RespostaNum a ordenar.
     * @param aux Array auxiliar amb els índexs originals.
     * @param left Índex inicial.
     * @param mid Punt mig.
     * @param right Índex final.
     *
     * @details Combina dos subarrays ordenats en un de sol.
     */
    private static void merge(RespostaNum[] arr, int[] aux, int left, int mid, int right) {
        RespostaNum[] temp = new RespostaNum[right - left + 1];
        int[] tempAux = new int[right - left + 1];

        int i = left;
        int j = mid + 1;
        int k = 0;

        while (i <= mid && j <= right) {
            if (arr[i].getValor() <= arr[j].getValor()) {
                temp[k] = arr[i];
                tempAux[k] = aux[i];
                k+=1;
                i+=1;
            }
            else {
                temp[k] = arr[j];
                tempAux[k] = aux[j];
                k+=1;
                j+=1;
            }
        }

        while (i <= mid) {
            temp[k] = arr[i];
            tempAux[k] = aux[i];
            k+=1;
            i+=1;
        }
        while (j <= right) {
            temp[k] = arr[j];
            tempAux[k] = aux[j];
            k+=1;
            j+=1;
        }

        for (int t = 0; t < temp.length; t++) {
            arr[left + t] = temp[t];
            aux[left + t] = tempAux[t];
        }
    }

    /**
     * @brief Imputa valors nuls de les respostes de l'enquesta.
     *
     * @param respostes Matriu de respostes amb possibles valors nuls.
     * @param preguntesDeEnquesta Vector de preguntes de l'enquesta.
     * 
     * @details
     *  - Per respostes numèriques: s'imputa la mitjana.
     *  - Per respostes de text: s'imputa la paraula més freqüent.
     *  - Per respostes multichoice: s'imputa l'opció més freqüent.
     * @throws InvalidClusterException Si es produeix un error durant la imputació.
     * @throws InvalidRespostaException Si es genera una resposta invàlida.
     */
    private void imputacioRespostes(RespostaInd[][] respostes, Pregunta[] preguntesDeEnquesta) throws InvalidClusterException, InvalidRespostaException 
    {
        try {
            int nResp = e.getNumRespostes();
            int nPreg = preguntesDeEnquesta.length;
            float mitjana = 0.0f, compt = 0.0f;
            for (int i = 0; i < nPreg; ++i) { //anem pregunta per pregunta
                if (preguntesDeEnquesta[i] instanceof PreguntaLliure) {
                    PreguntaLliure preg_ll = (PreguntaLliure) preguntesDeEnquesta[i];
                    if (preg_ll.esNumerica()) {
                        for (int j = 0; j < nResp; ++j) { //calculem mitjana
                            RespostaNum resp_num = (RespostaNum) respostes[j][i];
                            if (resp_num != null) {
                                mitjana = mitjana + resp_num.getValor();
                                compt += 1.0f;
                            }
                        }
                        if (compt >= 1.0) mitjana = mitjana / compt;
                        for (int j = 0; j < nResp; ++j) { //substituim
                            RespostaNum resp_num = (RespostaNum) respostes[j][i];
                            if (resp_num == null) {
                                RespostaNum resp_imputada = new RespostaNum(preg_ll,"aa", mitjana);
                                respostes[j][i] = resp_imputada;
                            }
                        }
                        mitjana = 0.0f;
                        compt = 0.0f;
                    
                    }
                    else {
                        //Inicialitzo array de map, cada element de l'array marca la freqüencia de strings
                        Map<String, Integer> frequencyMap = new HashMap<>();

                        for (int j = 0; j < nResp; ++j) {
                            if (respostes[j][i] != null) {
                                RespostaText rn = (RespostaText) respostes[j][i];
                                String n = rn.getValor();
                                //convertim a minúscules i treiem signes de puntuació, possible implementacio de ometre signes extranys
                                String cleaned = n.toLowerCase();
                                String[] words = cleaned.split("\\s+");


                                for (String word : words) {
                                    if (!word.isBlank()) {
                                        Integer f = frequencyMap.get(word);
                                        if (f == null) { // no estava l'string enregistrat
                                            frequencyMap.put(word, 1);
                                        }
                                        else {
                                            frequencyMap.put(word, f+1);
                                        }
                                    }
                                }
                            }
                        }

                        // Busquem la paraula més freqüent 
                        String res = "null";
                        int freq = 0;

                        for (Map.Entry<String, Integer> e2 : frequencyMap.entrySet()) {
                            if (e2.getValue() > freq) {
                                freq = e2.getValue();
                                res = e2.getKey();
                            }
                        }
                        for (int j = 0; j < nResp; ++j) {
                            if (respostes[j][i] == null) {
                                respostes[j][i] = new RespostaText(preg_ll, "null", res);
                            }
                        }                    
                    }
                    
                } else {
                    PreguntaMultichoice p = (PreguntaMultichoice) preguntesDeEnquesta[i];
                    int nOpcions = p.getOpcions().size();
                    //Inicialitzo array de map, cada element de l'array marca la freqüencia de cada opcio
                    int[] frequencyMap = new int[nOpcions];
                    for (int s = 0; s < nOpcions; ++s){
                        frequencyMap[s] = 0;
                    }

                    for (int j = 0; j < nResp; ++j) {
                        if (respostes[j][i] != null) {
                            RespostaMultichoice r = (RespostaMultichoice) respostes[j][i];
                            Set<Integer> resp = r.getValor();

                            for (Integer num : resp) {
                                frequencyMap[num] += 1;
                            }
                        }
                    }

                    // Trobar freqüencia maxima 
                    int maxFreq = 0;
                    int resultat = 0;
                    for (int j = 0; j < nOpcions; ++j) {
                        int freq = frequencyMap[j];
                        if (freq > maxFreq) {
                            maxFreq = freq;
                            resultat = j;
                        }
                    }

                    Set<Integer> res = new HashSet<>();
                    res.add(resultat);
                    for (int j = 0; j < nResp; ++j) {
                        if (respostes[j][i] == null) {
                            respostes[j][i] = new RespostaMultichoice(p, "null", res);
                        }
                    }                  
                }
            }
        } catch (Exception ex) {
            throw new InvalidClusterException(
                "Error inesperat durant la imputació de respostes: " + ex.getMessage(),
                ex
            );
        }

    }

}
