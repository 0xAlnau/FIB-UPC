 /*
    +----------------------------------------------------------+
    |                      Enquesta.java                       |
    +----------------------------------------------------------+ 
    | Repositori:                                              |
    |   ·subgrup-prop32.3                                      |
    +----------------------------------------------------------+
    | Aquest mòdul ha sigut programat per:                     |
    |   ·Arnau Cullell Martínez                                |
    +----------------------------------------------------------+
    | *Versió 0.5: Començant a implementar funcionalitats      |
    |              bàsiques.                                   |
    | *Versió 1.0: Ja es pot importar, exportar, eliminar,     |
    |              afegir i veure correctament els enquestes   |
    | *Versió 1.5: Pot importar i exportar preguntes de forma  |
    |              correcta, exporta i importa els fitxers de  |
    |              prova.                                      |
    | *Versió 2.0: Ara pot guardar sempre l'execució actual    |
    |            per tal de poder-la seguir en un altre moment,|
    |            a més a més per cada cluster també indica el  |
    |            seu coeficient de Silhouette.                 |  
    | *Versió 3.0: Classe modificada perquè ja no ha de crear  |
    |              arxius ni guardar-ho's.                     |
    |                                                          |
    +----------------------------------------------------------+
  */

 /** @file Enquesta.java
     @brief Codi de la classe Enquesta.
*/

/** @class Enquesta
    @brief Representa una enquesta amb les seves característiques i
    les seves operacions pròpies, que són:

    <b>-Constructores:</b> té 2 constructores. La primera es la de per defecte, on rep un títol
     i el nom de l'administrador que crea l'Enquesta. La segona permet crear l'Enquesta també amb
     un títol i el nom de l'administrador, però, també permet importar una altra enquesta d'un fitxer
     .csv i agafar les seves preguntes, amb el seu tipus i les seves opcions si és multichoice.

    <b>-Consultores:</b> té 5 consultores. On podem consultar: quantes preguntes té l'enquesta;
     les preguntes en sí; quanta gent ha respòs; totes les respostes; i el títol de l'Enquesta. 

    <b>-Modificadores:</b> té 5 modificadores. Que s'encarreguen de: registrar les preguntes (sigui
     del tipus que siguin); registrar les respostes (siguin del tipus que siguin); exportar l'Enquesta
     en el seu fitxer .csv corresponent; eliminar preguntes; i generar els clusters.

    <b>-Escriure:</b> té 1 funció que escriu per pantalla, i s'encarrega de mostrar de forma visual
     i atractiva les respostes de l'enquesta per cada usuari.
*/
package FONTS.Domini; //necessari!! encara que surti vermell esta be!

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;


public class Enquesta 
{
    /** @brief Atribut que serveix per indentificar l'Enquesta.*/
    private String titol;

    /** @brief Atribut que serveix per indicar quants clusters volem.*/
    private int valorK;

    /** @brief Atribut que serveix per indicar quin és el ID que li tocaria al següent usuari sense haver contestat abans.*/
    private int segIdUsu = 1;

    /** @brief Atribut que serveix per indicar quin és el ID que li tocaria a la següent pregunta que caldria registrar.*/
    private int segIdPreg = 1;

    /** @brief Atribut que serveix per indicar quin és el ID de la fila (respostes d'usuari) que caldria omplir si arriba un nou usuari.*/
    private int segIdFila = 1;

    /** @brief Atribut que serveix per indicar quin és el ID de la fila (respostes d'usuari) que caldria omplir si arriba un nou usuari.*/
    private float cSil;

    /** @brief Atribut que serveix per indicar quantes preguntes com a màxim pot tenir l'Enquesta.*/
    private int MAX_PREGUNTES = 3000;

    /** @brief Atribut que serveix per indicar quants usuaris poden contestar com a màxim a l'Enquesta.*/
    private int MAX_USUARIS = 3000;

    /** @brief Indica la llargaria màxima d'una pregunta/resposta.*/
    private int maxAllargadaPreg = 6; // 6 de usuari

    /** @brief Atribut que serveix per comunicar-se amb l'administrador de l'Enquesta.*/
    private Usuari admin;

    /** @brief Atribut que serveix per consultar i manejar les respostes que ha rebut l'Enquesta.
     *  El format és:
     *  IdUsuari | Preg1 | Preg2 | Preg3 | ... | PregN | clusterAlQuePertany
    */
    private RespostaInd[][] respostesCompletes = new RespostaInd[MAX_USUARIS][MAX_PREGUNTES];

    /** @brief Atribut que serveix per anar guardant els enunciats de les preguntes a mesura que arriben.*/
    private String[] fila0 = new String[MAX_PREGUNTES];

    /** @brief Atribut que indica a quina fila de la columna 0 hauria d'anar els usuaris nous de l'Enquesta.*/
    private String[] columna0 = new String[MAX_USUARIS];

    /** @brief Atribut que serveix per dir i guardar el cluster al qual pertany cada usuari una vegada fet l'analisi.*/
    private String[] columnaClusters = new String[MAX_USUARIS];

    /** @brief Atribut que serveix per consultar i manejar les preguntes de l'Enquesta.*/
    private Pregunta[] preguntesDeEnquesta = new Pregunta[MAX_PREGUNTES];

    /** @brief Atribut que serveix per generar el cluster i consultar el seu anàlisi.*/
    private Cluster cluster;

    /** @brief Atribut que serveix per emmagatzemar el resultat donat pel cluster*/
    private AnalisiCluster analisiCluster;

    /** @brief Atribut que permet passar del nom d'un usuari al seu número identificador corresponent*/
    private Map<String,Integer> usuari2num = new HashMap<String, Integer>();

    /** @brief Atribut que permet passar de l'enunciat d'una pregunta al seu número identificador corresponent*/
    private Map<String,Integer> preg2num = new HashMap<String, Integer>();

    /** @brief Atribut que permet passar del nom d'un usuari a la seva fila corresponent en la taula de respostes.*/
    private Map<String,Integer> usari2taula = new HashMap<String, Integer>();


    //Constructores
    /** @brief Creadora per defecte.*/
    public Enquesta (String titol, Usuari admin, Integer valorK) 
    {
        this.admin = admin;
        this.titol = titol;
        this.valorK = valorK;
        fila0[0] = "Usuari";
    }

    /** @brief Creadora on l'enquesta creada ja està feta d'abans i s'IMPORTA.*/
    public Enquesta(String titol, Vector<Vector<String>> datos, HashMap<String, Usuari> usuarios) 
    {
        this.titol = titol;
        this.fila0[0] = "Usuari"; 

        if (datos.size() > 0 && !datos.get(0).isEmpty()) { //la k
            this.valorK = Integer.parseInt(datos.get(0).get(0));
        }

        if (datos.size() > 1) { //admin i contra
            Vector<String> filaAdmin = datos.get(1);
            String adminName = filaAdmin.get(0);
            String adminPass = (filaAdmin.size() > 1) ? filaAdmin.get(1) : "password"; // Fallback simple

            //si l'usuari existeix l'agafem, si no el creem
            if (usuarios.get(adminName) == null) {
                this.admin = new Usuari(adminName, adminPass);
                usuarios.put(adminName, this.admin);
            } else {
                this.admin = usuarios.get(adminName);
            }
            this.admin.crearEnquesta(titol, this);
        }

        if (datos.size() > 2) { //llegim preguntes
            Vector<String> filaHeaders = datos.get(2);
            for (int i = 1; i < filaHeaders.size() - 1; ++i) {
                String rawPregunta = filaHeaders.get(i);
                parsearIRegistrarPregunta(rawPregunta);
            }
        }

        for (int i = 3; i < datos.size(); ++i) { //llegim respostes
            Vector<String> filaResp = datos.get(i);
            if (filaResp.isEmpty()) continue;

            String nomUsuari = filaResp.get(0);
            
            if (usuarios.get(nomUsuari) == null) {
                Usuari u = new Usuari();
                u.setName(nomUsuari);
                usuarios.put(nomUsuari, u);
            }
            
            int limitColumnes = Math.min(filaResp.size() - 1, getNumPreguntes() + 1); 
            
            for (int j = 1; j < limitColumnes; ++j) {
                String valorResposta = filaResp.get(j);
                
                if (valorResposta == null || 
                    valorResposta.trim().isEmpty() || 
                    valorResposta.trim().equalsIgnoreCase("NULL")) {
                    continue; // Saltem al següent cicle sense intentar parsejar
                }
                
                Pregunta preg = preguntesDeEnquesta[j]; 
                
                try {
                    if (preg instanceof PreguntaMultichoice) {
                        Set<Integer> opcionsEscollides = new HashSet<>();
                        String[] ops = valorResposta.split("~");
                        for (String op : ops) {
                            if (!op.isEmpty()) opcionsEscollides.add(Integer.parseInt(op));
                        }
                        RespostaMultichoice resp = new RespostaMultichoice((PreguntaMultichoice) preg, nomUsuari, opcionsEscollides);
                        registrarResposta(resp);
                        
                    } else if (preg instanceof PreguntaLliure) {
                        PreguntaLliure pregLliure = (PreguntaLliure) preg;
                        if (pregLliure.esNumerica()) {
                            RespostaNum resp = new RespostaNum(pregLliure, nomUsuari, Float.parseFloat(valorResposta));
                            registrarResposta(resp);
                        }
                        else {
                            RespostaText resp = new RespostaText(pregLliure, nomUsuari, valorResposta);
                            registrarResposta(resp);
                        }
                    }
                }
                catch (InvalidRespostaException e) {
                    System.err.println("Error important resposta usuari " + nomUsuari + ": " + e.getMessage());
                }
                catch (NumberFormatException e) {
                    System.err.println("Error de format numèric a l'enquesta " + titol + ": " + e.getMessage());
                }
            }

            int indexCluster = filaResp.size() - 1; //cluster
            if (indexCluster > 0 && indexCluster < filaResp.size()) {
                String valCluster = filaResp.get(indexCluster);
                if (valCluster != null && !valCluster.equalsIgnoreCase("NULL")) {
                    if (columnaClusters == null || columnaClusters.length < MAX_USUARIS) {
                         if (columnaClusters == null) columnaClusters = new String[MAX_USUARIS];
                    }
                    Integer filaTaula = usari2taula.get(nomUsuari);
                    if (filaTaula != null) {
                        columnaClusters[filaTaula - 1] = valCluster;
                    }
                }
            }
        }
    }

    //Setter
    /** @brief Permet assignar un nou valor k a l'enquesta.*/
    public void setValorK(Integer k)
    {
        valorK = k;
    }

    //Consultores
    /** @brief Consultora del nombre de preguntes que té l'Enquesta.*/
    public Integer getNumPreguntes() 
    {
        return segIdPreg - 1;
    }

    /** @brief Consultora del nombre de respostes que ha rebut l'Enquesta.*/
    public Integer getNumRespostes() 
    {
        return segIdUsu - 1;
    }

    /** @brief Consultora del nom de l'Enquesta.*/
    public String getTitolEnquesta() 
    {
        return titol;
    }

    public Usuari getAdmin()
    {
        return admin;
    }

    public Integer getValorK()
    {
        return valorK;
    }

    /** @brief Consultora de les respostes de l'Enquesta en forma de matriu.*/
    public RespostaInd[][] getRespostes() 
    {
        return respostesCompletes;
    }

    /** @brief Consultora de les preguntes a l'Enquesta.*/
    public Pregunta[] getPreguntes()
    {
        return preguntesDeEnquesta;
    }

    /** @brief Permet saber a quin prototipus pertany una persona.*/
    public String getPrototipus(String name) 
    {
        Integer fila = usari2taula.get(name);
        if (columnaClusters == null) {
            return "null";
        }
        else {
            return columnaClusters[fila-1];
        }
    }

    /** @brief Transforma a dades primitives les preguntes de l'enquesta (enunciats nomes).*/
    public ArrayList<String> getPreguntesPrimitives() 
    {
        ArrayList<String> headers = new ArrayList<>();
        int n_preg = getNumPreguntes();
        
        for (int i = 1; i <= n_preg; ++i) {
            String formato = "";
            if (preguntesDeEnquesta[i] instanceof PreguntaLliure) {
                PreguntaLliure preg = (PreguntaLliure) preguntesDeEnquesta[i];
                formato = fila0[i] + (preg.esNumerica() ? "N?" : "T?");
            }
            else {
                PreguntaMultichoice preg = (PreguntaMultichoice) preguntesDeEnquesta[i];
                String ops = "~";
                for (String op : preg.getOpcions()) ops += op + "~";
                formato = fila0[i] + ops + "!" + preg.getLimitOpcions() + "!";
            }
            headers.add(formato);
        }
        return headers;
    }

    /** @brief Transforma les respostes dels usuaris a dades primitives.*/
    public ArrayList<ArrayList<String>> getRespostesPrimitives()
    {
        ArrayList<ArrayList<String>> matriz = new ArrayList<>();
        
        for (int i = 1; i <= segIdFila - 1; ++i) { //noms usuaris
            ArrayList<String> fila = new ArrayList<>();
            fila.add(columna0[i]);
            
            for (int j = 1; j <= segIdPreg - 1; ++j) {
                String val = "NULL";
                if (respostesCompletes[i-1][j-1] != null) {
                    if (respostesCompletes[i-1][j-1] instanceof RespostaMultichoice) {
                        RespostaMultichoice resp = (RespostaMultichoice) respostesCompletes[i-1][j-1];
                        StringBuilder sb = new StringBuilder();
                        Iterator<Integer> it = resp.getValor().iterator();
                        while (it.hasNext()) {
                            sb.append(it.next());
                            if (it.hasNext()) sb.append("~");
                        }
                        val = sb.toString();
                    } 
                    else {
                        val = respostesCompletes[i-1][j-1].getRespostaText();
                    }
                }
                fila.add(val);
            }
            fila.add(columnaClusters != null && columnaClusters[i-1] != null ? columnaClusters[i-1] : "NULL");
            matriz.add(fila);
        }
        return matriz;
    }

    //Modificadores
    /** @brief Permet generar els clusters i veure els seus resultats.*/
    public void generarCluster(Set<Integer> preguntes_esc, int opc_k_means, int opc_tipus)  throws InvalidClusterException
    {
        if (getNumRespostes() > 0) {
            try {
                RespostaInd[][] aux = new RespostaInd[segIdFila-1][preguntes_esc.size()];
                Pregunta[] preguntesCluster = new Pregunta[preguntes_esc.size()];
                int pregunta_x = 0;
                for (int i = 1; i <= segIdFila-1; ++i) {
                    for (int j = 1; j <= segIdPreg-1; ++j) {
                        if (preguntes_esc.contains(j)) {
                            aux[i-1][pregunta_x] = respostesCompletes[i-1][j-1];
                            preguntesCluster[pregunta_x] = preguntesDeEnquesta[j];
                            ++pregunta_x;
                        }
                    }
                    pregunta_x = 0;
                }

                cluster = new Cluster(this, valorK);
                analisiCluster = cluster.analitzaCluster(opc_k_means, opc_tipus, aux, preguntesCluster);

                Integer[] assig = analisiCluster.getAssignacions();
                int size = assig.length;
                columnaClusters = new String[size];
                for (int i = 0; i < size; ++i) { //passem els valor a strings per comoditat després
                    columnaClusters[i] = String.valueOf(assig[i]);
                }
                try{
                    cSil = analisiCluster.calculaSilhouette();
                }
                catch (InvalidClusterException e) {
                    System.err.println(e.getMessage());
                }
                catch (InvalidRespostaException e) {
                    System.err.println(e.getMessage());
                }
            }
            catch (InvalidClusterException e) {
                System.out.println(e.getMessage());
                throw e;
            }
        }
        else {
            System.out.println("No es pot fer un cluster sense respostes");
        }
    }

    /** @brief Fa la imputació a base de calcular la mitjana de les respostes d'una pregunta. */
    public void imputacioRespostes() 
    {
        float mitjana = 0.0f, compt = 0.0f;
        for (int i = 1; i <= segIdPreg - 1; ++i) { //anem pregunta per pregunta
            if (preguntesDeEnquesta[i] instanceof PreguntaLliure) {
                PreguntaLliure preg_ll = (PreguntaLliure) preguntesDeEnquesta[i];
                if (preg_ll.esNumerica()) {
                    for (int j = 1; j <= segIdFila -1; ++j) { //calculem mitjana
                        RespostaNum resp_num = (RespostaNum) respostesCompletes[j-1][i-1];
                        if (resp_num == null) {
                            //no fem res :D
                        }
                        else {
                            mitjana = mitjana + resp_num.getValor();
                            compt += 1.0f;
                        }
                    }
                    if (compt >= 1.0) mitjana = mitjana / compt;
                    for (int k = 1; k <= segIdFila -1; ++k) { //substituim
                        RespostaNum resp_num = (RespostaNum) respostesCompletes[k-1][i-1];
                        if (resp_num == null) {
                            try {
                                RespostaNum resp_imputada = new RespostaNum(preg_ll, columna0[k], mitjana);
                                respostesCompletes[k-1][i-1] = resp_imputada;
                                if (respostesCompletes[k-1][i-1].getRespostaText().length() > maxAllargadaPreg) maxAllargadaPreg = respostesCompletes[k-1][i-1].getRespostaText().length(); 
                            }
                            catch (InvalidRespostaException e) {
                                System.err.println(e.getMessage());
                            }
                        }
                    }
                    System.out.println("Mitjana: " + mitjana);
                    mitjana = 0.0f;
                    compt = 0.0f;
                }
            }
        }
    }

    /** @brief Permet registrar una nova pregunta a l'Enquesta, sigui lliure o multichoice. */
    public void registrarPregunta(Pregunta preg)  
    {
        String enunciatPreg = preg.getText();
        if (preg2num.get(enunciatPreg) != null) { //pregunta feta abans o pot ser error

        }
        else {
            preg2num.put(enunciatPreg, segIdPreg);
            ++segIdPreg;
        }
        
        if (enunciatPreg.length() > maxAllargadaPreg) maxAllargadaPreg = enunciatPreg.length();
        int i = preg2num.get(enunciatPreg);
        if (fila0[i] == null) fila0[i] = enunciatPreg;
        preguntesDeEnquesta[i] = preg;
    }

    /** @brief Permet eliminar una pregunta de l'Enquesta. */
    public void eliminarPregunta(String preg)  
    {
        if (preg2num.get(preg) == null) { //pregunta no existeix

        }
        else {
            int i = preg2num.get(preg);
            preg2num.remove(preg);
            --segIdPreg;

            //movem indexos
            for (Map.Entry<String, Integer> pair : preg2num.entrySet()) {
                if (pair.getValue() > i) preg2num.put(pair.getKey(), pair.getValue() - 1);
            }
            for (int j = i; j < MAX_PREGUNTES; ++j) {
                    if (j + 1 < MAX_PREGUNTES) {
                        fila0[j] = fila0[j+1];
                        preguntesDeEnquesta[j] = preguntesDeEnquesta[j+1];
                    }
            }

            for (int k = 0; k < MAX_USUARIS; ++k) {
                for (int l = i; l < MAX_PREGUNTES; ++l) {
                    if (l + 1 < MAX_PREGUNTES) {
                        respostesCompletes[k][l] = respostesCompletes[k][l+1];
                    }        
                }
            }
        }
    }


    private void parsearIRegistrarPregunta(String raw) 
    {
        int len = raw.length();
        if (len < 2) return;

        char lastChar = raw.charAt(len - 1);
        
        if (lastChar == '?') { //lliure
            char tipus = raw.charAt(len - 2); // 'N' o 'T'
            String enunciat = raw.substring(0, len - 2);
            
            boolean esNumerica = (tipus == 'N');
            try {
                PreguntaLliure preg = new PreguntaLliure(enunciat, 20, esNumerica);
                registrarPregunta(preg);
            }
            catch (InvalidPreguntaException e) {
                System.err.println("Error creant pregunta lliure: " + e.getMessage());
            }

        }
        else if (lastChar == '!') { //multichoice
            int indexPenultimExcl = raw.lastIndexOf('!', len - 2);
            if (indexPenultimExcl == -1) return;
            
            String limitStr = raw.substring(indexPenultimExcl + 1, len - 1);
            int limitOpcions = Integer.parseInt(limitStr);
            
            String partEsquerra = raw.substring(0, indexPenultimExcl);
            
            String[] parts = partEsquerra.split("~");
            String enunciat = parts[0];
            List<String> opcions = new ArrayList<>();
            
            for (int k = 1; k < parts.length; ++k) {
                opcions.add(parts[k]);
            }
            
            try {
                PreguntaMultichoice preg = new PreguntaMultichoice(enunciat, opcions, limitOpcions);
                registrarPregunta(preg);
            } 
            catch (InvalidPreguntaException e) {
                System.err.println("Error creant pregunta multichoice: " + e.getMessage());
            }
        }
    }

    /** @brief Permet anar registrant les respostes de la gent en el seu array.*/
    public void registrarResposta(RespostaInd resp) 
    {
        Pregunta preg = resp.getPreguntaAssociada();
        String nomUsuari = resp.getIdUsuari();

        if (usuari2num.get(nomUsuari) == null) { // l'usuari no estava enregistrat
            usuari2num.put(nomUsuari, segIdUsu);
            ++segIdUsu;
        }

        String enunciatPreg = preg.getText();
        if (preg2num.get(enunciatPreg) == null) {}//throw error, preg d'una altra enquesta o no existeix
        
        if (usari2taula.get(nomUsuari) == null) { //usuari no té assignada una fila en la taula
            usari2taula.put(nomUsuari, segIdFila);
            ++segIdFila;
        }

        int i = usari2taula.get(nomUsuari);
        int j = preg2num.get(enunciatPreg);
        if (columna0[i] == null) columna0[i] = nomUsuari; //posem el nom de l'usuari a la nova fila
        if (respostesCompletes[i-1][j-1] == null) respostesCompletes[i-1][j-1] = resp;
        if (respostesCompletes[i-1][j-1].getRespostaText().length() > maxAllargadaPreg) maxAllargadaPreg = respostesCompletes[i-1][j-1].getRespostaText().length(); 
    }

    /**@throws ExcepcioGenerarArxiu 
     * @brief Permet generar el fitxer .csv corresponent en la carpeta Enquestes.*/
    public void exportarEnquesta(String nomNouFitxer, Scanner sc) throws ExcepcioGenerarArxiu
    {
        try (PrintWriter pw = new PrintWriter(new FileWriter("../FONTS/Persistencia/Enquestes/" + nomNouFitxer + ".csv"))) {
            pw.println(valorK);
            pw.println(admin.getName() + "," + admin.getPassword());
            // escriu les preguntes
            pw.print("Usuaris,");
            int n_preg = getNumPreguntes();
            for (int i = 1; i <= n_preg; ++i) {
                if (i < n_preg) {
                    if (preguntesDeEnquesta[i] instanceof PreguntaLliure) {
                        PreguntaLliure preg = (PreguntaLliure) preguntesDeEnquesta[i];
                        if (preg.esNumerica()) { //numèrica
                            pw.print(fila0[i] + "N" + "?" + ","); //pregunta lliure i numerica
                        }
                        else { //text
                            pw.print(fila0[i] + "T" + "?" + ","); //pregunta lliure i de text
                        }
                    }
                    else { //multichoice
                        PreguntaMultichoice preg = (PreguntaMultichoice) preguntesDeEnquesta[i];
                        List<String> opcions = preg.getOpcions();
                        String aux = "~"; //farem que les opcions siguien entre 'x'
                        int size = opcions.size();
                        for (int k = 0; k < size; ++k) {
                            aux += opcions.get(k) + "~";
                        }
                        int limit_opcions = preg.getLimitOpcions();
                        pw.print(fila0[i] + aux + "!" + limit_opcions + "!" + ","); //pregunta multichoice
                    }
                }
                else { //ultima pregunta no cal coma
                    if (preguntesDeEnquesta[i] instanceof PreguntaLliure) {
                        PreguntaLliure preg = (PreguntaLliure) preguntesDeEnquesta[i];
                        if (preg.esNumerica()) { //numèrica
                            pw.print(fila0[i] + "N" + "?"); //pregunta lliure i numerica
                        }
                        else { //text
                            pw.print(fila0[i] + "T" + "?"); //pregunta lliure i de text
                        }
                    }
                    else { //multichoice
                        PreguntaMultichoice preg = (PreguntaMultichoice) preguntesDeEnquesta[i];
                        List<String> opcions = preg.getOpcions();
                        String aux = "~"; //farem que les opcions siguien entre 'x'
                        int size = opcions.size();
                        for (int k = 0; k < size; ++k) {
                            aux += opcions.get(k) + "~";
                        }
                        int limit_opcions = preg.getLimitOpcions();
                        pw.print(fila0[i] + aux + "!" + limit_opcions + "!"); //pregunta multichoice
                    }
                }
            }
            pw.print(",Cluster");

            System.out.print("Vols també exportar les respostes? s/n ");
            String consulta = sc.nextLine();

            if (consulta.equalsIgnoreCase("s")) {
                if (segIdFila == 1) System.err.println("Error: no hi ha respostes a exportar!");
                else {
                    pw.println();
                    for (int i = 1; i <= segIdFila-1; ++i) {
                        pw.print(columna0[i] + ",");
                        for (int j = 1; j <= segIdPreg-1; ++j) {
                            if (j < segIdPreg-1) { //cal comes
                                if (respostesCompletes[i-1][j-1] == null) pw.print("NULL,");
                                else if (respostesCompletes[i-1][j-1] instanceof RespostaMultichoice) {
                                    RespostaMultichoice resp = (RespostaMultichoice) respostesCompletes[i-1][j-1];
                                    Set<Integer> respostes = resp.getValor();
                                    Iterator<Integer> namesIterator = respostes.iterator();
                                    while(namesIterator.hasNext()) {
                                       Integer num = namesIterator.next();
                                       pw.print(num + ",");
                                    }
                                }
                                else {
                                    String resp = respostesCompletes[i-1][j-1].getRespostaText();
                                    pw.print(resp + ",");
                                }
                            }
                            else { //ultima resposta no cal comes
                                if (respostesCompletes[i-1][j-1] == null) pw.print("NULL");
                                else if (respostesCompletes[i-1][j-1] instanceof RespostaMultichoice) {
                                    RespostaMultichoice resp = (RespostaMultichoice) respostesCompletes[i-1][j-1];
                                    Set<Integer> respostes = resp.getValor();
                                    Iterator<Integer> namesIterator = respostes.iterator();
                                    while(namesIterator.hasNext()) {
                                       Integer num = namesIterator.next();
                                       if (namesIterator.hasNext()) pw.print(num + "~");
                                       else pw.print(num);
                                    }
                                }
                                else {
                                    String resp = respostesCompletes[i-1][j-1].getRespostaText();
                                    pw.print(resp);
                                }
                                if (columnaClusters != null) {
                                    pw.print("," + columnaClusters[i-1]);
                                }
                                else {
                                    pw.print(",NULL");
                                }
                            }
                        }
                        if (i < segIdFila-1)  {
                            pw.println();
                        }
                    }
                }

            }

            System.out.println("Enquesta exportada correctament a la carpeta 'Enquestes' amb el nom " + nomNouFitxer);

        } 
        catch (IOException e) {
            throw new ExcepcioGenerarArxiu(nomNouFitxer);
        }
    }


    //Escriure
    /** @brief Permet veure les respostes registrades de la gent.*/
    public void veureRespostes() 
    {
        System.out.println();
        System.out.println(titol);
        Boolean stop = false;            String espai;
        String guions = "-".repeat(maxAllargadaPreg + 1) + "+-";
        String linia = "";
        fila0[segIdPreg] = "Cluster"; //per indicar a quin cluster pertany
        for (int n = 0; n < getNumPreguntes() + 2; n = n + 1) linia += guions; 
        linia = linia.substring(0, linia.length()-1); //eliminar ultim guio
        for (int i = 0; !stop && i < MAX_USUARIS; ++i) {
            for (int j = 0; !stop && j < MAX_PREGUNTES; ++j) {
                if (i == 0) {
                    if (fila0[j] != null) {
                        int num_espais = (1 + maxAllargadaPreg) - fila0[j].length();
                        espai = " ".repeat(num_espais);
                        System.out.print(fila0[j] + espai + "| ");
                    }
                }
                else {
                    if (j == 0) {
                        if (columna0[i] != null) {
                            int num_espais = (1 + maxAllargadaPreg) - columna0[i].length();
                            espai = " ".repeat(num_espais);
                            System.out.print(columna0[i] + espai + "| ");
                        }
                        else stop = true;
                    }
                    else if (j == segIdPreg) { //cluster
                        if (columnaClusters[j] == null) {
                            int num_espais = (1 + maxAllargadaPreg) - 4;
                            espai = " ".repeat(num_espais);
                            System.out.print("NULL" + espai + "| ");
                        }
                        else {
                            int num_espais = (1 + maxAllargadaPreg) - columnaClusters[i - 1].length();
                            espai = " ".repeat(num_espais);
                            System.out.print(columnaClusters[i - 1] + espai + "| ");
                        }
                            
                    }
                    else {
                        if (respostesCompletes[i-1][j-1] != null) {
                            int num_espais = (1 + maxAllargadaPreg) - respostesCompletes[i-1][j-1].getRespostaText().length();
                            espai = " ".repeat(num_espais);
                            System.out.print(respostesCompletes[i-1][j-1].getRespostaText() + espai + "| ");
                        }
                        else if (fila0[j] != null) {
                            int num_espais = (1 + maxAllargadaPreg) - 4;
                            espai = " ".repeat(num_espais);
                            System.out.print("NULL" + espai + "| ");
                        }
                    }
                }
            }
            System.out.println();
            if (!stop) {
                System.out.println(linia);
            }
        }
        fila0[segIdPreg] = null; //treiem cluster
        System.out.println("Valor Coeficient de Silhouette: " + cSil);
    }

    /** @brief Permet obtenir les respostes registrades de la gent en format matriu de Strings.*/
    public String[][] getPerPantalla() 
    {
        String[][] resultatsPantalla = new String[segIdFila][segIdPreg];
        Boolean stop = false;

        for (int i = 0; !stop && i < MAX_USUARIS; ++i) {
            for (int j = 0; !stop && j < MAX_PREGUNTES; ++j) {
                if (i == 0) {
                    if (fila0[j] != null) {
                        resultatsPantalla[i][j] = fila0[j];
                    }
                }
                else {
                    if (j == 0) {
                        if (columna0[i] != null) {
                            resultatsPantalla[i][j] = columna0[i];
                        }
                        else stop = true;
                    }
                    else if (j == segIdPreg) { //cluster
                        if (columnaClusters[j] == null) {
                            resultatsPantalla[i][j] = "NULL";
                        }
                        else {
                            resultatsPantalla[i][j] = columnaClusters[i - 1];
                        }
                            
                    }
                    else {
                        if (respostesCompletes[i-1][j-1] != null) {
                            resultatsPantalla[i][j] = respostesCompletes[i-1][j-1].getRespostaText();
                        }
                        else if (fila0[j] != null) {
                            resultatsPantalla[i][j] = "NULL";
                        }
                    }
                }
            }
        }

        return resultatsPantalla;
    }
   
    /** @brief Retorna el valor del coeficient de Silhouette calculat. */
    public float getSilhouette() {
        return cSil;
    }
}