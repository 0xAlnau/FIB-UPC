package FONTS.Domini;

/**
 * @class KmeansPlus
 * @brief Implementació de l'algoritme de clustering k-means amb inicialització k-means++.
 *
 * @details Aquesta classe especialitza {@link AnalisiCluster} i executa
 *          l'algoritme k-means utilitzant l'estratègia d'inicialització
 *          k-means++, la qual selecciona centroides inicials més separats
 *          entre si per millorar la qualitat i la velocitat de convergència.
 */
public class KmeansPlus extends AnalisiCluster {

    /**
     * @brief Constructor que executa l'algoritme k-means amb inicialització k-means++.
     *
     * @param r Matriu de respostes de l'enquesta.
     * @param l Nombre de clusters (k).
     * @param nR Nombre total de respostes.
     * @param nP Nombre total de preguntes.
     *
     * @details El procés consta de les fases següents:
     *          1. Inicialització dels centroides mitjançant k-means++.
     *          2. Assignació iterativa de les respostes al centroide més proper.
     *          3. Recalcul dels centroides mitjançant la mitjana de les respostes assignades.
     *          4. Repetició del procés fins a assolir la convergència.
     *
     *          L’ús de k-means++ redueix la dependència de la inicialització
     *          aleatòria i sol produir clusters més estables.
     *
     * @throws InvalidClusterException Si es produeix algun error durant el clustering.
     * @throws InvalidRespostaException Si alguna resposta és invàlida.
     */
    public KmeansPlus(RespostaInd[][] r, int l, int nR, int nP) throws InvalidClusterException, InvalidRespostaException {
        super(r,l,nR,nP);
        initializeKmeans(); 

        boolean canvis = true;
        while(canvis) {
            canvis = false;
            canvis = assignar();
            updateCentroidsKmeans();
        }
    }
}
