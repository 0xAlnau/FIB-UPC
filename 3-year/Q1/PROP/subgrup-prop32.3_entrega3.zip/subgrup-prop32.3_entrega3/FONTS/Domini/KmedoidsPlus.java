package FONTS.Domini;

/**
 * @class KmedoidsPlus
 * @brief Implementació de l'algoritme de clustering k-medoids amb inicialització k-means++.
 *
 * @details Aquesta classe especialitza {@link AnalisiCluster} i implementa
 *          l'algoritme k-medoids utilitzant una estratègia d'inicialització
 *          basada en k-means++, amb l'objectiu d'obtenir medoids inicials
 *          més ben separats i millorar la convergència de l'algoritme.
 *
 *          Tot i que l'algoritme final és k-medoids, la inicialització
 *          s'inspira en k-means++ per seleccionar punts inicials representatius.
 */
public class KmedoidsPlus extends AnalisiCluster {
    /**
     * @brief Constructor que executa l'algoritme k-medoids amb inicialització millorada.
     *
     * @param r Matriu de respostes de l'enquesta.
     * @param l Nombre de clusters (k).
     * @param nR Nombre total de respostes.
     * @param nP Nombre total de preguntes.
     *
     * @details El procés consta de les fases següents:
     *          1. Inicialització dels medoids mitjançant una estratègia inspirada en k-means++.
     *          2. Assignació de cada resposta al medoid més proper.
     *          3. Actualització dels medoids seleccionant les respostes que minimitzen
     *             la distància total dins de cada cluster.
     *          4. Repetició del procés fins a assolir la convergència.
     *
     *          Aquesta variant redueix la dependència de la inicialització aleatòria
     *          i pot produir clusters més estables que el k-medoids clàssic.
     *
     * @throws InvalidClusterException Si es produeix algun error durant el clustering.
     * @throws InvalidRespostaException Si alguna resposta és invàlida.
     */
    public KmedoidsPlus(RespostaInd[][] r, int l, int nR, int nP) throws InvalidClusterException, InvalidRespostaException {
        super(r,l,nR,nP);
        initializeKmeans(); 

        boolean canvis = true;
        while(canvis) {
            canvis = false;
            canvis = assignar();
            updateCentroidsKmedoids();
        }
    }
}
