package FONTS.Domini;

/**
 * @class InicialitzacioKmeansPlus
 * @brief Inicialització del clustering mitjançant l'estratègia k-means++.
 *
 * @details Aquesta classe especialitza {@link AnalisiCluster} i s’encarrega
 *          exclusivament de realitzar una inicialització dels centroides
 *          basada en l’algoritme k-means++, seguida d’una primera assignació
 *          de les respostes als clusters.
 *
 *          Aquest mètode d’inicialització millora la separació inicial
 *          dels centroides respecte a la inicialització aleatòria i redueix
 *          la probabilitat de convergir cap a solucions locals pobres.
 */
public class InicialitzacioKmeansPlus extends AnalisiCluster {

    /**
     * @brief Constructor que executa una inicialització k-means++ del clustering.
     *
     * @param r Matriu de respostes de l'enquesta.
     * @param l Nombre de clusters (k).
     * @param nR Nombre total de respostes.
     * @param nP Nombre total de preguntes.
     *
     * @details El procés consta de les fases següents:
     *          1. Selecció dels centroides inicials utilitzant k-means++.
     *          2. Assignació inicial de totes les respostes al cluster més proper.
     *
     *          Aquesta classe no realitza el procés iteratiu complet de clustering,
     *          sinó que proporciona un estat inicial òptim per a altres algorismes.
     *
     * @throws InvalidClusterException Si es produeix algun error durant la inicialització.
     * @throws InvalidRespostaException Si alguna resposta és invàlida.
     */
    public InicialitzacioKmeansPlus(RespostaInd[][] r, int l, int nR, int nP) throws InvalidClusterException, InvalidRespostaException {
        super(r,l,nR,nP);
        initializeKmeans(); 
        assignar(); 
    }
    
}
