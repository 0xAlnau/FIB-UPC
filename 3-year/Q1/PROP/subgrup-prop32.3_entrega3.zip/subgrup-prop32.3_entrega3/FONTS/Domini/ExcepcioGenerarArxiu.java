 /*
    +----------------------------------------------------------+
    |                ExcepcioObrirArxiuJava.java               |
    +----------------------------------------------------------+ 
    | Repositori:                                              |
    |   ·subgrup-prop32.3                                      |
    +----------------------------------------------------------+
    | Aquest mòdul ha sigut programat per:                     |
    |   ·Arnau Cullell Martínez                                |
    +----------------------------------------------------------+
    | *Versió 1.0: permet generar una excepció quan no es      | 
    |             genera correctament l'arxiu .csv a l'exportar|
    |              una enquesta.                               |
    |                                                          |
    +----------------------------------------------------------+
  */
package FONTS.Domini;
public class ExcepcioGenerarArxiu extends Exception
{
    private String nom_arxiu;

    public ExcepcioGenerarArxiu(String nom_arxiu)
    {
        super("·Error: no s'ha pogut generar el fitxer '" + nom_arxiu + ".csv' correctament.");
        this.nom_arxiu = nom_arxiu;
    }

    public String toString() 
    {
        return "·Excepció al generar el fitxer " + nom_arxiu + ".csv";
    }
}