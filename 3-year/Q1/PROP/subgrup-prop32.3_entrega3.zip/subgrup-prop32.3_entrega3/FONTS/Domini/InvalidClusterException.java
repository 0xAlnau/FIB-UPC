/*
    +----------------------------------------------------------+
    |                InvalidClusterException.java              |
    +----------------------------------------------------------+
    | Repositori:                                              |
    |   ·subgrup-prop32.3                                      |
    +----------------------------------------------------------+
    | Aquest mòdul ha sigut programat per:                     |
    |   · Angel Dominguez Buira                                |
    +----------------------------------------------------------+
    | Excepció per indicar errors en la configuració o         |
    | execució del clustering                                   |
    +----------------------------------------------------------+
*/



/** @file InvalidClusterException.java
    @brief Excepció per a errors relacionats amb clustering.
*/

package FONTS.Domini;

/** @class InvalidClusterException
    @brief Excepció llançada quan hi ha errors en la configuració o execució del clustering.
   
    Aquesta excepció s'utilitza per indicar:
    - Nombre de clusters invàlid (k <= 0 o k > nombre de respostes)
    - Dades insuficients per realitzar clustering
    - Matriu de respostes buida o nul·la
    - Errors durant l'execució de l'algoritme k-means
*/
public class InvalidClusterException extends Exception {
   
    /** @brief Constructora per defecte.
     */
    public InvalidClusterException() {
        super();
    }
   
    /** @brief Constructora amb missatge.
     * @param s El missatge d'error explicatiu.
     */
    public InvalidClusterException(String s) {
        super(s);
    }
   
    /** @brief Constructora amb missatge i causa.
     * @param s El missatge d'error explicatiu.
     * @param cause La causa original de l'error.
     */
    public InvalidClusterException(String s, Throwable cause) {
        super(s, cause);
    }
}