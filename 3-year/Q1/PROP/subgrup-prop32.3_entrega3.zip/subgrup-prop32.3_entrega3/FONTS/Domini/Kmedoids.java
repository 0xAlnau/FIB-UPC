package FONTS.Domini;

/**
 * @class Kmedoids
 * @brief Implementació de l'algoritme de clustering k-medoids.
 *
 * @details Aquesta classe especialitza {@link AnalisiCluster} i implementa
 *          l'algoritme k-medoids, una variant del k-means en què els centroides
 *          (medoids) són sempre respostes reals del conjunt de dades.
 *
 *          Aquest enfocament és més robust davant outliers i dades no
 *          estrictament numèriques, ja que es basa exclusivament en distàncies.
 */
public class Kmedoids extends AnalisiCluster {
    
    /**
     * @brief Constructor que executa l'algoritme k-medoids.
     *
     * @param r Matriu de respostes de l'enquesta.
     * @param l Nombre de clusters (k).
     * @param nR Nombre total de respostes.
     * @param nP Nombre total de preguntes.
     *
     * @details El procés consta de les fases següents:
     *          1. Inicialització aleatòria dels medoids.
     *          2. Assignació de cada resposta al medoid més proper.
     *          3. Actualització dels medoids seleccionant la resposta que
     *             minimitza la distància total dins de cada cluster.
     *          4. Repetició fins que no hi hagi canvis en les assignacions.
     *
     * @throws InvalidClusterException Si es produeix algun error durant el clustering.
     * @throws InvalidRespostaException Si alguna resposta és invàlida.
     */
    public Kmedoids(RespostaInd[][] r, int l, int nR, int nP) throws InvalidClusterException, InvalidRespostaException {
        super(r,l,nR,nP);
        initializeRandom(); 

        boolean canvis = true;
        while(canvis) {
            canvis = false;
            canvis = assignar();
            updateCentroidsKmedoids();
        }
    }
}
