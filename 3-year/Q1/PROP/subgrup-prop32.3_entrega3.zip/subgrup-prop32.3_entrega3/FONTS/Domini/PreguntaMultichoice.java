/*    +----------------------------------------------------------+
      |               PreguntaMultichoice.java                   |
      +----------------------------------------------------------+
      | Repositori:                                              |
      |   ·subgrup-prop32.3                                      |
      +----------------------------------------------------------+
      | Aquest mòdul ha sigut programat per:                     |
      |   ·Santiago Lluzar                                       |
      +----------------------------------------------------------+
      | Versió 1.0 : package FONTS;                              |
      +----------------------------------------------------------+
*/

/** @file PreguntaMultichoice.java
    @brief Codi de la classe PreguntaMultichoice.
*/


package FONTS.Domini;
import java.util.List;


/** @class PreguntaMultichoice
    @brief Representa una pregunta d'opció múltiple.
    Correspon a la classe 'Multichoice' del diagrama UML.
*/
public class PreguntaMultichoice extends Pregunta {

    /** @brief Llista d'opcions de resposta possibles.*/
    private List<String> opcions;

    /** @brief Límit d'opcions que es poden seleccionar.*/
    private int limitOpcions;

    /** @brief Constructor per a una pregunta d'opció múltiple.
     * @param text El text de la pregunta.
     * @param opcions La llista d'opcions.
     * @param limitOpcions El nombre màxim d'opcions a seleccionar.
     * @throws InvalidPreguntaException Si el text és invàlid (a la superclasse), la llista d'opcions és nul·la/buida o el límit és invàlid.
     */
    public PreguntaMultichoice(String text, List<String> opcions, int limitOpcions) throws InvalidPreguntaException {
        super(text, TipusPregunta.MULTICHOICE);
        
        if (opcions == null || opcions.isEmpty()) {
            throw new InvalidPreguntaException("La llista d'opcions no pot ser nul·la o buida.");
        }
        if (limitOpcions <= 0) {
             throw new InvalidPreguntaException("El límit d'opcions ha de ser positiu major a 0.");
        }
        if (limitOpcions > opcions.size()) {
            throw new InvalidPreguntaException("El límit d'opcions (" + limitOpcions + ") no pot ser més gran que el nombre d'opcions (" + opcions.size() + ").");
        }
        
        this.opcions = opcions;
        this.limitOpcions = limitOpcions;
    }
    /** @brief Consultora de les opcions.
     * @return La llista d'opcions.
     */
    public List<String> getOpcions() {
        return opcions;
    }

    /** @brief Consultora del límit d'opcions.
     * @return El nombre màxim d'opcions seleccionables.
     */
    public int getLimitOpcions() {
        return limitOpcions;
    }
}