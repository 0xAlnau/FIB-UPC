/*    +----------------------------------------------------------+
      |               InvalidRespostaException.java              |
      +----------------------------------------------------------+
      | Repositori:                                              |
      |   ·subgrup-prop32.3                                      |
      +----------------------------------------------------------+
      | Aquest mòdul ha sigut programat per:                     |
      |   ·Santiago Lluzar                                       |
      +----------------------------------------------------------+
      | Versió 1.0 : package FONTS;                              |
      +----------------------------------------------------------+
*/

/** @file InvalidRespostaException.java
    @brief Codi de l'excepció InvalidRespostaException.
*/

/** @class InvalidRespostaException
    @brief Excepció pròpia per a errors en la creació o validació de Respostes.
    Hereda d'Exception, per la qual cosa és una 'checked exception'.
*/
package FONTS.Domini;
public class InvalidRespostaException extends Exception {
    
    /** @brief Constructora per defecte.
     */
    public InvalidRespostaException() {
        super();
    }
    
    /** @brief Constructora amb missatge.
     * @param s El missatge d'error explicatiu.
     */
    public InvalidRespostaException(String s) {
        super(s);
    }
}