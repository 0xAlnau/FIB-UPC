 /*
    +----------------------------------------------------------+
    |                ExcepcioObrirArxiuJava.java               |
    +----------------------------------------------------------+ 
    | Repositori:                                              |
    |   ·subgrup-prop32.3                                      |
    +----------------------------------------------------------+
    | Aquest mòdul ha sigut programat per:                     |
    |   ·Arnau Cullell Martínez                                |
    +----------------------------------------------------------+
    | *Versió 1.0: permet generar una excepció quan no s'obre  |
    |              correctament un arxiu .csv a Enquesta.      |
    |                                                          |
    +----------------------------------------------------------+
  */
package FONTS.Domini;
public class ExcepcioObrirArxiu extends Exception
{
    private String nom_arxiu;

    public ExcepcioObrirArxiu(String nom_arxiu)
    {
        super("·Error: no s'ha pogut obrir el fitxer '" + nom_arxiu + ".csv' correctament.");
        this.nom_arxiu = nom_arxiu;
    }

    public String toString() 
    {
        return "·Excepció a l'obrir el fitxer " + nom_arxiu + ".csv";
    }
}