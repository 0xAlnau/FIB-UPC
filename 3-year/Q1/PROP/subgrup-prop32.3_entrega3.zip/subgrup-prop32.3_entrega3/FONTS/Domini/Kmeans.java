package FONTS.Domini;

/**
 * @class Kmeans
 * @brief Implementació de l'algoritme de clustering k-means.
 *
 * @details Aquesta classe especialitza la classe {@link AnalisiCluster}
 *          i executa l'algoritme clàssic k-means. Els centroides s'inicialitzen
 *          de manera aleatòria i es recalculen iterativament com la mitjana
 *          de les respostes assignades fins assolir la convergència.
 */
public class Kmeans extends AnalisiCluster{

    /**
     * @brief Constructor que executa l'algoritme k-means.
     *
     * @param r Matriu de respostes de l'enquesta.
     * @param l Nombre de clusters (k).
     * @param nR Nombre total de respostes.
     * @param nP Nombre total de preguntes.
     *
     * @details El procés consta de les fases següents:
     *          1. Inicialització aleatòria dels centroides.
     *          2. Assignació iterativa de les respostes al centroide més proper.
     *          3. Recalcul dels centroides mitjançant la mitjana de les respostes.
     *          4. Repetició fins que no hi hagi canvis en les assignacions.
     *
     * @throws InvalidClusterException Si es produeix algun error durant el clustering.
     * @throws InvalidRespostaException Si alguna resposta és invàlida.
     */
    public Kmeans(RespostaInd[][] r, int l, int nR, int nP) throws InvalidClusterException, InvalidRespostaException {
        super(r,l,nR,nP);
        initializeRandom(); 

        boolean canvis = true;
        while(canvis) {
            canvis = false;
            canvis = assignar();
            updateCentroidsKmeans();
        }
    }
}
