/*    +----------------------------------------------------------+
      |               InvalidPreguntaException.java              |
      +----------------------------------------------------------+
      | Repositori:                                              |
      |   ·subgrup-prop32.3                                      |
      +----------------------------------------------------------+
      | Aquest mòdul ha sigut programat per:                     |
      |   ·Santiago Lluzar                                       |
      +----------------------------------------------------------+
      | Versió 1.0 : package FONTS;                              |
      +----------------------------------------------------------+
*/

/** @file InvalidPreguntaException.java
    @brief Codi de l'excepció InvalidPreguntaException.
*/

/** @class InvalidPreguntaException
    @brief Excepció pròpia per a errors en la creació o validació de Preguntes.
    Hereda d'Exception, per la qual cosa és una 'checked exception'.
*/
package FONTS.Domini;

public class InvalidPreguntaException extends Exception {
    
    /** @brief Constructora per defecte.
     */
    public InvalidPreguntaException() {
        super();
    }
    
    /** @brief Constructora amb missatge.
     * @param s El missatge d'error explicatiu.
     */
    public InvalidPreguntaException(String s) {
        super(s);
    }
}
