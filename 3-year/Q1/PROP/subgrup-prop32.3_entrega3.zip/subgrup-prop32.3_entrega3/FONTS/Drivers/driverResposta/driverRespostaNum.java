/*    +----------------------------------------------------------+
      |                 driverRespostaNum.java                   |
      +----------------------------------------------------------+
      | Repositori:                                              |
      |   ·subgrup-prop32.3                                      |
      +----------------------------------------------------------+
      | Aquest mòdul ha sigut programat per:                     |
      |   ·Santiago Lluzar                                       |
      +----------------------------------------------------------+
      | *Versió 1.1: Driver JUnit per a RespostaNum.             |
      |              Prova el constructor, la distància i        |
      |              la clonació.                                |
      +----------------------------------------------------------+
*/

package FONTS.Drivers.driverResposta;

import FONTS.Domini.*; 
import static org.junit.Assert.*;
import org.junit.Test;
import java.util.Set;
import java.util.HashSet;
import java.util.List;
import java.util.ArrayList;

/** @class driverRespostaNum
    @brief Driver de JUnit per a la classe RespostaNum.
*/
public class driverRespostaNum {

    // Stub per a preguntes numèriques (cas vàlid)
    private PreguntaLliure crearPreguntaStub() throws InvalidPreguntaException {
        return new PreguntaLliure("Pregunta Stub Numèrica", 20, true);
    }

    // Stub per a preguntes de text (cas invàlid)
    private PreguntaLliure crearPreguntaTextStub() throws InvalidPreguntaException {
        return new PreguntaLliure("Pregunta Stub Text", 20, false);
    }

//--------------------COMPROVAR LA SUPERCLASSE---------------------------

    @Test(expected = InvalidRespostaException.class)
    public void testConstructorIdUsuariNull() throws Exception {
        // Comprova (idUsuari == null...)
        new RespostaNum(crearPreguntaStub(), null, 10.0f);
    }

    @Test(expected = InvalidRespostaException.class)
    public void testConstructorPreguntaNull() throws Exception {
        // Comprova (preguntaAssociada == null)'
        new RespostaNum(null, "usuari1", 10.0f);
    }

//------------------------------------------------------------------------
    
    @Test
    public void testConstructorCasValid() throws InvalidPreguntaException, InvalidRespostaException {
        PreguntaLliure pStub = crearPreguntaStub();
        RespostaNum r = new RespostaNum(pStub, "usuari1", 10.5f);
        assertEquals(10.5f, r.getValor(), 0.001); 
    }
    
    @Test(expected = InvalidRespostaException.class)
    public void testConstructorPreguntaIncorrecta() throws InvalidPreguntaException, InvalidRespostaException {
        // Cas erroni: intentem crear RespostaNum amb una Pregunta de text
        PreguntaLliure pTextStub = crearPreguntaTextStub();
        new RespostaNum(pTextStub, "usuari1", 10.5f);
    }

    @Test
    public void testCalcularDistanciaNormal() throws InvalidRespostaException, InvalidPreguntaException {
        PreguntaLliure pStub = crearPreguntaStub();
        RespostaNum r1 = new RespostaNum(pStub, "u1", 100f);
        RespostaNum r2 = new RespostaNum(pStub, "u2", 80f);
        
        // Comprova que retorna la distància absoluta (sense normalitzar)
        assertEquals(20.0f, r1.calcularDistancia(r2), 0.001);
    }
    
    @Test
    public void testCalcularDistanciaTipusDiferent() throws Exception {
        RespostaNum rNum = new RespostaNum(crearPreguntaStub(), "u1", 100f);
        RespostaText rText = new RespostaText(crearPreguntaTextStub(), "u2", "hola");
        
        // Cas erroni: comparar tipus diferents
        assertEquals(RespostaInd.DISTANCIA_INFINITA, rNum.calcularDistancia(rText), 0.001);
    }

    @Test
    public void testCalcularDistanciaMateixValor() throws Exception {
        PreguntaLliure pStub = crearPreguntaStub();
        RespostaNum r1 = new RespostaNum(pStub, "u1", 50.5f);
        RespostaNum r2 = new RespostaNum(pStub, "u2", 50.5f);
        
        // Cas límit: distància entre dos valors iguals
        assertEquals(0.0f, r1.calcularDistancia(r2), 0.001);
    }

    @Test
    public void testCalcularDistanciaAmbNul() throws Exception {
        PreguntaLliure pStub = crearPreguntaStub();
        RespostaNum r1 = new RespostaNum(pStub, "u1", 50.5f);
        
        // Cas erroni: comparar amb null
        assertEquals(RespostaInd.DISTANCIA_INFINITA, r1.calcularDistancia(null), 0.001);
    }

    @Test
    public void testClone() throws InvalidRespostaException, InvalidPreguntaException {
        RespostaNum original = new RespostaNum(crearPreguntaStub(), "u1", 123.4f);
        RespostaNum clon = (RespostaNum) original.clone();
        
        assertNotSame(original, clon); // Són objectes diferents
        assertEquals(original.getValor(), clon.getValor(), 0.001); // Tenen el mateix valor
        
        // Comprova que són independents
        clon.setValor(500f);
        assertNotEquals(original.getValor(), clon.getValor(), 0.001);
    }
}