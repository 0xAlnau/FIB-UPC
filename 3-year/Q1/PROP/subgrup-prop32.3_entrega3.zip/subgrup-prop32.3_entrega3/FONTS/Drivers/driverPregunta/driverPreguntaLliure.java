/*    +----------------------------------------------------------+
      |               driverPreguntaLliure.java                  |
      +----------------------------------------------------------+
      | Repositori:                                              |
      |   ·subgrup-prop32.3                                      |
      +----------------------------------------------------------+
      | Aquest mòdul ha sigut programat per:                     |
      |   ·Santiago Lluzar                                       |
      +----------------------------------------------------------+
      | *Versió 1.0: Driver JUnit per a PreguntaLliure.          |
      |              Prova casos normals i erronis               |
      |              del constructor.                            |
      +----------------------------------------------------------+
*/
package FONTS.Drivers.driverPregunta;

import FONTS.Domini.*; 
import static org.junit.Assert.*;
import org.junit.Test;
import java.util.List; 
import java.util.ArrayList;

/** @class driverPreguntaLliure
    @brief Driver de JUnit per a la classe PreguntaLliure.
*/
public class driverPreguntaLliure {

//--------------------COMPROVAR LA SUPERCLASSE (Pregunta)--------------------

    @Test(expected = InvalidPreguntaException.class)
    public void testConstructorTextBuit() throws InvalidPreguntaException {
        // Comprova if (text.trim().isEmpty())
        new PreguntaLliure("   ", 3, true); 
    }

    @Test(expected = InvalidPreguntaException.class)
    public void testConstructorTextNul() throws InvalidPreguntaException {
        // Comprova if (text == null ...)
        new PreguntaLliure(null, 3, true); 
    }

//------------------------------------------------------------------------

    @Test
    public void testConstructorCasValid() throws InvalidPreguntaException {
        // Cas normal: comprova que no llança excepció i els atributs
        PreguntaLliure preg = new PreguntaLliure("Quina edat tens?", 3, true);
        
        assertNotNull(preg); // Comprovem que l'objecte s'ha creat
        
        // Comprovem els atributs implícitament (provant els getters)
        assertEquals("Quina edat tens?", preg.getText());
        assertEquals(TipusPregunta.LLIURE, preg.getTipus());
        assertEquals(3, preg.getNumMaxCaracters());
        assertTrue(preg.esNumerica());
    }

    @Test(expected = InvalidPreguntaException.class)
    public void testConstructorCaractersZero() throws InvalidPreguntaException {
        // Cas erroni: numMaxCaracters és invàlid
        new PreguntaLliure("Pregunta", 0, true); // Límit 0
    }
    
    @Test(expected = InvalidPreguntaException.class)
    public void testConstructorCaractersNegatius() throws InvalidPreguntaException {
        // Cas erroni: numMaxCaracters és invàlid
        new PreguntaLliure("Pregunta", -5, true); // Límit negatiu
    }
}