/*    +----------------------------------------------------------+
      |               driverUsuari.java                          |
      +----------------------------------------------------------+
      | Repositori:                                              |
      |   ·subgrup-prop32.3                                      |
      +----------------------------------------------------------+
      | Aquest mòdul ha sigut programat per:                     |
      |   ·Gabriel Alegre Conchello                              |
      +----------------------------------------------------------+
      | *Versió 1.2: Imports corregits i                         |
      |              adaptat a mètodes no estàtics.              |
      |                                                          |
      +----------------------------------------------------------+
*/

package FONTS.Drivers.driverUsuari;

import FONTS.Domini.*;

import static org.junit.Assert.*;
import org.junit.Test;

import java.util.Set;
import java.util.HashMap;     
import java.util.ArrayList;     
import org.junit.Before;       
import static org.junit.Assert.fail; 


public class driverUsuari {

    private Usuari u;
    private Usuari adminStub;
    private Enquesta e1; 
    private Enquesta e2; 

    // Aquest mètode s'executa abans de cada test
    @Before 
    public void setUp() {
        u = new Usuari("NombrePrueba", "1234");
        
        // Creem un usuari admin "fals" per ser el propietari de les enquestes
        adminStub = new Usuari("AdminUser", "adminpass");
        
        try {
            // Creem enquestes "falses" per poder passar-les com a paràmetre
            e1 = new Enquesta("Enquesta1", adminStub, 3);
            e2 = new Enquesta("Enquesta2", adminStub, 3);
        } catch (Exception e) {
            fail("El setup de les proves ha fallat: " + e.getMessage());
        }
        
        // Neteja de les enquestes de 'u'
        Set<String> titols = u.getTitulosEnquesta();
        // Fem una còpia per evitar ConcurrentModificationException
        for (String titol : new ArrayList<>(titols)) { 
            u.eliminarEnquesta(titol);
        }
    }

    /**
     * Test de la contrasenya
     * Comprovem que checkPassword funciona per a casos correctes i incorrectes.
     */
    @Test
    public void testCheckPassword() {
        assertTrue(u.checkPassword("1234"));
        assertFalse(u.checkPassword("passworderroni"));
    }

    /**
     * Test d'existència d'enquesta
     * Comprovem que l'usuari pot trobar una enquesta que se li ha afegit.
     */
    @Test
    public void testExisteEnquesta() {
        u.crearEnquesta("T1", e1);
        assertTrue(u.existeEnquesta("T1"));
        assertFalse(u.existeEnquesta("TitolQueNoExisteix"));
    }

    /**
     * Test de creació d'una enquesta.
     * Comprovem que després de cridar crearEnquesta, el títol apareix a la llista.
     */
    @Test
    public void testCrearEnquesta() {
        u.crearEnquesta("Enquesta1", e1); 
        Set<String> titulos = u.getTitulosEnquesta();
        assertTrue(titulos.contains("Enquesta1"));
    }

    /**
     * Test d’eliminació d’una enquesta.
     * Afegim una enquesta, la eliminem i comprovem que ja no apareix.
     */
    @Test
    public void testEliminarEnquesta() {
        u.crearEnquesta("Enquesta1", e1); 
        u.eliminarEnquesta("Enquesta1");

        Set<String> titulos = u.getTitulosEnquesta();
        assertFalse(titulos.contains("Enquesta1"));
    }

    /**
     * Test de llistar enquestes.
     * Com que llistarEnquestes imprimeix per pantalla, redirigim la sortida.
     */
    @Test
    public void testListarEnquestes() {
        u.crearEnquesta("Enquesta1", e1); 
        u.crearEnquesta("Enquesta2", e2); 

        // Redirigir System.out para capturar la salida
        java.io.ByteArrayOutputStream outContent = new java.io.ByteArrayOutputStream();
        java.io.PrintStream originalOut = System.out;
        System.setOut(new java.io.PrintStream(outContent));

        u.listarEnquestes(); 

        System.setOut(originalOut);

        String output = outContent.toString();
        assertTrue(output.contains("Enquesta1"));
        assertTrue(output.contains("Enquesta2"));
    }

    /** Test getTitulosEnquesta
     * Comprovem que retorna els titols de les enquestes creades.*/
    @Test
    public void testGetTitulos() {
        HashMap<String, Enquesta> map = new HashMap<>(); 
        map.put("T1", e1);
        map.put("T2", e2);

        u.setEnquestes(map);

        Set<String> titols = u.getTitulosEnquesta(); 

        assertEquals(2, titols.size());
        assertTrue(titols.contains("T1"));
        assertTrue(titols.contains("T2"));
    }

    /** Test getTitulosEnquesta si el map és buit*/
    @Test
    public void testGetTitulosEnquestaBuida() {
        u.setEnquestes(new HashMap<>()); 
        Set<String> titols = u.getTitulosEnquesta(); 
        assertEquals(0, titols.size());
    }
}