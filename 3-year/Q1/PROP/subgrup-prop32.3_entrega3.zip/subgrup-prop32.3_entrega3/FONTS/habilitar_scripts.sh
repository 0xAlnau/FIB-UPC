#!/bin/bash

chmod +x compilar_tot.sh
sed -i 's/\r$//' compilar_tot.sh

chmod +x compilar_domini.sh
sed -i 's/\r$//' compilar_domini.sh

chmod +x compilar_drivers.sh
sed -i 's/\r$//' compilar_drivers.sh
