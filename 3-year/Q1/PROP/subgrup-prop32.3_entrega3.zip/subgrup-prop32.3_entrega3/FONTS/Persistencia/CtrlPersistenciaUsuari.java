package FONTS.Persistencia;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;

/*
    +----------------------------------------------------------+
    |               CtrlPersistenciaUsuari.java                |
    +----------------------------------------------------------+ 
    | Repositori:                                              |
    |   ·subgrup-prop32.3                                      |
    +----------------------------------------------------------+
    | Aquest mòdul ha sigut programat per:                     |
    |   ·Arnau Cullell Martínez                                |
    +----------------------------------------------------------+
    | *Versió 1.0: Gestió de la persistència d'usuaris.        |
    |                                                          |
    +----------------------------------------------------------+
  */

public class CtrlPersistenciaUsuari
{
    // Constructora
    /** @brief Creadora per defecte.*/
    public CtrlPersistenciaUsuari()
    {
        // Constructor buit
    }
    
    /** @brief Comprova si existeix el fitxer d'usuaris.*/
    public boolean existeixFitxerUsuaris(String path)
    {
        File f = new File(path);
        return f.exists() && !f.isDirectory();
    }

    /** @brief Carrega la llista d'usuaris des del fitxer especificat.*/
    public ArrayList<String> carregarUsuaris(String path) 
    {
        ArrayList<String> llista = new ArrayList<>();
        Path p = Paths.get(path);
        
        if (!existeixFitxerUsuaris(path)) {
            return llista;
        }

        try (BufferedReader br = Files.newBufferedReader(p, StandardCharsets.UTF_8)) {
            br.readLine(); 
            
            String linia;
            while ((linia = br.readLine()) != null) {
                if (!linia.trim().isEmpty()) {
                    llista.add(linia);
                }
            }
        }
        catch (IOException e) {
             System.err.println("Error d'E/S al carregar usuaris: " + e.getMessage());
        }
        return llista;
    }

    /**  @brief Guarda la llista d'usuaris al fitxer especificat.*/
    public void guardarUsuaris(String path, ArrayList<String> dadesUsuaris) 
    {
        Path p = Paths.get(path);
        
        try (BufferedWriter bw = Files.newBufferedWriter(p, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)) 
        {
            bw.write("Usuari,Password");
            bw.newLine();
            
            for(String linia : dadesUsuaris) {
                bw.write(linia);
                bw.newLine();
            }
        }
        catch (IOException e) {
            System.err.println("Error d'E/S al guardar usuaris: " + e.getMessage());
        }
    }
}