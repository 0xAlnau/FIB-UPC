package FONTS.Persistencia;

import java.io.File;
import java.util.ArrayList;
import java.util.Vector;

/*
    +----------------------------------------------------------+
    |                    CtrlPersistencia.java                 |
    +----------------------------------------------------------+ 
    | Repositori:                                              |
    |   ·subgrup-prop32.3                                      |
    +----------------------------------------------------------+
    | Aquest mòdul ha sigut programat per:                     |
    |   ·Arnau Cullell Martínez                                |
    +----------------------------------------------------------+
    | *Versió 1.0: Funcionalitats bàsiques fetes.              |
    |              bàsiques.                                   |
    |                                                          |
    +----------------------------------------------------------+
  */

public class CtrlPersistencia
{

    //Instancia de CtrlPersistenciaEnquesta i CtrlPersistenciaUsuari
    private final CtrlPersistenciaEnquesta ctrlPersistenciaEnquesta;
    private final CtrlPersistenciaUsuari ctrlPersistenciaUsuari;

    //Constructora
    /** @brief Creadora per defecte.*/
    public CtrlPersistencia()
    {
        this.ctrlPersistenciaEnquesta = new CtrlPersistenciaEnquesta();
        this.ctrlPersistenciaUsuari = new CtrlPersistenciaUsuari();
    }

    /** @brief Guarda una Enquesta en la carpeta Enquestes.*/
    public void guardarEnquesta(String path, int valorK, String[] admin, ArrayList<String> preguntes, ArrayList<ArrayList<String>> respostes)
    {    
        ctrlPersistenciaEnquesta.guardarEnquesta(path, valorK, admin, preguntes, respostes);
    }

    /** @brief Importa una Enquesta des de la carpeta Enquestes.*/
    public Vector<Vector<String>> carregarEnquesta(String path)
    {
        if (ctrlPersistenciaEnquesta.existeixEnquesta(path)) {
            return ctrlPersistenciaEnquesta.carregarEnquesta(path);
        } 
        else {
            System.err.println("Error: El fitxer " + path + " no existeix.");
            return null;
        }
    }

    /** @brief Elimina el fitxer físic d'una enquesta.*/
    public void eliminarEnquesta(String path) {
        ctrlPersistenciaEnquesta.eliminarFitxer(path);
    }

    /** @brief Exporta els usuaris al seu fitxer corresponent.*/
    public void guardarUsuaris(ArrayList<String> dadesUsuaris) {
        ctrlPersistenciaUsuari.guardarUsuaris("../FONTS/Persistencia/Usuaris/usuaris.csv", dadesUsuaris);
    }

    /** @brief Exporta els usuaris al seu fitxer corresponent.*/
    public ArrayList<String> carregarUsuaris() {
        return ctrlPersistenciaUsuari.carregarUsuaris("../FONTS/Persistencia/Usuaris/usuaris.csv");
    }
    
    /** @brief Per poder veure quins fitxers hi ha en un directori.*/
    public ArrayList<String> fitxersEnEnquestes() {
        ArrayList<String> arxius = new ArrayList<>();
        File folder = new File("../FONTS/Persistencia/Enquestes");
        File[] listOfFiles = folder.listFiles();

        if (listOfFiles != null) {
            for (File file : listOfFiles) {
                if (file.isFile() && file.getName().endsWith(".csv")) {
                    arxius.add(file.getName());
                }
            }
        }
        return arxius;
    }
}