package FONTS.Persistencia;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Vector;

/*
    +----------------------------------------------------------+
    |               CtrlPersistenciaEnquesta.java              |
    +----------------------------------------------------------+ 
    | Repositori:                                              |
    |   ·subgrup-prop32.3                                      |
    +----------------------------------------------------------+
    | Aquest mòdul ha sigut programat per:                     |
    |   ·Arnau Cullell Martínez                                |
    +----------------------------------------------------------+
    | *Versió 1.0: Funcionalitats bàsiques fetes.              |
    |              bàsiques.                                   |
    |                                                          |
    +----------------------------------------------------------+
  */

public class CtrlPersistenciaEnquesta
{
    //Constructora
    /** @brief Creadora per defecte.*/
    public CtrlPersistenciaEnquesta()
    {
        //no cal posar res
    }

    //Getters
    /** @brief Permet consultar si existeix l'enquesta demanada.*/
    public boolean existeixEnquesta(String path)
    {
        File f = new File(path);
        return f.exists() && !f.isDirectory();
    }

    /** @brief Retorna una matriu de Strings, on cada fila conte una fila del fitxer CSV.*/
    public Vector<Vector<String>> carregarEnquesta(String path)
    {
        Vector<Vector<String>> dades = new Vector<>();
        Path p = Paths.get(path);

        try (BufferedReader br = Files.newBufferedReader(p, StandardCharsets.UTF_8)) {
            String linia;
            while ((linia = br.readLine()) != null) {
                if (linia.trim().isEmpty()) {} //no cal fer res

                Vector<String> filaVector = new Vector<>();
                String[] camps = linia.split(",", -1);
                
                for (String camp : camps) {
                    filaVector.add(camp);
                }
                dades.add(filaVector);
            }
        } 
        catch (IOException e) {
            System.err.println("Error d'E/S al carregar l'enquesta': " + e.getMessage());
            return null;
        }
        return dades;
    } 

    //Modificadores
    /** @brief Agafa les dades en forma primitiva d'una Enquesta i la guarda en la carpeta Enquestes*/
    public void guardarEnquesta(String path, int valorK, String[] admin, ArrayList<String> preguntes, ArrayList<ArrayList<String>> respostes)
    {
        
        Path p = Paths.get(path);
        
        try (BufferedWriter bw = Files.newBufferedWriter(p, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)) {

            bw.write(String.valueOf(valorK)); //valor k
            bw.newLine();

            if (admin != null && admin.length >= 2) { //admin i contra
                bw.write(admin[0] + "," + admin[1]);
            }
            bw.newLine();

            StringBuilder sbHeaders = new StringBuilder(); //usuari,PReg1,Preg2,...,Cluster
            sbHeaders.append("Usuaris");
            for (String pregunta : preguntes) {
                sbHeaders.append(",").append(pregunta);
            }
            sbHeaders.append(",Cluster");
            bw.write(sbHeaders.toString());
            bw.newLine();

            for (ArrayList<String> filaUsuario : respostes) { //respostes
                StringBuilder sbRow = new StringBuilder();
                for (int i = 0; i < filaUsuario.size(); i++) {
                    String valor = filaUsuario.get(i);
                    if (valor == null) valor = "NULL";
                    
                    if (i == 0) sbRow.append(valor);
                    else sbRow.append(",").append(valor);
                }
                bw.write(sbRow.toString());
                bw.newLine();
            }

        } catch (IOException e) {
            System.err.println("Error d'E/S guardant l'enquesta': " + e.getMessage());
        }
    }
    
    /** @brief Elimina el fitxer de l'enquesta especificat pel path.*/
    public boolean eliminarFitxer(String path) {
        try {
            Path p = Paths.get(path);
            return Files.deleteIfExists(p);
        } catch (IOException e) {
            System.err.println("Error d'E/S eliminant l'enquesta: " + e.getMessage());
            return false;
        }
    }
}