/*
 +----------------------------------------------------------+
 |                VistaCrear.java                           |
 +----------------------------------------------------------+
 | Repositori:                                              |
 |   · subgrup-prop32.3                                     |
 +----------------------------------------------------------+
 | Aquest mòdul ha sigut programat per:                     |
 |   · Gabriel Alegre Conchello                             |
 |   · Santiago Lluzar Frias                                |
 +----------------------------------------------------------+
 */

package FONTS.Presentacio;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import FONTS.Presentacio.CtrlPresentacion;
import FONTS.Domini.InvalidPreguntaException;

/**
 * @file VistaCrear.java
 * @brief Vista gràfica per crear una nova enquesta.
 */

/**
 * @class VistaCrear
 * @brief Panell de la capa de presentació per a la creació de noves enquestes.
 *
 * @details Aquesta vista:
 *          - Permet configurar el títol i el nombre de clusters (K) per a l'enquesta.
 *          - Ofereix una interfície per afegir preguntes de tipus "Lliure" (text/numèrica).
 *          - Ofereix una interfície per afegir preguntes de tipus "Multichoice" (múltiples opcions).
 *          - Mostra una vista prèvia de les preguntes afegides.
 *          - Permet guardar l'enquesta completa al sistema.
 *          - Utilitza CardLayout per navegar entre els editors de preguntes.
 */
public class VistaCrear extends JPanel {

    /** @brief Controlador de presentació associat a la vista. */
    private CtrlPresentacion ctrl;

    /** @brief Camp de text per introduir el títol de l'enquesta. */
    private JTextField txtTitol;
        
    /** @brief Model de la llista visual de preguntes afegides. */
    private DefaultListModel<String> listModel;
    
    /** @brief Llista visual de preguntes afegides. */
    private JList<String> listaVisual;
    
    /** @brief Panel de l'editor de preguntes. */
    private JPanel panelEditor;

    /** @brief CardLayout per canviar entre tipus de preguntes. */
    private CardLayout cardLayout;
    
    /** @brief Components de l'editor de preguntes multichoice. */
    private JTextField txtEnunMulti;

    /** @brief Panel contenidor de les opcions dinàmiques. */
    private JPanel panelOpcionesContainer;

    /** @brief Llista de camps de text per a les opcions. */
    private List<JTextField> listaFieldsOpciones; 

    /** @brief Selector pel nombre màxim de seleccions en preguntes multichoice. */
    private JSpinner spinMaxSel;

    /** @brief Components de l'editor de preguntes lliures. */
    private JTextArea txtEnunLliure; 

    /** @brief Casella de verificació per indicar si la pregunta lliure és numèrica. */
    private JCheckBox checkNumerica;

    /** @brief Classe interna per representar una pregunta temporal abans de guardar. */
    private class PreguntaTemp {
        /** @brief Tipus de la pregunta: "lliure" o "multi". */
        String tipo;

        /** @brief Enunciat de la pregunta. */
        String enunciado;

        /** @brief Indica si la pregunta lliure accepta resposta numèrica. */
        boolean esNumerica;

        /** @brief Opcions per a preguntes de tipus multichoice. */
        List<String> opciones;

        /** @brief Nombre màxim de seleccions per a preguntes multichoice. */
        int maxSel;

        /** Pregunta de tipus lliure */
        PreguntaTemp(String e, boolean num) {
            this.tipo = "lliure"; this.enunciado = e; this.esNumerica = num;
        }
        /** Pregunta de tipus multichoice */
        PreguntaTemp(String e, List<String> ops, int max) {
            this.tipo = "multi"; this.enunciado = e; this.opciones = ops; this.maxSel = max;
        }
    }
    
    /** @brief Llista temporal de preguntes pendents de guardar. */
    private ArrayList<PreguntaTemp> preguntasPendientes;

    /**
     * @brief Constructor de la vista de creació d'enquesta.
     *
     * @param ctrl Controlador de presentació que gestiona la navegació
     *             entre les diferents vistes i la comunicació amb el domini.
     *
     * @details Inicialitza els components de la interfície gràfica amb:
     *          - Zona de configuració general (títol i clusters).
     *          - Zona de llista de preguntes afegides.
     *          - Zona d'editor de preguntes amb CardLayout.
     */
    public VistaCrear(CtrlPresentacion ctrl) {
        this.ctrl = ctrl;
        this.preguntasPendientes = new ArrayList<>();
        this.listaFieldsOpciones = new ArrayList<>();
        
        /* --- Disseny principal --- */
        setLayout(new GridBagLayout());
        setBackground(new Color(240, 242, 245));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0; 

        /* --- Zona A: Configuració General (15% altura) --- */
        gbc.gridy = 0; gbc.weighty = 0.15;
        gbc.insets = new Insets(10, 10, 10, 10);
        
        JPanel panelNorte = new JPanel(new GridBagLayout());
        panelNorte.setBackground(Color.WHITE);
        panelNorte.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        
        GridBagConstraints gn = new GridBagConstraints();
        gn.fill = GridBagConstraints.BOTH; gn.insets = new Insets(5, 10, 10, 10);
        
        JLabel lblHeaderConfig = new JLabel("Configuració General");
        lblHeaderConfig.setFont(new Font("SansSerif", Font.BOLD, 40));
        lblHeaderConfig.setForeground(Color.GRAY);
        gn.gridx=0; gn.gridy=0; gn.gridwidth=4; gn.weighty=0.6;
        panelNorte.add(lblHeaderConfig, gn);

        gn.gridy=1; gn.gridwidth=1; gn.weighty=0.4;
        
        JLabel lblTitol = new JLabel("Títol de l'Enquesta:");
        gn.gridx=0; gn.weightx=0.2; 
        lblTitol.setFont(new Font("SansSerif", Font.BOLD, 28));        
        panelNorte.add(lblTitol, gn);
        
        txtTitol = new JTextField();
        gn.gridx=1; gn.weightx=1; 
        txtTitol.setFont(new Font("SansSerif", Font.BOLD, 28));        
        panelNorte.add(txtTitol, gn);
                
        add(panelNorte, gbc);

        /* --- Zona B: Llista de Preguntes (40% altura) --- */
        gbc.gridy = 1; gbc.weighty = 0.40;
        gbc.insets = new Insets(5, 10, 5, 10);
        
        JPanel panelListaContainer = new JPanel(new GridBagLayout());
        panelListaContainer.setBackground(new Color(240, 242, 245)); 

        GridBagConstraints gl = new GridBagConstraints();
        gl.fill = GridBagConstraints.BOTH; gl.weightx = 1.0;
        
        JLabel lblHeaderLista = new JLabel("Preguntes Afegides (Previsualització)");
        lblHeaderLista.setFont(new Font("SansSerif", Font.BOLD, 28));
        lblHeaderLista.setForeground(new Color(60, 60, 60));
        
        gl.gridy=0; gl.weighty=0.1; gl.insets = new Insets(0, 0, 5, 0);
        panelListaContainer.add(lblHeaderLista, gl);

        listModel = new DefaultListModel<>();
        listaVisual = new JList<>(listModel);
        listaVisual.setFixedCellHeight(50);
        listaVisual.setFont(new Font("SansSerif", Font.PLAIN, 30));
        listaVisual.setBackground(new Color(250, 250, 250));
        
        JScrollPane scrollLista = new JScrollPane(listaVisual);
        scrollLista.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));

        gl.gridy=1; gl.weighty=0.9; gl.insets = new Insets(0, 0, 0, 0);
        panelListaContainer.add(scrollLista, gl);
        
        add(panelListaContainer, gbc);

        /* --- Zona C: Editor (45% altura) --- */
        gbc.gridy = 2; gbc.weighty = 0.45;
        gbc.insets = new Insets(5, 10, 10, 10);

        cardLayout = new CardLayout();
        panelEditor = new JPanel(cardLayout);
        panelEditor.setBackground(Color.WHITE);
        panelEditor.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(Color.LIGHT_GRAY, 1),
                new EmptyBorder(10, 10, 10, 10)
        ));

        panelEditor.add(crearCartaSelector(), "SELECTOR");
        panelEditor.add(crearCartaLliure(), "LLIURE");
        panelEditor.add(crearCartaMulti(), "MULTI");
        
        add(panelEditor, gbc);
    }

    /**
     * @brief Crea la carta de selecció de tipus de preguntes.
     *
     * @return JPanel amb els botons de navegació i d'acció principal.
     *
     * @details Aquesta carta mostra:
     *          - Botons per afegir preguntes lliures o multichoice.
     *          - Botó per guardar i finalitzar l'enquesta.
     *          - Botó per cancel·lar i tornar al menú.
     */
    private JPanel crearCartaSelector() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(Color.WHITE);
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH; 
        
        /* --- Botons superiors --- */
        c.weightx = 0.5; c.weighty = 0.5; 
        c.insets = new Insets(10, 10, 10, 10);

        JButton btnL = new JButton("+ Afegir Pregunta Lliure");
        btnL.addActionListener(e -> cardLayout.show(panelEditor, "LLIURE"));
        btnL.setFont(new Font("SansSerif", Font.BOLD, 28));
        c.gridx=0; c.gridy=0; p.add(btnL, c);

        JButton btnM = new JButton("+ Afegir Pregunta Multi");
        btnM.setFont(new Font("SansSerif", Font.BOLD, 28));
        btnM.addActionListener(e -> { limpiarFormularioMulti(); cardLayout.show(panelEditor, "MULTI"); });
        c.gridx=1; c.gridy=0; p.add(btnM, c);

        /* --- Botons inferiors --- */
        c.weighty = 0.15; 
        
        JButton btnSave = new JButton("GUARDAR I FINALITZAR");
        btnSave.setFont(new Font("SansSerif", Font.BOLD, 28));
        btnSave.setBackground(new Color(76, 175, 80)); 
        btnSave.setForeground(Color.WHITE);
        btnSave.addActionListener(e -> guardarEnquestaEnSistema());
        c.gridx=0; c.gridy=1; c.gridwidth=2; p.add(btnSave, c);

        JButton btnCancel = new JButton("Cancel·lar Tot");
        btnCancel.setForeground(Color.RED);
        btnCancel.setFont(new Font("SansSerif", Font.BOLD, 28));
        btnCancel.addActionListener(e -> { limpiarTodo(); ctrl.irAMenu(); });
        c.gridy=2; p.add(btnCancel, c);

        return p;
    }

    /**
     * @brief Crea la carta per introduir una pregunta lliure.
     *
     * @return JPanel amb els components per redactar i afegir una pregunta lliure.
     */
    private JPanel crearCartaLliure() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(Color.WHITE);
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH; c.insets = new Insets(5,5,5,5);
        c.weightx = 1.0;

        /* --- Títol de la carta --- */
        JLabel lbl = new JLabel("Nova Pregunta Lliure (Text / Numèrica)", SwingConstants.CENTER);
        lbl.setForeground(new Color(0, 120, 215)); 
        lbl.setFont(new Font("SansSerif", Font.BOLD, 32));
        c.gridx=0; c.gridy=0; c.gridwidth=2; c.weighty=0.1; p.add(lbl, c);

        /* --- Etiqueta de l'enunciat --- */
        JLabel lblEnun = new JLabel("Enunciat de la pregunta:");
        lblEnun.setFont(new Font("SansSerif", Font.BOLD, 28)); 
        c.gridy=1; c.weighty=0.05; p.add(lblEnun, c);

        /* --- Àrea de text per a l'enunciat --- */
        txtEnunLliure = new JTextArea();
        txtEnunLliure.setLineWrap(true);
        txtEnunLliure.setWrapStyleWord(true);
        txtEnunLliure.setFont(new Font("SansSerif", Font.PLAIN, 40));
        txtEnunLliure.setMargin(new Insets(10, 10, 10, 10)); 
        txtEnunLliure.setBorder(null); 
        
        
        JScrollPane scrollTxt = new JScrollPane(txtEnunLliure);
        scrollTxt.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        
        c.gridy=2; c.weighty=0.20; 
        c.insets = new Insets(5, 50, 5, 50); 
        p.add(scrollTxt, c);

        c.insets = new Insets(5, 5, 5, 5); 

        /* --- Casella de verificació per a resposta numèrica --- */
        checkNumerica = new JCheckBox("És una resposta numèrica? (Ex: Edat, Valoració 1-10)");
        checkNumerica.setBackground(Color.WHITE);
        checkNumerica.setFont(new Font("SansSerif", Font.PLAIN, 28));
        checkNumerica.setHorizontalAlignment(SwingConstants.CENTER);
        c.gridy=3; c.weighty=0.1; p.add(checkNumerica, c);

        /* --- Botons de confirmació --- */
        JPanel pBtns = new JPanel(new GridLayout(1, 2, 20, 0));
        pBtns.setBackground(Color.WHITE);
        JButton bOk = new JButton("Afegir a la llista");
        bOk.setFont(new Font("SansSerif", Font.BOLD, 28));
        bOk.setBackground(new Color(225, 245, 254)); 
        JButton bNo = new JButton("Enrere");
        bNo.setFont(new Font("SansSerif", Font.BOLD, 28));

        bOk.addActionListener(e -> confirmarPreguntaLliure());
        bNo.addActionListener(e -> cardLayout.show(panelEditor, "SELECTOR"));
        pBtns.add(bNo); pBtns.add(bOk);
        
        c.gridy=4; c.weighty=0.25;
        p.add(pBtns, c);
        
        return p;
    }

    /**
     * @brief Crea la carta per introduir una pregunta multichoice.
     *
     * @return JPanel amb els components per afegir opcions i configurar la pregunta multichoice.
     */
    private JPanel crearCartaMulti() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(Color.WHITE);
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH; c.weightx=1.0; c.insets = new Insets(5,5,5,5);

        /* --- Capçalera de preguntes multichoice --- */
        JPanel top = new JPanel(new GridBagLayout());
        top.setBackground(Color.WHITE);
        GridBagConstraints ct = new GridBagConstraints();
        ct.fill=GridBagConstraints.BOTH; ct.insets=new Insets(2,5,2,5);
        ct.weighty = 1.0;
        
        JLabel lblEnun = new JLabel("Enunciat:");
        lblEnun.setHorizontalAlignment(SwingConstants.RIGHT);
        lblEnun.setFont(new Font("SansSerif", Font.BOLD, 28));
        ct.gridx=0; ct.weightx=0.2; top.add(lblEnun, ct);
        
        txtEnunMulti = new JTextField();
        txtEnunMulti.setFont(new Font("SansSerif", Font.PLAIN, 28));
        ct.gridx=1; ct.weightx=0.5; top.add(txtEnunMulti, ct);
        
        JLabel lblMax = new JLabel("Max Sel:");
        lblMax.setHorizontalAlignment(SwingConstants.RIGHT);
        lblMax.setFont(new Font("SansSerif", Font.BOLD, 28));
        ct.gridx=2; ct.weightx=0.15; top.add(lblMax, ct);

        spinMaxSel = new JSpinner(new SpinnerNumberModel(1, 1, 10, 1));
        JComponent editorM = spinMaxSel.getEditor();
        spinMaxSel.setFont(new Font("SansSerif", Font.BOLD, 40));
        if (editorM instanceof JSpinner.DefaultEditor) {
        }
        ct.gridx=3; ct.weightx=0.15; top.add(spinMaxSel, ct);

        c.gridy=0; c.weighty=0.15; p.add(top, c);

        JLabel lblOps = new JLabel("Llistat d'Opcions:");
        lblOps.setFont(new Font("SansSerif", Font.BOLD, 28));
        c.gridy=1; c.weighty=0.05; p.add(lblOps, c);

        /* --- Llista d'opcions amb scroll --- */
        panelOpcionesContainer = new JPanel();
        panelOpcionesContainer.setLayout(new BoxLayout(panelOpcionesContainer, BoxLayout.Y_AXIS));
        panelOpcionesContainer.setBackground(Color.WHITE); 

        JScrollPane scrollOps = new JScrollPane(panelOpcionesContainer);
        scrollOps.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));

        scrollOps.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollOps.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        
        c.gridy=2; c.weighty=0.75;
        p.add(scrollOps, c);

        /* --- Botó per afegir opció --- */
        JButton btnMas = new JButton("+ Afegir Opció");
        btnMas.setFont(new Font("SansSerif", Font.BOLD, 28));
        btnMas.setBackground(new Color(245 , 255, 150));
        btnMas.addActionListener(e -> agregarFilaOpcion());
        c.gridy=3; c.weighty=0.05; p.add(btnMas, c);

        /* --- Botons finals --- */
        JPanel pBtns = new JPanel(new GridLayout(1, 2, 20, 0));
        pBtns.setBackground(Color.WHITE);
        JButton bOk = new JButton("Afegir Pregunta");
        bOk.setFont(new Font("SansSerif", Font.BOLD, 28));
        bOk.setBackground(new Color(225, 245, 254));
        JButton bNo = new JButton("Enrere");

        bNo.setFont(new Font("SansSerif", Font.BOLD, 28));
        
        bOk.addActionListener(e -> confirmarPreguntaMulti());
        bNo.addActionListener(e -> cardLayout.show(panelEditor, "SELECTOR"));
        pBtns.add(bNo); pBtns.add(bOk);
        
        c.gridy=4; c.weighty=0.08; 
        p.add(pBtns, c);

        return p;
    }

    /**
     * @brief Afegeix una nova fila de camp de text per a una opció de resposta.
     *
     * @details Crea una fila amb etiqueta i camp de text, i l'afegeix al contenidor
     *          de manera dinàmica. Desplaça automàticament el scroll al final.
     */
    private void agregarFilaOpcion() {
        JTextField campo = new JTextField();
        campo.setPreferredSize(new Dimension(300, 60)); 
        campo.setFont(new Font("SansSerif", Font.PLAIN, 30));
        campo.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));
        
        
        
        listaFieldsOpciones.add(campo);
        
        JPanel fila = new JPanel();
        fila.setLayout(new BoxLayout(fila, BoxLayout.X_AXIS));
        fila.setBackground(Color.WHITE);
        fila.setBorder(new EmptyBorder(5, 5, 5, 5));
        fila.setMaximumSize(new Dimension(Integer.MAX_VALUE, 70));
        fila.setAlignmentX(Component.LEFT_ALIGNMENT);
        fila.setPreferredSize(new Dimension(panelOpcionesContainer.getWidth() - 20, 70));
        fila.setMinimumSize(new Dimension(panelOpcionesContainer.getWidth() - 20, 70));
        fila.setBackground(Color.WHITE);

        JLabel lbl = new JLabel("Opció " + listaFieldsOpciones.size() + ": ");
        lbl.setFont(new Font("SansSerif", Font.ITALIC | Font.BOLD, 20));
        
        fila.add(lbl);
        fila.add(campo);
        
        panelOpcionesContainer.add(fila);
        
        panelOpcionesContainer.revalidate();
        panelOpcionesContainer.repaint();
        
        SwingUtilities.invokeLater(() -> {
            JScrollPane scroll = (JScrollPane) SwingUtilities.getAncestorOfClass(JScrollPane.class, panelOpcionesContainer);
            if (scroll != null) {
                JScrollBar vBar = scroll.getVerticalScrollBar();
                vBar.setValue(vBar.getMaximum());
            }
        });
    }

    /**
     * @brief Neteja el formulari de preguntes multichoice.
     *
     * @details Buida tots els camps de text, reinicia les opcions amb dues files buides,
     *          i estableix el nombre màxim de seleccions a 1.
     */
    private void limpiarFormularioMulti() {
        txtEnunMulti.setText("");
        spinMaxSel.setValue(1);
        panelOpcionesContainer.removeAll();
        listaFieldsOpciones.clear();
        agregarFilaOpcion();
        agregarFilaOpcion();
    }

    /**
     * @brief Confirma i afegeix una pregunta de tipus lliure a la llista.
     *
     * @details Valida que l'enunciat no estigui buit, crea un objecte temporal
     *          de pregunta, l'afegeix a la llista i mostra un missatge de confirmació.
     *          Després torna a la carta de selector.
     */
    private void confirmarPreguntaLliure() {
        String enun = txtEnunLliure.getText().trim();
        if (enun.isEmpty()) {
            JOptionPane.showMessageDialog(this, "L'enunciat no pot estar buit.");
            return;
        }
        
        preguntasPendientes.add(new PreguntaTemp(enun, checkNumerica.isSelected()));
        listModel.addElement("[Lliure] " + enun + (checkNumerica.isSelected() ? " (Num)" : ""));
        
        txtEnunLliure.setText("");
        checkNumerica.setSelected(false);
        cardLayout.show(panelEditor, "SELECTOR");
    }

    /**
     * @brief Confirma i afegeix una pregunta de tipus multichoice a la llista.
     *
     * @details Valida que l'enunciat i les opcions siguin correctes:
     *          - Enunciat no pot estar buit.
     *          - Mínim 2 opcions necessàries.
     *          - Nombre màxim de seleccions no pot superar el nombre d'opcions.
     *          Després afegeix la pregunta a la llista i torna al selector.
     */
    private void confirmarPreguntaMulti() {
        String enun = txtEnunMulti.getText().trim();
        if (enun.isEmpty()) {
            JOptionPane.showMessageDialog(this, "L'enunciat no pot estar buit.");
            return;
        }
        
        List<String> opcionesReales = new ArrayList<>();
        for (JTextField tf : listaFieldsOpciones) {
            if (!tf.getText().trim().isEmpty()) {
                opcionesReales.add(tf.getText().trim());
            }
        }
        
        if (opcionesReales.size() < 2) {
            JOptionPane.showMessageDialog(this, "Min. 2 opcions.");
            return;
        }
        
        int max = (Integer) spinMaxSel.getValue();
        if (max > opcionesReales.size()) {
            JOptionPane.showMessageDialog(this, "Max seleccions > Nº Opcions");
            return;
        }

        preguntasPendientes.add(new PreguntaTemp(enun, opcionesReales, max));
        listModel.addElement("[Multi] " + enun + " (" + opcionesReales.size() + " ops)");
        
        cardLayout.show(panelEditor, "SELECTOR");
    }

    /**
     * @brief Guarda l'enquesta completa al sistema.
     *
     * @details Valida que l'enquesta tingui:
     *          - Títol no buit.
     *          - Almenys una pregunta afegida.
     *          
     *          Crea l'enquesta al dominili i afegeix totes les preguntes pendents
     *          amb les seves característiques específiques (numèriques per a lliures,
     *          opcions i màxim de seleccions per a multichoice).
     *          
     *          En cas d'èxit, mostra un missatge de confirmació i torna al menú.
     *          En cas d'error, mostra el missatge d'error corresponent.
     */
    private void guardarEnquestaEnSistema() {
        String titol = txtTitol.getText().trim();
        if (titol.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Falta el títol!");
            return;
        }
        if (preguntasPendientes.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Afegeix alguna pregunta.");
            return;
        }

        int k = 3;
        ctrl.getCD().crearEnquestaBuida(titol, ctrl.getUsuarioActual(), k);

        try {
            for (PreguntaTemp p : preguntasPendientes) {
                if (p.tipo.equals("lliure")) {
                    ctrl.getCD().crearPreguntaLliure(titol, p.enunciado, 20, p.esNumerica);
                } else {
                    ctrl.getCD().crearPreguntaMultichoice(titol, p.enunciado, p.opciones, p.maxSel);
                }
            }
            
            JOptionPane.showMessageDialog(this, "Enquesta guardada!");
            limpiarTodo();
            ctrl.irAMenu();
            
        } catch (InvalidPreguntaException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error inesperat: " + e.getMessage());
        }
    }

    /**
     * @brief Neteja tots els camps de la vista de creació.
     *
     * @details Reinicialitza:
     *          - Camp de títol de l'enquesta.
     *          - Nombre de clusters a 3.
     *          - Llista de preguntes afegides.
     *          - Llista temporal de preguntes pendents.
     *          - Torna a la carta de selector.
     */
    private void limpiarTodo() {
        txtTitol.setText("");
        listModel.clear();
        preguntasPendientes.clear();
        cardLayout.show(panelEditor, "SELECTOR");
    }
}