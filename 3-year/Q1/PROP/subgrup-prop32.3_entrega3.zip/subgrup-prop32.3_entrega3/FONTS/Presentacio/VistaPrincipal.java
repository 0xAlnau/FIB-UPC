/*
 +----------------------------------------------------------+
 |                VistaPrincipal.java                       |
 +----------------------------------------------------------+
 | Repositori:                                              |
 |   · subgrup-prop32.3                                     |
 +----------------------------------------------------------+
 | Aquest mòdul ha sigut programat per:                     |
 |   · Gabriel Alegre Conchello                             |
 |   · Santiago Lluzar Frias                                |
 +----------------------------------------------------------+
 */

package FONTS.Presentacio;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * @file VistaPrincipal.java
 * @brief Finestra principal de l'aplicació.
 */

/**
 * @class VistaPrincipal
 * @brief Finestra principal que conté totes les vistes
 *        de la capa de presentació mitjançant un CardLayout.
 *
 * @details Aquesta classe:
 *          - Inicialitza totes les vistes del sistema.
 *          - Gestiona el canvi de vistes amb CardLayout.
 *          - Gestiona la comunicació entre controlador i vistes.
 *          - Controla el tancament segur de l'aplicació.
 */
public class VistaPrincipal extends JFrame {

    /** @brief Controlador de presentació associat a la finestra. */
    private CtrlPresentacion ctrl;

    /** @brief Gestor de layout per alternar entre vistes. */
    private CardLayout cardLayout;

    /** @brief Panell principal que conté totes les vistes. */
    private JPanel mainPanel;

    /** @brief Vista d'inici de sessió (login). */
    private VistaLogin vistaLogin;

    /** @brief Vista del menú principal. */
    private VistaMenu vistaMenu;

    /** @brief Vista per crear enquestes. */
    private VistaCrear vistaCrear;

    /** @brief Vista per contestar enquestes. */
    private VistaContestar vistaContestar;

    /** @brief Vista per mostrar resultats d'enquestes. */
    private VistaResultats vistaResultats;

    /** @brief Vista per visualitzar resultats de clustering. */
    private VistaCluster vistaCluster;

    /** @brief Vista per eliminar enquestes. */
    private VistaEliminar vistaEliminar;
    
    /** @brief Vista per gestionar prototipus d'enquestes. */
    private VistaPrototipus vistaPrototipus;

    /**
     * @brief Constructor de la finestra principal.
     *
     * @param ctrl Controlador de presentació que coordina
     *             la navegació i la lògica de l'aplicació.
     */
    public VistaPrincipal(CtrlPresentacion ctrl) {
        this.ctrl = ctrl;
        configurarVentana();
        inicializarVistas();
    }

    /**
     * @brief Configura les propietats bàsiques de la finestra.
     */
    private void configurarVentana() {
        setTitle("Gestor d'Enquestes Pro");
        setSize(2000, 1400);
        setResizable(true);
        setMinimumSize(new Dimension(2000, 1400));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

        /* --- Gestió del tancament segur --- */
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                ctrl.cerrarApp();
            }
        });

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        add(mainPanel);
    }

    /**
     * @brief Inicialitza totes les vistes i les registra al CardLayout.
     */
    private void inicializarVistas() {
        vistaLogin = new VistaLogin(ctrl);
        vistaMenu = new VistaMenu(ctrl);
        vistaCrear = new VistaCrear(ctrl);
        vistaContestar = new VistaContestar(ctrl);
        vistaResultats = new VistaResultats(ctrl);
        vistaCluster = new VistaCluster(ctrl);
        vistaEliminar = new VistaEliminar(ctrl);
        vistaPrototipus = new VistaPrototipus(ctrl);

        mainPanel.add(vistaLogin, "LOGIN");
        mainPanel.add(vistaMenu, "MENU");
        mainPanel.add(vistaCrear, "CREAR");
        mainPanel.add(vistaContestar, "CONTESTAR");
        mainPanel.add(vistaResultats, "RESULTATS");
        mainPanel.add(vistaCluster, "CLUSTER");
        mainPanel.add(vistaEliminar, "ELIMINAR");
        mainPanel.add(vistaPrototipus, "PROTOTIPUS");
    }

    /**
     * @brief Mostra una vista concreta segons el seu identificador.
     *
     * @param nombre Identificador de la vista a mostrar.
     */
    public void mostrarVista(String nombre) {
        cardLayout.show(mainPanel, nombre);
    }

    /**
     * @brief Actualitza el menú amb el nom de l'usuari actual.
     */
    public void actualizarMenu(String user) {
        vistaMenu.setUsuario(user);
    }

    /** @brief Carrega la llista d'enquestes per contestar. */
    public void cargarListaContestar() {
        vistaContestar.cargarEnquestas();
    }

    /** @brief Carrega la llista d'enquestes per veure resultats. */
    public void cargarListaResultats() {
        vistaResultats.cargarEnquestas();
    }

    /** @brief Carrega la llista d'enquestes per clustering. */
    public void cargarListaCluster() {
        vistaCluster.cargarEnquestas();
    }

    /** @brief Carrega la llista d'enquestes per eliminar. */
    public void cargarListaEliminar() {
        vistaEliminar.cargarEnquestas();
    }

    /** @brief Carrega la llista d'enquestes del prototipus. */
    public void cargarListaPrototipus() {
        vistaPrototipus.cargarEnquestas();
    }

    /**
     * @brief Fa visible la finestra principal.
     */
    public void hacerVisible() {
        setVisible(true);
    }
}