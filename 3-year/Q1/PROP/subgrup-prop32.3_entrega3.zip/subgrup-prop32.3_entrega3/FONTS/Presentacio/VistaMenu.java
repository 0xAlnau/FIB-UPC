/*
 +----------------------------------------------------------+
 |                   VistaMenu.java                         |
 +----------------------------------------------------------+
 | Repositori:                                              |
 |   · subgrup-prop32.3                                     |
 +----------------------------------------------------------+
 | Aquest mòdul ha sigut programat per:                     |
 |   · Gabriel Alegre Conchello                             |
 |   · Santiago Lluzar Frias                                |
 +----------------------------------------------------------+
 */

package FONTS.Presentacio;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

/**
 * @file VistaMenu.java
 * @brief Vista gràfica del menú principal de l'aplicació.
 */

/**
 * @class VistaMenu
 * @brief Panell de la capa de presentació que actua com a
 *        punt central de navegació del sistema.
 *
 * @details Aquesta vista:
 *          - Mostra les funcionalitats principals del sistema.
 *          - Permet navegar entre crear, contestar i eliminar enquestes.
 *          - Dona accés a visualització de resultats i clustering.
 *          - Permet tancar la sessió de l'usuari actual.
 */
public class VistaMenu extends JPanel {

    /** @brief Controlador de presentació associat a la vista. */
    private CtrlPresentacion ctrl;

    /** @brief Etiqueta de títol que mostra el menú o el nom de l'usuari. */
    private JLabel title;

    /**
     * @brief Constructor del menú principal.
     *
     * @param ctrl Controlador de presentació que gestiona la navegació
     *             entre les diferents vistes.
     */
    public VistaMenu(CtrlPresentacion ctrl) {
        this.ctrl = ctrl;

        /* --- Layout principal --- */
        setLayout(new GridBagLayout());
        setBackground(new Color(240, 242, 245));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1.0;


        /* --- Carta central --- */
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(new CompoundBorder(
            new LineBorder(Color.LIGHT_GRAY, 1, true),
            new EmptyBorder(20, 20, 20, 20)
        ));

        gbc.gridx = 1;
        gbc.weightx = 0.6;
        gbc.insets = new Insets(30, 0, 30, 0);
        add(card, gbc);

        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 1.0;
        c.gridx = 0;

        /* --- Títol --- */
        c.gridy = 0;
        c.weighty = 0.15;

        title = new JLabel("MENÚ PRINCIPAL", SwingConstants.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 100));
        card.add(title, c);

        /* --- Funcionalitats --- */
        c.gridy = 1;
        c.weighty = 0.75;
        c.insets = new Insets(30, 50, 50, 50);

        JPanel grid = new JPanel(new GridLayout(3, 2, 15, 15));
        grid.setBackground(Color.WHITE);

        grid.add(crearBtn("Crear Enquesta", new Color(33, 150, 243), e -> ctrl.irACrearEnquesta()));
        grid.add(crearBtn("Contestar", new Color(33, 150, 243), e -> ctrl.irAContestar()));
        grid.add(crearBtn("Veure Resultats", new Color(76, 175, 80), e -> ctrl.irAResultats()));
        grid.add(crearBtn("Clustering", new Color(76, 175, 80), e -> ctrl.irACluster()));
        grid.add(crearBtn("El meu Prototipus", null, e -> ctrl.irAPrototipus()));
        grid.add(crearBtn("Eliminar Enquesta", new Color(255, 82, 82), e -> ctrl.irAEliminar()));

        card.add(grid, c);

        /* --- Botó de tancar sessió --- */
        c.gridy = 2;
        c.weighty = 0.10;
        c.insets = new Insets(10, 40, 0, 40);

        JButton btnOut = crearBtn(
            "Tancar Sessió",
            new Color(96, 125, 139),
            e -> ctrl.logout()
        );
        card.add(btnOut, c);
    }

    /**
     * @brief Crea un botó pel menú principal.
     *
     * @param txt Text del botó.
     * @param bg Color de fons (null per defecte).
     * @param al Acció associada al botó.
     * @return Botó configurat.
     */
    private JButton crearBtn(String txt, Color bg, java.awt.event.ActionListener al) {
        JButton b = new JButton(txt);
        b.setBackground(bg != null ? bg : new Color(224, 224, 224));
        b.setForeground(bg != null ? Color.WHITE : Color.BLACK);
        b.setFont(new Font("SansSerif", Font.BOLD, 50));
        b.setFocusPainted(false);
        b.addActionListener(al);
        return b;
    }

    /**
     * @brief Actualitza el títol del menú amb el nom de l'usuari actual.
     *
     * @param u Nom de l'usuari autenticat.
     */
    public void setUsuario(String u) {
        if (title != null)
            title.setText("BENVINGUT/DA, " + u.toUpperCase());
    }
}
