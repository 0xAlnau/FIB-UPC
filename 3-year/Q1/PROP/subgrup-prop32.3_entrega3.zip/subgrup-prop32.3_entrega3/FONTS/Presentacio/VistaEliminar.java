/*
 +----------------------------------------------------------+
 |                 VistaEliminar.java                       |
 +----------------------------------------------------------+
 | Repositori:                                              |
 |   · subgrup-prop32.3                                     |
 +----------------------------------------------------------+
 | Aquest mòdul ha sigut programat per:                     |
 |   · Gabriel Alegre Conchello                             |
 |   · Santiago Lluzar Frias                                |
 +----------------------------------------------------------+
 */

package FONTS.Presentacio;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.util.Set;

/**
 * @file VistaEliminar.java
 * @brief Vista gràfica per eliminar enquestes existents.
 */

/**
 * @class VistaEliminar
 * @brief Panell de la capa de presentació que permet a l'usuari
 *        eliminar una de les seves enquestes.
 *
 * @details Aquesta vista:
 *          - Mostra les enquestes creades per l'usuari actual.
 *          - Permet seleccionar una enquesta concreta.
 *          - Demana confirmació abans d'eliminar-la.
 *          - Elimina definitivament l'enquesta del sistema.
 */
public class VistaEliminar extends JPanel {

    /** @brief Controlador de presentació associat a la vista. */
    private CtrlPresentacion ctrl;

    /** @brief ComboBox amb la llista d'enquestes de l'usuari. */
    private JComboBox<String> comboEnquestes;

    /**
     * @brief Constructor de la vista d'eliminació d'enquestes.
     *
     * @param ctrl Controlador de presentació que gestiona la navegació
     *             i la comunicació amb la capa de domini.
     */
    public VistaEliminar(CtrlPresentacion ctrl) {
        this.ctrl = ctrl;

        /* --- Layout principal --- */
        setLayout(new GridBagLayout());
        setBackground(new Color(240, 242, 245));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1.0;

        /* --- Marges laterals --- */
        gbc.gridx = 0; 
        gbc.weightx = 0.15; 
        add(Box.createGlue(), gbc);

        gbc.gridx = 2; 
        gbc.weightx = 0.15; 
        add(Box.createGlue(), gbc);

        /* --- Carta central --- */
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(new CompoundBorder(
            new LineBorder(Color.LIGHT_GRAY, 1, true),
            new EmptyBorder(30, 40, 30, 40)
        ));

        gbc.gridx = 1;
        gbc.weightx = 0.4;
        gbc.insets = new Insets(60, 0, 60, 0);
        add(card, gbc);

        GridBagConstraints c = new GridBagConstraints();
        c.weightx = 1.0;
        c.gridx = 0;
        c.fill = GridBagConstraints.BOTH;

        /* --- Títol --- */
        c.gridy = 0;
        c.weighty = 0.2;

        JLabel title = new JLabel("ELIMINAR ENQUESTA", SwingConstants.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 65));
        title.setForeground(new Color(211, 47, 47));
        card.add(title, c);

        /* --- Text informatiu --- */
        c.gridy = 1;
        c.weighty = 0.1;
        c.insets = new Insets(10, 0, 0, 0);

        JLabel l = new JLabel("Selecciona l'enquesta a esborrar:", SwingConstants.CENTER);
        l.setFont(new Font("SansSerif", Font.ITALIC | Font.BOLD, 30));
        l.setForeground(Color.GRAY);
        card.add(l, c);

        /* --- Selector d'enquestes --- */
        c.gridy = 2;
        c.weighty = 0.10;
        c.fill = GridBagConstraints.BOTH;
        c.insets = new Insets(5, 20, 10, 20);

        comboEnquestes = new JComboBox<>();
        comboEnquestes.setPreferredSize(new Dimension(0, 60));
        comboEnquestes.setFont(new Font("SansSerif", Font.PLAIN, 50));
        card.add(comboEnquestes, c);

        /* --- Botons inferiors --- */
        c.gridy = 4;
        c.weighty = 0.1;
        c.insets = new Insets(200, 40, 0, 40);

        JPanel pBtn = new JPanel(new GridLayout(1, 2, 20, 0));
        pBtn.setBackground(Color.WHITE);

        JButton btnBack = new JButton("Tornar");
        btnBack.setFont(new Font("SansSerif", Font.BOLD, 50));
        btnBack.addActionListener(e -> ctrl.irAMenu());

        JButton btnDel = new JButton("ELIMINAR");
        btnDel.setBackground(new Color(255, 82, 82));
        btnDel.setFont(new Font("SansSerif", Font.BOLD, 50));
        btnDel.setForeground(Color.WHITE);
        btnDel.addActionListener(e -> eliminar());

        pBtn.add(btnBack);
        pBtn.add(btnDel);
        card.add(pBtn, c);
    }

    /**
     * @brief Carrega al comboBox les enquestes creades per l'usuari actual.
     */
    public void cargarEnquestas() {
        comboEnquestes.removeAllItems();
        Set<String> s = ctrl.getCD().getEnquestesDeUsuari(ctrl.getUsuarioActual());
        for (String t : s) comboEnquestes.addItem(t);
    }

    /**
     * @brief Elimina l'enquesta seleccionada després de confirmar l'acció.
     */
    private void eliminar() {
        String t = (String) comboEnquestes.getSelectedItem();
        if (t != null) {
            int confirm = JOptionPane.showConfirmDialog(
                this,
                "Segur que vols eliminar '" + t + "'? Aquesta acció no es pot desfer.",
                "Confirmar Eliminació",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
            );

            if (confirm == JOptionPane.YES_OPTION) {
                ctrl.getCD().eliminarEnquesta(ctrl.getUsuarioActual(), t);
                JOptionPane.showMessageDialog(this, "Enquesta eliminada.");
                cargarEnquestas();
            }
        }
    }
}
