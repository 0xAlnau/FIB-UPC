/*
 +----------------------------------------------------------+
 |                VistaPrototipus.java                      |
 +----------------------------------------------------------+
 | Repositori:                                              |
 |   · subgrup-prop32.3                                     |
 +----------------------------------------------------------+
 | Aquest mòdul ha sigut programat per:                     |
 |   · Gabriel Alegre Conchello                             |
 |   · Santiago Lluzar Frias                                |
 +----------------------------------------------------------+
 */

package FONTS.Presentacio;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Set;

/**
 * @file VistaPrototipus.java
 * @brief Vista gràfica per executar i mostrar el prototipus
 *        d'una enquesta.
 */

/**
 * @class VistaPrototipus
 * @brief Panell de la capa de presentació que permet
 *        calcular i visualitzar el prototipus d'una enquesta.
 *
 * @details Aquesta vista:
 *          - Permet seleccionar una enquesta existent.
 *          - Executa el càlcul del prototipus a través del controlador.
 *          - Mostra el resultat obtingut o els errors corresponents.
 */
public class VistaPrototipus extends JPanel {

    /** @brief Controlador de presentació associat a la vista. */
    private CtrlPresentacion ctrl;

    /** @brief ComboBox amb la llista d'enquestes disponibles. */
    private JComboBox<String> comboEnquestes;

    /** @brief Etiqueta on es mostra el resultat del prototipus. */
    private JLabel lblResultado;

    /**
     * @brief Constructor de la vista de prototipus.
     *
     * @param ctrl Controlador de presentació que gestiona
     *             la comunicació amb la capa de domini.
     */
public VistaPrototipus(CtrlPresentacion ctrl) {
        this.ctrl = ctrl;

        // 1. LAYOUT EXTERNO (30-40-30)
        setLayout(new GridBagLayout());
        setBackground(new Color(240, 242, 245));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1.0;

        // Márgenes laterales
        gbc.gridx = 0; gbc.weightx = 0.15; add(Box.createGlue(), gbc);
        gbc.gridx = 2; gbc.weightx = 0.15; add(Box.createGlue(), gbc);

        // Carta Central
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(new CompoundBorder(
            new LineBorder(Color.LIGHT_GRAY, 1, true), 
            new EmptyBorder(30, 40, 30, 40)
        ));

        gbc.gridx = 1; 
        gbc.weightx = 0.4;
        gbc.insets = new Insets(60, 0, 60, 0);
        add(card, gbc);

        // --- CONTENIDO ---
        GridBagConstraints c = new GridBagConstraints();
        c.weightx = 1.0;
        c.gridx = 0;

        // A. TÍTULO (20%)
        c.gridy = 0; 
        c.weighty = 0.2;
        c.fill = GridBagConstraints.BOTH;
        
        JLabel title = new JLabel("EL MEU PROTOTIPUS", SwingConstants.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 65));
        title.setForeground(new Color(0, 150, 136));
        card.add(title, c);

        // B. ETIQUETA (10%)
        c.gridy = 1; 
        c.weighty = 0.1;
        c.fill = GridBagConstraints.BOTH; 
        c.insets = new Insets(10, 0, 0, 0);
        
        JLabel l = new JLabel("Selecciona l'enquesta:", SwingConstants.CENTER);
        l.setFont(new Font("SansSerif", Font.ITALIC | Font.BOLD, 40));
        l.setForeground(Color.GRAY);
        card.add(l, c);

        // C. COMBOBOX (25%)
        c.gridy = 2; 
        c.weighty = 0.10; 
        c.fill = GridBagConstraints.BOTH; 
        c.insets = new Insets(5, 20, 10, 20); 
        
        comboEnquestes = new JComboBox<>();
        comboEnquestes.setPreferredSize(new Dimension(0, 60));
        comboEnquestes.setFont(new Font("SansSerif", Font.PLAIN, 50)); 
        card.add(comboEnquestes, c);

        // D. RESULTADO (15%)
        c.gridy = 3;
        c.weighty = 0.15;
        c.fill = GridBagConstraints.BOTH;
        c.insets = new Insets(5, 0, 5, 0);
        
        lblResultado = new JLabel("-", SwingConstants.CENTER);
        lblResultado.setFont(new Font("SansSerif", Font.BOLD, 40));
        lblResultado.setForeground(new Color(0, 150, 136));
        card.add(lblResultado, c);

        // E. BOTONES (30%)
        c.gridy = 4; 
        c.weighty = 0.15;
        c.fill = GridBagConstraints.BOTH; 
        c.insets = new Insets(10, 40, 0, 40);
        
        JPanel pBtn = new JPanel(new GridLayout(1, 2, 20, 0));
        pBtn.setBackground(Color.WHITE);

        JButton btnBack = new JButton("Tornar");
        btnBack.setFont(new Font("SansSerif", Font.BOLD, 50));
        btnBack.addActionListener(e -> ctrl.irAMenu());

        JButton btnCalc = new JButton("CALCULAR");
        btnCalc.setBackground(new Color(0, 150, 136)); 
        btnCalc.setFont(new Font("SansSerif", Font.BOLD, 50));
        btnCalc.setForeground(Color.WHITE);
        btnCalc.addActionListener(e -> ejecutarPrototipus());

        pBtn.add(btnBack);
        pBtn.add(btnCalc);
        card.add(pBtn, c);
    }

    /**
     * @brief Carrega la llista d'enquestes disponibles al ComboBox.
     */
    public void cargarEnquestas() {
        comboEnquestes.removeAllItems();
        Set<String> s = ctrl.getCD().getLlistaTitolEnquestes();
        for (String t : s) comboEnquestes.addItem(t);
        lblResultado.setText("-");
        lblResultado.setForeground(Color.BLACK);
    }
    
    /**
     * @brief Executa el càlcul del prototipus de l'enquesta seleccionada.
     *
     * @details Captura la sortida per consola del prototipus i la mostra
     *          directament a la interfície gràfica.
     */
    private void ejecutarPrototipus() {
        String t = (String) comboEnquestes.getSelectedItem();
        if (t != null) {
            String resultado = ctrl.getCD().getPrototipus(t, ctrl.getUsuarioActual());
            
            if (resultado.startsWith("Error")) {
                lblResultado.setForeground(Color.RED);
                lblResultado.setFont(new Font("SansSerif", Font.BOLD, 30));
                if (resultado.length() > 30) {
                     JOptionPane.showMessageDialog(this, resultado, "Error", JOptionPane.WARNING_MESSAGE);
                }
            } else {
                lblResultado.setForeground(new Color(0, 150, 136)); 
            }
            
            lblResultado.setText(resultado);
        }
    }
}