/*
 +----------------------------------------------------------+
 |                VistaContestar.java                       |
 +----------------------------------------------------------+
 | Repositori:                                              |
 |   · subgrup-prop32.3                                     |
 +----------------------------------------------------------+
 | Aquest mòdul ha sigut programat per:                     |
 |   · Gabriel Alegre Conchello                             |
 |   · Santiago Lluzar Frias                                |
 +----------------------------------------------------------+
 */


package FONTS.Presentacio;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.util.*;
import java.util.List;

import FONTS.Domini.*;

/**
 * @file VistaContestar.java
 * @brief Vista gràfica per contestar enquestes existents.
 */

/**
 * @class VistaContestar
 * @brief Panell de la capa de presentació que permet a l'usuari
 *        contestar una de les enquestes disponibles.
 *
 * @details Aquesta vista:
 *          - Mostra les enquestes disponibles per contestar.
 *          - Permet seleccionar una enquesta concreta.
 *          - Genera el formulari dinàmic amb les preguntes de l'enquesta.
 *          - Recull les respostes de l'usuari i les enmagatzema al sistema.
 */
public class VistaContestar extends JPanel {

    /** @brief Controlador de presentació que gestiona la lògica i comunicació amb el domini. */
    private CtrlPresentacion ctrl;

    /** @brief Components gràfics principals. */
    private JComboBox<String> comboEnquestes;

    /** @brief Panell que conté el qüestionari generat. */
    private JPanel panelCuestionario;

    /** @brief Llista d'inputs associats a les preguntes del qüestionari. */
    private List<PreguntaAux> listaInputs;

    /**
     * @brief Classe auxiliar per emmagatzemar una pregunta i el seu component d'input associat.
     */
    private class PreguntaAux {
        /** @brief Pregunta associada. */
        Pregunta pregunta;

        /** @brief Component gràfic d'input per a la pregunta. */
        JComponent componenteInput;

        /** @brief Constructor de la classe PreguntaAux.
         *  @param p Pregunta associada.
         *  @param c Component gràfic d'input per a la pregunta.
         */
        PreguntaAux(Pregunta p, JComponent c) { 
            this.pregunta = p; 
            this.componenteInput = c; 
        }
    }

    /**
     * @brief Constructor de la vista per contestar enquestes.
     *  @param ctrl Controlador de presentació.
     */
    public VistaContestar(CtrlPresentacion ctrl) {
        this.ctrl = ctrl;
        this.listaInputs = new ArrayList<>();

        /* --- Layout principal --- */
        setLayout(new GridBagLayout());
        setBackground(new Color(240, 242, 245));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1.0;

        gbc.gridx = 0; gbc.weightx = 0.1; add(Box.createGlue(), gbc);
        gbc.gridx = 2; gbc.weightx = 0.1; add(Box.createGlue(), gbc);

        /* --- Carta central --- */
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(new CompoundBorder(
            new LineBorder(Color.LIGHT_GRAY, 1, true),
            new EmptyBorder(20, 20, 20, 20)
        ));

        gbc.gridx = 1;
        gbc.weightx = 0.8;
        gbc.insets = new Insets(30, 0, 30, 0);
        add(card, gbc);

        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 1.0;
        c.gridx = 0;

        /* --- Panell superior --- */
        c.gridy = 0;
        c.weighty = 0.075;
        JPanel top = new JPanel(new GridBagLayout());
        top.setBackground(Color.WHITE);
        
        JLabel lbl = new JLabel("Enquesta:");
        lbl.setFont(new Font("SansSerif", Font.BOLD, 50));
        lbl.setForeground(new Color(155, 155, 32));        
        comboEnquestes = new JComboBox<>();
        comboEnquestes.setFont(new Font("SansSerif", Font.PLAIN, 50));

        JButton btnCargar = new JButton("Carregar");
        btnCargar.setFont(new Font("SansSerif", Font.BOLD, 28));
        btnCargar.setBackground(new Color(33, 150, 243));
        btnCargar.setForeground(Color.WHITE);
        btnCargar.addActionListener(e -> generarFormulario());

        GridBagConstraints ch = new GridBagConstraints();
        ch.fill = GridBagConstraints.BOTH;
        ch.insets = new Insets(5, 5, 5, 5);
        ch.weighty = 1.0;
        ch.gridx = 0; ch.weightx = 0.1; top.add(lbl, ch);
        ch.gridx = 1; ch.weightx = 0.7; top.add(comboEnquestes, ch);
        ch.gridx = 2; ch.weightx = 0.2; top.add(btnCargar, ch);
        
        card.add(top, c);

        /* --- Panell central amb scroll --- */
        c.gridy = 1;
        c.weighty = 0.8;
        c.insets = new Insets(10, 0, 10, 0);

        panelCuestionario = new JPanel(new GridBagLayout());
        panelCuestionario.setBackground(Color.WHITE);

        JScrollPane scroll = new JScrollPane(panelCuestionario);
        scroll.getVerticalScrollBar().setUnitIncrement(20);
        scroll.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        
        card.add(scroll, c);

        /* --- Botons inferiors --- */
        c.gridy = 2;
        c.weighty = 0.1;
        
        JPanel pBtn = new JPanel(new GridLayout(1, 2, 20, 0));
        pBtn.setBackground(Color.WHITE);

        JButton btnCancel = new JButton("Cancel·lar");
        btnCancel.setFont(new Font("SansSerif", Font.BOLD, 28));
        btnCancel.addActionListener(e -> { limpiar(); ctrl.irAMenu(); });

        JButton btnEnviar = new JButton("ENVIAR RESPOSTES");
        btnEnviar.setFont(new Font("SansSerif", Font.BOLD, 28));
        btnEnviar.setBackground(new Color(76, 175, 80));
        btnEnviar.setForeground(Color.WHITE);
        btnEnviar.addActionListener(e -> procesarRespuestas());

        pBtn.add(btnCancel);
        pBtn.add(btnEnviar);
        card.add(pBtn, c);
    }

    /**
     * @brief Carrega els títols de les enquestes disponibles al comboBox.
     */
    public void cargarEnquestas() {
        comboEnquestes.removeAllItems();
        Set<String> s = ctrl.getCD().getLlistaTitolEnquestes();
        for (String t : s) comboEnquestes.addItem(t);
        limpiar();
    }

    /**
     * @brief Neteja el panell del qüestionari i la llista d'inputs.
     */
    private void limpiar() {
        panelCuestionario.removeAll();
        panelCuestionario.revalidate();
        panelCuestionario.repaint();
        listaInputs.clear();
    }

    /**
     * @brief Genera el formulari de preguntes de l'enquesta seleccionada.
     */
    private void generarFormulario() {
        limpiar();
        String t = (String) comboEnquestes.getSelectedItem();
        if (t == null) return;
        
        Enquesta enq = ctrl.getCD().getEnquesta(t);
        int numP = enq.getNumPreguntes();
        if (numP == 0) return;

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(10, 10, 10, 10);
        
        gbc.weighty = 0.0;

        for (int i = 1; i <= numP; i++) {
            gbc.gridy = i - 1;
            Pregunta p = enq.getPreguntes()[i];
            JPanel pPreg = crearPanelPregunta(i, p);
            panelCuestionario.add(pPreg, gbc);
        }
        
        GridBagConstraints gbcFiller = new GridBagConstraints();
        gbcFiller.gridx = 0;
        gbcFiller.gridy = numP;
        gbcFiller.weighty = 1.0;
        gbcFiller.fill = GridBagConstraints.VERTICAL;
        
        JPanel filler = new JPanel();
        filler.setOpaque(false); 
        panelCuestionario.add(filler, gbcFiller);
        
        panelCuestionario.revalidate();
        panelCuestionario.repaint();
    }
    
    /**
     * @brief Crea el panell gràfic corresponent a una pregunta concreta.
     */
    private JPanel crearPanelPregunta(int index, Pregunta p) {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(new CompoundBorder(
            new LineBorder(Color.LIGHT_GRAY, 1, true),
            new EmptyBorder(10, 15, 10, 15)
        )); 

        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH;
        c.gridx = 0;
        c.weightx = 1.0;

        c.gridy = 0;
        c.weighty = 0.2;
        
        JLabel lblPregunta = new JLabel(index + ". " + p.getText());
        lblPregunta.setFont(new Font("SansSerif", Font.BOLD, 28));
        lblPregunta.setForeground(new Color(60, 60, 60));
        panel.add(lblPregunta, c);

        c.gridy = 1;
        c.weighty = 0.8; 
        c.insets = new Insets(5, 0, 0, 0);

        JComponent componenteVisual;
        JComponent inputReal;

        if (p instanceof PreguntaLliure) {
            PreguntaLliure pl = (PreguntaLliure) p;
            
            JPanel pLliure = new JPanel(new GridBagLayout());
            pLliure.setBackground(Color.WHITE);
            
            GridBagConstraints ci = new GridBagConstraints();
            ci.fill = GridBagConstraints.BOTH;
            ci.weightx = 1.0;
            ci.gridx = 0;

            ci.gridy = 0;
            ci.weighty = 0.2;
            JLabel lblTipo = new JLabel(pl.esNumerica() ? "(Numèrica)" : "(Text)");
            lblTipo.setFont(new Font("SansSerif", Font.ITALIC, 28));
            lblTipo.setForeground(Color.GRAY);
            pLliure.add(lblTipo, ci);

            ci.gridy = 1;
            ci.weighty = 0.8;
            JTextField tf = new JTextField();
            tf.setFont(new Font("SansSerif", Font.PLAIN, 30));
            pLliure.add(tf, ci);

            componenteVisual = pLliure;
            inputReal = tf;

        } else {
            PreguntaMultichoice pm = (PreguntaMultichoice) p;
            
            JPanel pMulti = new JPanel(new GridBagLayout());
            pMulti.setFont(new Font("SansSerif", Font.PLAIN, 30));
            pMulti.setBackground(Color.WHITE);
            
            GridBagConstraints ci = new GridBagConstraints();
            ci.fill = GridBagConstraints.HORIZONTAL;
            ci.weightx = 1.0;
            ci.gridx = 0;

            ci.gridy = 0;
            JLabel info = new JLabel("(Selecciona màx " + pm.getLimitOpcions() + ")");
            info.setFont(new Font("SansSerif", Font.ITALIC, 28));
            info.setForeground(Color.GRAY);
            pMulti.add(info, ci);

            ci.gridy = 1;
            ci.insets = new Insets(5, 0, 0, 0);
            
            JList<String> list = new JList<>(pm.getOpcions().toArray(new String[0]));
            list.setFont(new Font("SansSerif", Font.PLAIN, 30));
            list.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
            
            int opcionesVisibles = Math.min(pm.getOpcions().size(), 6);
            if (opcionesVisibles < 1) opcionesVisibles = 1; 
            list.setVisibleRowCount(opcionesVisibles);
            
            JScrollPane scrollLista = new JScrollPane(list);
            pMulti.add(scrollLista, ci);
            
            componenteVisual = pMulti;
            inputReal = list;       
    }

        panel.add(componenteVisual, c);
        listaInputs.add(new PreguntaAux(p, inputReal));
        return panel;
    }

    /**
     * @brief Crea i processa les respostes donades a l'enquesta.
     */
    private void procesarRespuestas() {
        if (listaInputs.isEmpty()) return;
        String t = (String) comboEnquestes.getSelectedItem();
        Enquesta enq = ctrl.getCD().getEnquesta(t);
        String u = ctrl.getUsuarioActual();

        for (PreguntaAux pw : listaInputs) {
            try {
                if (pw.pregunta instanceof PreguntaLliure) {
                    String txt = ((JTextField) pw.componenteInput).getText();
                    if (((PreguntaLliure) pw.pregunta).esNumerica())
                        enq.registrarResposta(new RespostaNum((PreguntaLliure) pw.pregunta, u, Float.parseFloat(txt)));
                    else
                        enq.registrarResposta(new RespostaText((PreguntaLliure) pw.pregunta, u, txt));
                } else {
                    PreguntaMultichoice pm = (PreguntaMultichoice) pw.pregunta;
                    JList<?> lista = (JList<?>) pw.componenteInput;
                    int[] indicesSeleccionados = lista.getSelectedIndices();

                    if (indicesSeleccionados.length > pm.getLimitOpcions()) {
                        JOptionPane.showMessageDialog(this, 
                            "Error a la pregunta: \"" + pm.getText() + "\"\n" +
                            "Has seleccionat " + indicesSeleccionados.length + " opcions.\n" +
                            "El màxim permès és " + pm.getLimitOpcions() + ".",
                            "Excés d'opcions", JOptionPane.WARNING_MESSAGE);
                        return; 
                    }
                    Set<Integer> idxs = new HashSet<>();
                    for (int i : indicesSeleccionados) idxs.add(i);
                    enq.registrarResposta(new RespostaMultichoice(pm, u, idxs));
                }
            } catch (Exception e) {
                System.out.println("Error processant resposta: " + e.getMessage());
            }
        }        
        ctrl.getCD().getUsuari(u).enquestaContestada(t, enq);
        JOptionPane.showMessageDialog(this, "Enviat!");
        limpiar();
        ctrl.irAMenu();
    }
}