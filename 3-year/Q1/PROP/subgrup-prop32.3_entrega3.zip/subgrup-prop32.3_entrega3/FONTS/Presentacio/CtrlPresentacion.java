/*
 +----------------------------------------------------------+
 |                CtrlPresentacion.java                     |
 +----------------------------------------------------------+
 | Repositori:                                              |
 |   · subgrup-prop32.3                                     |
 +----------------------------------------------------------+
 | Aquest mòdul ha sigut programat per:                     |
 |   · Gabriel Alegre Conchello                             |
 |   · Santiago Lluzar Frias                                |
 +----------------------------------------------------------+
 */

package FONTS.Presentacio;

import FONTS.Domini.*;
import javax.swing.*;
import java.util.ArrayList;

/**
 * @file CtrlPresentacion.java
 * @brief Controlador de la capa de presentació de l'aplicació.
 */

/**
 * @class CtrlPresentacion
 * @brief Classe encarregada de coordinar la comunicació entre la
 *        vista (interfície gràfica) i el domini.
 *
 * @details Aquesta classe:
 *          - Inicialitza l'aplicació i carrega les dades persistides.
 *          - Gestiona el login, registre i logout d'usuaris.
 *          - Controla la navegació entre les diferents vistes.
 *          - S'encarrega de guardar les dades abans de tancar l'aplicació.
 */
public class CtrlPresentacion {

    /** @brief Controlador de la capa de domini. */
    private CtrlDominio CD;

    /** @brief Vista principal de l'aplicació. */
    private VistaPrincipal vistaPrincipal;

    /** @brief Nom de l'usuari que ha iniciat sessió. */
    private String usuarioActual;

    /**
     * @brief Constructor per defecte del controlador de presentació.
     *
     * @details Inicialitza el controlador de domini i la vista principal,
     *          establint la relació entre ambdós components.
     */
    public CtrlPresentacion() {
        CD = new CtrlDominio();
        vistaPrincipal = new VistaPrincipal(this);
    }

    /**
     * @brief Inicia l'aplicació.
     *
     * @details Carrega les dades persistides (usuaris i enquestes) si existeixen
     *          i mostra la vista de login com a pantalla inicial.
     */
    public void iniciarApp() {
        try {
            CD.importaUsuaris();
            CD.importaEnquestes();
        } catch (Exception e) {
            System.out.println("Info: No s'han trobat dades prèvies o error de càrrega.");
        }
        vistaPrincipal.mostrarVista("LOGIN");
        vistaPrincipal.hacerVisible();
    }

    /**
     * @brief Retorna el controlador de domini.
     * @return Instància de CtrlDominio.
     */
    public CtrlDominio getCD() { 
        return CD; 
    }

    /**
     * @brief Retorna el nom de l'usuari actual.
     * @return Nom de l'usuari autenticat o null si no hi ha sessió.
     */
    public String getUsuarioActual() { 
        return usuarioActual; 
    }

    /**
     * @brief Gestiona el procés de login d'un usuari.
     *
     * @param user Nom d'usuari.
     * @param pass Contrasenya.
     *
     * @details Comprova si l'usuari existeix i si la contrasenya és correcta.
     *          En cas afirmatiu, actualitza la vista i mostra el menú principal.
     */
    public void login(String user, String pass) {
        if (CD.nombreEnUso(user) && CD.comprovarPassword(user, pass)) {
            usuarioActual = user;
            vistaPrincipal.actualizarMenu(user);
            vistaPrincipal.mostrarVista("MENU");
        } else {
            JOptionPane.showMessageDialog(null, "Usuari o contrasenya incorrectes.");
        }
    }

    /**
     * @brief Registra un nou usuari al sistema.
     *
     * @param user Nom d'usuari.
     * @param pass Contrasenya.
     *
     * @details Si el nom d'usuari no existeix i els camps no són buits,
     *          es crea un nou usuari al domini.
     */
    public void registrar(String user, String pass) {
        if (user.isEmpty() || pass.isEmpty()) return;
        if (CD.nombreEnUso(user)) {
            JOptionPane.showMessageDialog(null, "L'usuari ja existeix.");
        } else {
            CD.crearUsuari(user, pass);
            JOptionPane.showMessageDialog(null, "Registrat! Fes login.");
        }
    }

    /**
     * @brief Tanca la sessió de l'usuari actual.
     *
     * @details Reinicia l'usuari actual i mostra la vista de login.
     */
    public void logout() {
        usuarioActual = null;
        vistaPrincipal.mostrarVista("LOGIN");
    }

    /**
     * @brief Navega a la vista del menú principal.
     */
    public void irAMenu() {
        vistaPrincipal.actualizarMenu(usuarioActual);
        vistaPrincipal.mostrarVista("MENU");
    }

    /** @brief Navega a la vista de creació d'enquestes. */
    public void irACrearEnquesta() { 
        vistaPrincipal.mostrarVista("CREAR"); 
    }

    /** @brief Navega a la vista per contestar enquestes. */
    public void irAContestar() { 
        vistaPrincipal.cargarListaContestar();
        vistaPrincipal.mostrarVista("CONTESTAR"); 
    }

    /** @brief Navega a la vista de resultats d'enquestes. */
    public void irAResultats() {
        vistaPrincipal.cargarListaResultats();
        vistaPrincipal.mostrarVista("RESULTATS");
    }

    /** @brief Navega a la vista de clustering. */
    public void irACluster() {
        vistaPrincipal.cargarListaCluster();
        vistaPrincipal.mostrarVista("CLUSTER");
    }

    /** @brief Navega a la vista d'eliminació d'enquestes. */
    public void irAEliminar() {
        vistaPrincipal.cargarListaEliminar();
        vistaPrincipal.mostrarVista("ELIMINAR");
    }

    /** @brief Navega a la vista de prototips. */
    public void irAPrototipus() {
        vistaPrincipal.cargarListaPrototipus();
        vistaPrincipal.mostrarVista("PROTOTIPUS");
    }

    /** @brief Obté les capçaleres de la taula de resultats des de Domini. */
    public ArrayList<String> getHeadersEncuesta(String titol) {
        return CD.getCapcalerasResultats(titol);
    }

    /** @brief Obté les dades de la taula de resultats des de Domini. */
    public ArrayList<ArrayList<String>> getDataEncuesta(String titol) {
        return CD.getDadesResultats(titol);
    }

    /** @brief Estableix el valor de k per al clustering d'una enquesta. */
    public void setValorK(String titol, int k) {
        CD.setValorK(titol, k);
    }

    /** @brief Obté la llista d'enunciats de les preguntes d'una enquesta. */
    public ArrayList<String> getPreguntesEnquesta(String titol) {
        return CD.getLlistaEnunciatsPreguntes(titol);
    }

    /** @brief Obté el valor de la silueta per a una enquesta. */
    public float getSilhouette(String titol) {
        return CD.getSilhouette(titol);
    }

    /**
     * @brief Tanca l'aplicació.
     *
     * @details Exporta les dades d'usuaris i enquestes abans de sortir
     *          definitivament del programa.
     */
    public void cerrarApp() {
        try {
            CD.exportarUsuaris();
            CD.exportarEnquestes();
        } catch (Exception e) { 
            e.printStackTrace(); 
        }
        System.exit(0);
    }
}