/*
 +----------------------------------------------------------+
 |                   VistaLogin.java                        |
 +----------------------------------------------------------+
 | Repositori:                                              |
 |   · subgrup-prop32.3                                     |
 +----------------------------------------------------------+
 | Aquest mòdul ha sigut programat per:                     |
 |   · Gabriel Alegre Conchello                             |
 |   · Santiago Lluzar Frias                                |
 +----------------------------------------------------------+
 */

package FONTS.Presentacio;

import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;

/**
 * @file VistaLogin.java
 * @brief Vista gràfica per a l'autenticació d'usuaris.
 */

/**
 * @class VistaLogin
 * @brief Panell de la capa de presentació que permet a un usuari
 * iniciar sessió o registrar-se al sistema.
 *
 * @details Aquesta vista:
 * - Mostra un formulari d'usuari i contrasenya.
 * - Permet iniciar sessió amb un usuari existent.
 * - Permet registrar un nou usuari.
 * - Delegua la lògica d'autenticació al controlador.
 */
public class VistaLogin extends JPanel {

    /** @brief Camp de text per introduir el nom d'usuari. */
    private JTextField userField;

    /** @brief Camp de contrasenya per introduir la password. */
    private JPasswordField passField;

    /**
     * @brief Constructor de la vista de login.
     *
     * @param ctrl Controlador de presentació encarregat de gestionar
     * el procés de login i registre.
     */
    public VistaLogin(CtrlPresentacion ctrl) {

        /* --- Layout principal --- */
        setLayout(new GridBagLayout());
        setBackground(new Color(240, 242, 245));

        GridBagConstraints gbcOuter = new GridBagConstraints();
        gbcOuter.fill = GridBagConstraints.BOTH;
        gbcOuter.weighty = 1.0;

        /* --- Marges laterals --- */
        gbcOuter.gridx = 0;
        gbcOuter.weightx = 0.3;
        add(Box.createGlue(), gbcOuter);

        gbcOuter.gridx = 2;
        gbcOuter.weightx = 0.3;
        add(Box.createGlue(), gbcOuter);

        /* --- Panell central del formulari --- */
        gbcOuter.gridx = 1;
        gbcOuter.weightx = 0.4;
        gbcOuter.insets = new Insets(20, 0, 40, 0);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(new CompoundBorder(
            new LineBorder(new Color(200, 200, 200), 1, true),
            new EmptyBorder(20, 40, 20, 40)
        ));

        GridBagConstraints gbcIn = new GridBagConstraints();
        gbcIn.fill = GridBagConstraints.BOTH;
        gbcIn.weightx = 1.0;
        gbcIn.gridx = 0;

        /* --- Títol --- */
        gbcIn.gridy = 0;
        gbcIn.weighty = 0.2;

        JLabel title = new JLabel("BENVINGUT", SwingConstants.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 85));
        title.setForeground(new Color(60, 60, 60));
        formPanel.add(title, gbcIn);

        /* --- Camp usuari --- */
        gbcIn.gridy = 1;
        gbcIn.weighty = 0.075;
        gbcIn.insets = new Insets(0, 0, 50, 0);
        JPanel pUser = createFieldPanel("Usuari", false);
        formPanel.add(pUser, gbcIn);
        userField = (JTextField) pUser.getComponent(1);

        /* --- Camp contrasenya --- */
        gbcIn.gridy = 2;
        gbcIn.weighty = 0.075;
        gbcIn.insets = new Insets(50, 0, 50, 0);

        JPanel pPass = createFieldPanel("Contrasenya", true);
        formPanel.add(pPass, gbcIn);
        passField = (JPasswordField) pPass.getComponent(1);

        /* --- Botons --- */
        gbcIn.gridy = 3;
        gbcIn.weighty = 0.1;
        gbcIn.insets = new Insets(100, 0, 0, 0);

        JPanel pBtn = new JPanel(new GridLayout(1, 2, 20, 0));
        pBtn.setBackground(Color.WHITE);

        JButton bLogin = crearBoton("Accedir", new Color(33, 150, 243));
        JButton bReg   = crearBoton("Registrar-se", new Color(255, 87, 34));

        bLogin.addActionListener(e ->
            ctrl.login(userField.getText(), new String(passField.getPassword()))
        );
        bReg.addActionListener(e ->
            ctrl.registrar(userField.getText(), new String(passField.getPassword()))
        );

        pBtn.add(bLogin);
        pBtn.add(bReg);
        formPanel.add(pBtn, gbcIn);

        add(formPanel, gbcOuter);
    }

    // ==================================================
    //            MÈTODES AUXILIARS
    // ==================================================

    /**
     * @brief Crea un panell amb etiqueta i camp de text.
     *
     * @param labelText Text de l'etiqueta.
     * @param isPass Indica si el camp és de contrasenya.
     * @return Panell configurat amb etiqueta i input.
     */
    private JPanel createFieldPanel(String labelText, boolean isPass) {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(Color.WHITE);

        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 1.0;
        c.gridx = 0;

        c.gridy = 0;
        c.weighty = 0.3;
        JLabel l = new JLabel(labelText);
        l.setFont(new Font("SansSerif", Font.BOLD, 40));
        l.setForeground(Color.GRAY);
        p.add(l, c);

        c.gridy = 1;
        c.weighty = 0.7;
        JTextField tf = isPass ? new JPasswordField() : new JTextField();
        
        tf.setFont(new Font("SansSerif", Font.PLAIN, 50));
        
        tf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.LIGHT_GRAY),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        p.add(tf, c);

        return p;
    }

    /**
     * @brief Crea un botó.
     *
     * @param txt Text del botó.
     * @param bg Color de fons.
     * @return Botó configurat.
     */
    private JButton crearBoton(String txt, Color bg) {
        JButton b = new JButton(txt);
        b.setBackground(bg);
        b.setForeground(Color.WHITE);
        
        // CAMBIO: Fuente más grande para el botón
        b.setFont(new Font("SansSerif", Font.BOLD, 40));
        b.setFocusPainted(false);
        
        // CAMBIO: Borde más grueso para hacer el botón más grande
        b.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        return b;
    }
}