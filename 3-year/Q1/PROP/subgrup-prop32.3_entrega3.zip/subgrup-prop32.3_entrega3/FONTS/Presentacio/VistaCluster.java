/*
 +----------------------------------------------------------+
 |                VistaCluster.java                         |
 +----------------------------------------------------------+
 | Repositori:                                              |
 |   · subgrup-prop32.3                                     |
 +----------------------------------------------------------+
 | Aquest mòdul ha sigut programat per:                     |
 |   · Gabriel Alegre Conchello                             |
 |   · Santiago Lluzar Frias                                |
 +----------------------------------------------------------+
 */

package FONTS.Presentacio;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel; 
import java.awt.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.*;
import java.util.Locale;

/**
 * @file VistaCluster.java
 * @brief Vista gràfica per executar i visualitzar el clustering d'enquestes amb mètriques de qualitat.
 */

/**
 * @class VistaCluster
 * @brief Panell de la capa de presentació que permet executar i visualitzar
 *        algoritmes de clustering sobre enquestes.
 *  
 * @details Aquesta vista:
 *          - Permet seleccionar una enquesta i les seves preguntes per analitzar.
 *          - Ofereix opcions de configuració per al clustering (algorisme, inicialització, nombre de clusters).
 *          - Executa l'algoritme i mostra els resultats en una taula (usuari i cluster assignat).
 *          - Calcula i visualitza el coeficient de Silhouette per avaluar la qualitat del clustering.
 */
public class VistaCluster extends JPanel {

    /** @brief Controlador de presentació que gestiona la lògica i comunicació amb el domini. */
    private CtrlPresentacion ctrl;

    /** @brief ComboBox per seleccionar l'enquesta a analitzar. */
    private JComboBox<String> comboEnquestes;

    /** @brief Llista de preguntes de l'enquesta seleccionada (permet selecció múltiple). */
    private JList<String> listaPreguntas;

    /** @brief Model de dades per a la llista de preguntes. */
    private DefaultListModel<String> modelPreguntas;

    /** @brief Taula per mostrar els resultats del clustering (usuari i cluster assignat). */
    private JTable tablaResultados;

    /** @brief Model de dades per a la taula de resultats. */
    private DefaultTableModel modelTabla;

    /** @brief Etiqueta que mostra el coeficient de Silhouette (métrica de qualitat del clustering). */
    private JLabel lblSilhouette;

    /** @brief Botó de ràdio per seleccionar l'algorisme 'basic'. */
    private JRadioButton rbBasic;

    /** @brief Botó de ràdio per seleccionar l'algorisme 'k-means'. */
    private JRadioButton rbKmeans;

    /** @brief Botó de ràdio per seleccionar l'algorisme 'k-medoids'. */
    private JRadioButton rbKmedoids;

    /** @brief Grup de botons de ràdio per a la selecció d'algorisme. */
    private ButtonGroup grupoAlgoritmo;

    /** @brief Botó de ràdio per seleccionar inicialització aleatòria. */
    private JRadioButton rbRandom;

    /** @brief Botó de ràdio per seleccionar inicialització k-means++. */
    private JRadioButton rbKmeansPlus;

    /** @brief Grup de botons de ràdio per a la selecció d'inicialització. */
    private ButtonGroup grupoInicializacion;

    /** @brief Selector numèric per establir el nombre de clusters a generar (2-100). */
    private JSpinner spinClusters;

    /** @brief Panell que conté les opcions de clustering (algoritme, inicialització i nombre de clusters). */
    private JPanel panelOpciones;

    /**
     * @brief Constructor de la vista de clustering.
     *
     * @param ctrl Referència al controlador de presentació per gestionar la lògica.
     */
    public VistaCluster(CtrlPresentacion ctrl) {
        this.ctrl = ctrl;

        /* --- Layout principal --- */
        setLayout(new GridBagLayout());
        setBackground(new Color(240, 242, 245));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1.0;

        /* --- Marges laterals --- */
        gbc.gridx = 0; gbc.weightx = 0.1; add(Box.createGlue(), gbc);
        gbc.gridx = 2; gbc.weightx = 0.1; add(Box.createGlue(), gbc);

        /* --- Carta central --- */
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(new CompoundBorder(
            new LineBorder(Color.LIGHT_GRAY, 1, true),
            new EmptyBorder(20, 20, 20, 20)
        ));

        gbc.gridx = 1; gbc.weightx = 0.8;
        gbc.insets = new Insets(30, 0, 30, 0);
        add(card, gbc);

        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 1.0;
        c.gridx = 0;

        /* --- Panell superior: selecció d'enquesta --- */
        c.gridy = 0; c.weighty = 0.06;
        JPanel top = new JPanel(new GridBagLayout());
        top.setBackground(Color.WHITE);

        JLabel lblTop = new JLabel("Enquesta a analitzar:");
        lblTop.setFont(new Font("SansSerif", Font.BOLD, 40));

        comboEnquestes = new JComboBox<>();
        comboEnquestes.addActionListener(e -> cargarPreguntas());
        comboEnquestes.setFont(new Font("SansSerif", Font.PLAIN, 50));
        comboEnquestes.setPreferredSize(new Dimension(600, 70));

        GridBagConstraints ch = new GridBagConstraints();
        ch.fill = GridBagConstraints.BOTH;
        ch.insets = new Insets(5, 5, 5, 5);
        ch.weighty = 1.0;
        ch.gridx = 0; ch.weightx = 0.3; top.add(lblTop, ch);
        ch.gridx = 1; ch.weightx = 0.7; top.add(comboEnquestes, ch);

        card.add(top, c);

        /* --- Panell central: preguntes i resultat --- */
        c.gridy = 1; c.weighty = 0.75; 
        c.insets = new Insets(10, 0, 10, 0);

        JPanel center = new JPanel(new GridBagLayout());
        center.setBackground(Color.WHITE);

        modelPreguntas = new DefaultListModel<>();
        listaPreguntas = new JList<>(modelPreguntas);
        listaPreguntas.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        listaPreguntas.setFont(new Font("SansSerif", Font.PLAIN, 24)); 

        // --- CONFIGURACIÓN DE LA TABLA ---
        modelTabla = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaResultados = new JTable(modelTabla);
        
        tablaResultados.setFont(new Font("SansSerif", Font.PLAIN, 30));
        tablaResultados.setRowHeight(50);
        tablaResultados.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 30));
        tablaResultados.getTableHeader().setPreferredSize(new Dimension(0, 50));
        tablaResultados.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        tablaResultados.setPreferredScrollableViewportSize(new Dimension(1600, 500));

        lblSilhouette = new JLabel("Silhouette: -");
        lblSilhouette.setFont(new Font("SansSerif", Font.BOLD, 24));
        lblSilhouette.setForeground(Color.GRAY);
        lblSilhouette.setHorizontalAlignment(SwingConstants.CENTER);

        GridBagConstraints gbcCenter = new GridBagConstraints();
        gbcCenter.fill = GridBagConstraints.BOTH;
        gbcCenter.weighty = 1.0;
        
        // 1. Panel Llista (Esquerra) 
        gbcCenter.gridx = 0; gbcCenter.weightx = 0.3; gbcCenter.insets = new Insets(0, 0, 0, 10); 
        center.add(crearPanelPreguntas("1. Selecciona Preguntes", listaPreguntas), gbcCenter);

        // 2. Panel Taula (Dreta) 
        gbcCenter.gridx = 1; gbcCenter.weightx = 0.7; gbcCenter.insets = new Insets(0, 10, 0, 0);
        center.add(crearPanelResultados("2. Resultat", tablaResultados), gbcCenter);        
        
        center.setFont(new Font("SansSerif", Font.BOLD, 30));

        card.add(center, c);

        /* --- Opcions de clustering --- */
        c.gridy = 2; c.weighty = 0.05;
        c.insets = new Insets(5, 0, 5, 0);

        panelOpciones = new JPanel(new GridLayout(1, 3, 20, 0));
        panelOpciones.setBackground(Color.WHITE);

        /* 1. Algorisme */
        JPanel pAlgoritmo = new JPanel(new GridLayout(3, 1));
        pAlgoritmo.setBackground(Color.WHITE);
        TitledBorder borderAlg = new TitledBorder("Algorisme Cluster");
        borderAlg.setTitleFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 25));
        pAlgoritmo.setBorder(borderAlg);

        rbBasic = new JRadioButton("basic", true);
        rbKmeans = new JRadioButton("k-means");
        rbKmedoids = new JRadioButton("k-methoids");
        rbBasic.setFont(new Font("SansSerif", Font.PLAIN, 30));
        rbKmeans.setFont(new Font("SansSerif", Font.PLAIN, 30));
        rbKmedoids.setFont(new Font("SansSerif", Font.PLAIN, 30));

        configurarRadio(rbBasic); configurarRadio(rbKmeans); configurarRadio(rbKmedoids);
        grupoAlgoritmo = new ButtonGroup();
        grupoAlgoritmo.add(rbBasic); grupoAlgoritmo.add(rbKmeans); grupoAlgoritmo.add(rbKmedoids);
        pAlgoritmo.add(rbBasic); pAlgoritmo.add(rbKmeans); pAlgoritmo.add(rbKmedoids);

        /* 2. Inicialització */
        JPanel pInicializacion = new JPanel(new GridLayout(2, 1));
        pInicializacion.setBackground(Color.WHITE);
        TitledBorder borderIni = new TitledBorder("Inicialització");
        borderIni.setTitleFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 25));
        pInicializacion.setBorder(borderIni);

        rbRandom = new JRadioButton("random", true);
        rbKmeansPlus = new JRadioButton("k-means++");
        rbRandom.setFont(new Font("SansSerif", Font.PLAIN, 30));
        rbKmeansPlus.setFont(new Font("SansSerif", Font.PLAIN, 30));

        configurarRadio(rbRandom); configurarRadio(rbKmeansPlus);
        grupoInicializacion = new ButtonGroup();
        grupoInicializacion.add(rbRandom); grupoInicializacion.add(rbKmeansPlus);
        pInicializacion.add(rbRandom); pInicializacion.add(rbKmeansPlus);

        /* 3. Spinner */
        JPanel pClusters = new JPanel(new GridBagLayout()); 
        pClusters.setBackground(Color.WHITE);
        TitledBorder borderClust = new TitledBorder("nº Clusters");
        borderClust.setTitleFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 25));
        pClusters.setBorder(borderClust);

        spinClusters = new JSpinner(new SpinnerNumberModel(2, 2, 100, 1));
        spinClusters.setFont(new Font("SansSerif", Font.BOLD, 100));
        spinClusters.setPreferredSize(new Dimension(160, 160));
        pClusters.add(spinClusters);

        panelOpciones.add(pAlgoritmo);
        panelOpciones.add(pInicializacion);
        panelOpciones.add(pClusters);

        card.add(panelOpciones, c);

        /* --- Botons inferiors --- */
        c.gridy = 3; c.weighty = 0.065;
        c.insets = new Insets(15, 0, 0, 0);

        JPanel pBtn = new JPanel(new GridLayout(1, 2, 20, 0));
        pBtn.setBackground(Color.WHITE);

        JButton btnBack = new JButton("Tornar");
        btnBack.setFont(new Font("SansSerif", Font.BOLD, 50));
        btnBack.addActionListener(e -> ctrl.irAMenu());

        JButton btnGen = new JButton("EXECUTAR CLUSTER");
        btnGen.setFont(new Font("SansSerif", Font.BOLD, 50));
        btnGen.setBackground(new Color(0, 150, 136));
        btnGen.setForeground(Color.WHITE);
        btnGen.addActionListener(e -> ejecutar());

        pBtn.add(btnBack); pBtn.add(btnGen);
        card.add(pBtn, c);
    }

    private void configurarRadio(JRadioButton rb) {
        rb.setBackground(Color.WHITE);
    }

    /**
     * @brief Crea el panell de resultats amb l'etiqueta Silhouette.
     */
    private JPanel crearPanelResultados(String titulo, JTable tabla) {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0; gbc.gridx = 0;

        // 1. Títol
        gbc.gridy = 0; gbc.weighty = 0.05;
        JLabel lbl = new JLabel(titulo, SwingConstants.CENTER);
        lbl.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 30));
        lbl.setForeground(new Color(0, 150, 136));       
        p.add(lbl, gbc);

        // 2. Etiqueta Silhouette
        gbc.gridy = 1; gbc.weighty = 0.05;
        p.add(lblSilhouette, gbc);

        
        // 3. Taula de resultats
        gbc.gridy = 2; gbc.weighty = 0.9;
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        p.add(scroll, gbc);

        return p;
    }

    /**
     * @brief Crea el panell de preguntes AMB EL BOTÓ "Seleccionar Tot".
     */
    private JPanel crearPanelPreguntas(String titulo, JList<String> lista) {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0; gbc.gridx = 0;

        // 1. Títol
        gbc.gridy = 0; gbc.weighty = 0.1;
        JLabel lbl = new JLabel(titulo, SwingConstants.CENTER);
        lbl.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 30));
        lbl.setForeground(new Color(0, 150, 136));       
        p.add(lbl, gbc);

        // 2. Botó "Seleccionar Tot"
        gbc.gridy = 1; gbc.weighty = 0.05;
        gbc.fill = GridBagConstraints.NONE; 
        gbc.insets = new Insets(0, 0, 5, 0); 
        
    
        JButton btnAll = new JButton("Seleccionar Tot");
        btnAll.setFont(new Font("SansSerif", Font.BOLD, 22));
        btnAll.setBackground(new Color(225, 245, 254));
        btnAll.setFocusPainted(false);
        btnAll.addActionListener(e -> {
            int size = modelPreguntas.getSize();
            if (size > 0) {
                int[] indices = new int[size];
                for (int i = 0; i < size; i++) indices[i] = i;
                lista.setSelectedIndices(indices);
            }
        });
        p.add(btnAll, gbc);

        // 3. Llista
        gbc.gridy = 2; gbc.weighty = 0.85;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(0, 0, 0, 0);
        p.add(new JScrollPane(lista), gbc);

        return p;
    }

    /** @brief Carrega les enquestes de l'usuari actual al comboBox. */
    public void cargarEnquestas() {
        comboEnquestes.removeAllItems();
        Set<String> s = ctrl.getCD().getEnquestesDeUsuari(ctrl.getUsuarioActual());
        for (String t : s) comboEnquestes.addItem(t);
        modelTabla.setRowCount(0); 
        modelTabla.setColumnCount(0);
        modelPreguntas.clear();
        lblSilhouette.setText("Silhouette: -");
    }

    /** @brief Carrega les preguntes de l'enquesta seleccionada a la llista. */
    private void cargarPreguntas() {
        modelPreguntas.clear();
        String t = (String) comboEnquestes.getSelectedItem();
        if (t == null) return;

        ArrayList<String> preguntes = ctrl.getPreguntesEnquesta(t);
        for (int i = 0; i < preguntes.size(); i++)
            modelPreguntas.addElement((i + 1) + ". " + preguntes.get(i));
    }

    /** @brief Executa el clustering amb les opcions seleccionades i mostra els resultats. */
    private void ejecutar() {
        String t = (String) comboEnquestes.getSelectedItem();
        int[] idxs = listaPreguntas.getSelectedIndices();
        if(idxs.length == 0) { 
            JOptionPane.showMessageDialog(this, "Selecciona preguntes."); 
            return; 
        }
        
        int k = (Integer) spinClusters.getValue();

        int numResp = ctrl.getCD().getNumRespostes(t);
        if (numResp <= k) {
            JOptionPane.showMessageDialog(this, 
                "No es pot executar el clustering:\n" +
                "Has demanat " + k + " clusters, però només hi ha " + numResp + " respostes.", 
                "Error: Manca de dades", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        ctrl.setValorK(t, k); 

        int opcioIni = rbKmeansPlus.isSelected() ? 1 : 0;
        int opcioCluster = rbKmeans.isSelected() ? 1 : (rbKmedoids.isSelected() ? 2 : 0);

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintStream ps = new PrintStream(baos);
        PrintStream oldOut = System.out;
        System.setOut(ps);

        try {
            System.out.println(">>> LOGS START");
            ctrl.getCD().imputarNulls(t);
            
            Set<Integer> s = new HashSet<>(); 
            for(int i : idxs) s.add(i + 1);
            
            ctrl.getCD().generarCluster(t, s, opcioIni, opcioCluster);
            ctrl.getCD().veureResultatsEnquesta(t);
            
        } catch(Exception e) { 
            System.out.println("ERROR: " + e.getMessage()); 
        } finally { 
            System.out.flush(); 
            System.setOut(oldOut); 
        }
        
        parsearResultadosCluster(baos.toString());
        
        float sil = ctrl.getSilhouette(t);
        lblSilhouette.setText("Silhouette: " + String.format(Locale.US, "%.4f", sil));
        if (sil > 0.5) lblSilhouette.setForeground(new Color(76, 175, 80)); 
        else lblSilhouette.setForeground(Color.GRAY);
    }

    /** 
     * @brief Parsea el text brut dels resultats del clustering i actualitza la taula.
     * 
     * @param rawText Text brut amb els resultats del clustering.
     */
    private void parsearResultadosCluster(String rawText) {
        modelTabla.setRowCount(0);
        modelTabla.setColumnCount(0);

        String[] lines = rawText.split("\\r?\\n");
        boolean headersFound = false;

        for (String line : lines) {
            line = line.trim();
            if (line.isEmpty()) continue;
            
            if (!line.contains("|")) continue;
            if (line.contains("-") && line.contains("+") && !line.matches(".*[a-zA-Z0-9].*")) continue;

            String[] parts = line.split("\\|");
            Vector<String> rowData = new Vector<>();
            
            for (String part : parts) {
                if (!part.trim().isEmpty()) {
                    rowData.add(formatearDecimal(part.trim()));
                }
            }
            if (rowData.size() >= 2) {
                String ultimoValor = rowData.remove(rowData.size() - 1); 
                rowData.add(1, ultimoValor); 
                
                while (rowData.size() > 2) rowData.remove(rowData.size() - 1);
            }

            if (!headersFound) {
                for (String header : rowData) {
                    modelTabla.addColumn(header);
                }
                TableColumnModel cm = tablaResultados.getColumnModel();
                if (cm.getColumnCount() > 0) cm.getColumn(0).setPreferredWidth(700);
                if (cm.getColumnCount() > 1) cm.getColumn(1).setPreferredWidth(299);
                headersFound = true;
            } else {
                if (rowData.size() > 0) {
                    modelTabla.addRow(rowData);
                }
            }
        }

        if (modelTabla.getColumnCount() == 0) {
            modelTabla.addColumn("Informació");
            modelTabla.addRow(new String[]{"No s'han generat resultats."});
        }
    }

    /**
     * @brief Intenta formatar un string numèric amb 3 decimals (Locale.US).
     *
     * Si `valor` no representa un decimal, es retorna tal qual.
     *
     * @param valor String que pot contenir un nombre decimal.
     * @return String formatat amb 3 decimals o el valor original si no es pot parsejar.
     */
    private String formatearDecimal(String valor) {
        if (valor == null) return "NULL";
        try {
            if (valor.contains(".")) {
                double d = Double.parseDouble(valor);
                return String.format(Locale.US, "%.3f", d);
            }
        } catch (NumberFormatException e) { 
        }
        return valor;
    }
}