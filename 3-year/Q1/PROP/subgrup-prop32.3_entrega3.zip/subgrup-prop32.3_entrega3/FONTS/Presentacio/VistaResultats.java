/*
 +----------------------------------------------------------+
 |                VistaResultats.java                       |
 +----------------------------------------------------------+
 | Repositori:                                              |
 |   · subgrup-prop32.3                                     |
 +----------------------------------------------------------+
 | Aquest mòdul ha sigut programat per:                     |
 |   · Gabriel Alegre Conchello                             |
 |   · Santiago Lluzar Frias                                |
 +----------------------------------------------------------+
 */

package FONTS.Presentacio;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.Set;
import java.util.Vector;
import java.util.Locale;

import FONTS.Domini.Enquesta;
import FONTS.Domini.Pregunta;

/**
 * @file VistaResultats.java
 * @brief Vista gràfica per consultar els resultats d'una enquesta.
 */

/**
 * @class VistaResultats
 * @brief Panell de la capa de presentació que permet
 * visualitzar els resultats detallats d'una enquesta.
 *
 * @details Aquesta vista:
 * - Permet seleccionar una enquesta de l'usuari.
 * - Executa la consulta de resultats.
 * - Mostra els resultats en format taula (Usuari x Preguntes).
 */
public class VistaResultats extends JPanel {

    /** @brief Controlador de presentació associat a la vista. */
    private CtrlPresentacion ctrl;

    /** @brief ComboBox amb la llista d'enquestes de l'usuari. */
    private JComboBox<String> comboEnquestes;

    /** @brief Taula on es mostren els resultats detallats. */
    private JTable tablaResultados;

    /** @brief Model de dades per a la taula. */
    private DefaultTableModel modelTabla;

    /**
     * @brief Constructor de la vista de resultats.
     *
     * @param ctrl Controlador de presentació que gestiona
     * la comunicació amb la capa de domini.
     */
    public VistaResultats(CtrlPresentacion ctrl) {
        this.ctrl = ctrl;

        /* --- Layout principal --- */
        setLayout(new GridBagLayout());
        setBackground(new Color(240, 242, 245));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1.0;

        /* --- Marges laterals --- */
        gbc.gridx = 0;
        gbc.weightx = 0.1;
        add(Box.createGlue(), gbc);

        gbc.gridx = 2;
        gbc.weightx = 0.1;
        add(Box.createGlue(), gbc);

        /* --- Carta central --- */
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(new CompoundBorder(
            new LineBorder(Color.LIGHT_GRAY, 1, true),
            new EmptyBorder(20, 20, 20, 20)
        ));

        gbc.gridx = 1;
        gbc.weightx = 0.8;
        gbc.insets = new Insets(30, 0, 30, 0);
        add(card, gbc);

        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH;
        c.weightx = 1.0;
        c.gridx = 0;

        /* --- Panell superior: selecció --- */
        c.gridy = 0;
        c.weighty = 0.1;

        JPanel top = new JPanel(new GridBagLayout());
        top.setBackground(Color.WHITE);

        JLabel lbl = new JLabel("Selecciona Enquesta:");
        lbl.setFont(new Font("SansSerif", Font.BOLD, 40));

        comboEnquestes = new JComboBox<>();
        comboEnquestes.setFont(new Font("SansSerif", Font.PLAIN, 50));
        comboEnquestes.setPreferredSize(new Dimension(800, 60));

        JButton btnVer = new JButton("Consultar");
        btnVer.setFont(new Font("SansSerif", Font.BOLD, 40));
        btnVer.setBackground(new Color(33, 150, 243));
        btnVer.setForeground(Color.WHITE);
        btnVer.addActionListener(e -> mostrar());

        GridBagConstraints ch = new GridBagConstraints();
        ch.fill = GridBagConstraints.BOTH;
        ch.insets = new Insets(5, 5, 5, 5);
        ch.weighty = 1.0;

        ch.gridx = 0; ch.weightx = 0.2; top.add(lbl, ch);
        ch.gridx = 1; ch.weightx = 0.6; top.add(comboEnquestes, ch);
        ch.gridx = 2; ch.weightx = 0.2; top.add(btnVer, ch);

        card.add(top, c);

        /* --- Panell central: resultats --- */
        c.gridy = 1;
        c.weighty = 0.8;
        c.insets = new Insets(10, 0, 10, 0);

        JPanel center = new JPanel(new GridBagLayout());
        center.setBackground(Color.WHITE);

        GridBagConstraints cc = new GridBagConstraints();
        cc.fill = GridBagConstraints.BOTH;
        cc.weightx = 1.0;
        cc.gridx = 0;

        cc.gridy = 0;
        cc.weighty = 0.15;

        JLabel lblRes = new JLabel("Resultats Detallats", SwingConstants.CENTER);
        lblRes.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 40));
        lblRes.setForeground(new Color(33, 150, 243));
        center.add(lblRes, cc);

        cc.gridy = 1;
        cc.weighty = 0.85;

        // Configuració de la Taula
        modelTabla = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; 
            }
        };
        
        tablaResultados = new JTable(modelTabla);
        
        tablaResultados.setFont(new Font("SansSerif", Font.PLAIN, 30));
        tablaResultados.setRowHeight(50); 
        tablaResultados.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 30));
        tablaResultados.getTableHeader().setPreferredSize(new Dimension(0, 50));
        
        tablaResultados.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        JScrollPane scroll = new JScrollPane(tablaResultados);
        scroll.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        
        center.add(scroll, cc);

        card.add(center, c);

        /* --- Botó tornar --- */
        c.gridy = 2;
        c.weighty = 0.1;
        c.insets = new Insets(15, 100, 5, 100);

        JButton btnBack = new JButton("Tornar al Menú");
        btnBack.setFont(new Font("SansSerif", Font.BOLD, 50));
        btnBack.addActionListener(e -> ctrl.irAMenu());

        card.add(btnBack, c);
    }

    /**
     * @brief Carrega la llista d'enquestes de l'usuari actual.
     */
    public void cargarEnquestas() {
        comboEnquestes.removeAllItems();
        Set<String> s = ctrl.getCD().getEnquestesDeUsuari(ctrl.getUsuarioActual());
        for (String t : s) comboEnquestes.addItem(t);
        modelTabla.setRowCount(0);
        modelTabla.setColumnCount(0);
    }

    /**
     * @brief Mostra els resultats demanant les dades primitives al Controlador.
     */
    private void mostrar() {
        String t = (String) comboEnquestes.getSelectedItem();
        if (t == null) return;

        ArrayList<String> headers = ctrl.getHeadersEncuesta(t);
        if (headers.isEmpty()) return;

        modelTabla.setColumnCount(0);
        for (String h : headers) {
            modelTabla.addColumn(h);
        }

        TableColumnModel cm = tablaResultados.getColumnModel();
        for (int i = 0; i < cm.getColumnCount(); i++) {
            cm.getColumn(i).setPreferredWidth(300);
        }

        ArrayList<ArrayList<String>> dades = ctrl.getDataEncuesta(t);
        
        modelTabla.setRowCount(0);
        for (ArrayList<String> fila : dades) {
            Vector<String> filaVector = new Vector<>();
            for (String celda : fila) {
                filaVector.add(formatearDecimal(celda));
            }
            modelTabla.addRow(filaVector);
        }
    }

    /**
     * @brief Formateja strings numèrics per mostrar només 3 decimals.
     */
    private String formatearDecimal(String valor) {
        if (valor == null) return "NULL";
        try {
            if (valor.contains(".")) {
                double d = Double.parseDouble(valor);
                return String.format(Locale.US, "%.3f", d);
            }
        } catch (NumberFormatException e) {
        }
        return valor;
    }
}