#!/bin/bash

java -cp "../LIBS/*:../CLASSES" org.junit.runner.JUnitCore FONTS.Drivers.driverPregunta.driverPreguntaMultichoice

java -cp "../LIBS/*:../CLASSES" org.junit.runner.JUnitCore FONTS.Drivers.driverPregunta.driverPreguntaLliure
