#!/bin/bash

java -cp "../LIBS/*:../CLASSES" org.junit.runner.JUnitCore FONTS.Drivers.driverResposta.driverRespostaMultichoice

java -cp "../LIBS/*:../CLASSES" org.junit.runner.JUnitCore FONTS.Drivers.driverResposta.driverRespostaText

java -cp "../LIBS/*:../CLASSES" org.junit.runner.JUnitCore FONTS.Drivers.driverResposta.driverRespostaNum
