#!/bin/bash

java -cp "../LIBS/*:../CLASSES" org.junit.runner.JUnitCore FONTS.Drivers.driverAnalisiCluster.driverKmeans

java -cp "../LIBS/*:../CLASSES" org.junit.runner.JUnitCore FONTS.Drivers.driverAnalisiCluster.driverKmeansPlus

java -cp "../LIBS/*:../CLASSES" org.junit.runner.JUnitCore FONTS.Drivers.driverAnalisiCluster.driverInicialitzacioKmeansPlus

java -cp "../LIBS/*:../CLASSES" org.junit.runner.JUnitCore FONTS.Drivers.driverAnalisiCluster.driverInicialitzacioRandom

java -cp "../LIBS/*:../CLASSES" org.junit.runner.JUnitCore FONTS.Drivers.driverAnalisiCluster.driverKmedoids

java -cp "../LIBS/*:../CLASSES" org.junit.runner.JUnitCore FONTS.Drivers.driverAnalisiCluster.driverKmedoidsPlus
