#!/bin/bash
java -cp ../CLASSES FONTS.Domini.Main
