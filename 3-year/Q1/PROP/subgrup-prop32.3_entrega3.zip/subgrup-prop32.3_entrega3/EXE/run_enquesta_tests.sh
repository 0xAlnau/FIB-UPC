#!/bin/bash

java -cp "../LIBS/*:../CLASSES" org.junit.runner.JUnitCore FONTS.Drivers.driversEnquesta.driverTotesFuncionsEnquesta
