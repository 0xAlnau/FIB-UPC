#!/bin/bash
# executa tots els drivers que estan a partir de exe
java -cp "../LIBS/*:../CLASSES" org.junit.runner.JUnitCore FONTS.Drivers.driversEnquesta.driverTotesFuncionsEnquesta

java -cp "../LIBS/*:../CLASSES" org.junit.runner.JUnitCore FONTS.Drivers.driverResposta.driverRespostaMultichoice

java -cp "../LIBS/*:../CLASSES" org.junit.runner.JUnitCore FONTS.Drivers.driverResposta.driverRespostaText

java -cp "../LIBS/*:../CLASSES" org.junit.runner.JUnitCore FONTS.Drivers.driverResposta.driverRespostaNum

java -cp "../LIBS/*:../CLASSES" org.junit.runner.JUnitCore FONTS.Drivers.driverPregunta.driverPreguntaMultichoice

java -cp "../LIBS/*:../CLASSES" org.junit.runner.JUnitCore FONTS.Drivers.driverPregunta.driverPreguntaLliure

java -cp "../LIBS/*:../CLASSES" org.junit.runner.JUnitCore FONTS.Drivers.driverUsuari.driverUsuari

java -cp "../LIBS/*:../CLASSES" org.junit.runner.JUnitCore FONTS.Drivers.driverAnalisiCluster.driverKmeans

java -cp "../LIBS/*:../CLASSES" org.junit.runner.JUnitCore FONTS.Drivers.driverAnalisiCluster.driverKmeansPlus

java -cp "../LIBS/*:../CLASSES" org.junit.runner.JUnitCore FONTS.Drivers.driverAnalisiCluster.driverInicialitzacioKmeansPlus

java -cp "../LIBS/*:../CLASSES" org.junit.runner.JUnitCore FONTS.Drivers.driverAnalisiCluster.driverInicialitzacioRandom

java -cp "../LIBS/*:../CLASSES" org.junit.runner.JUnitCore FONTS.Drivers.driverAnalisiCluster.driverKmedoids

java -cp "../LIBS/*:../CLASSES" org.junit.runner.JUnitCore FONTS.Drivers.driverAnalisiCluster.driverKmedoidsPlus


#caldrà posar una linia nova canviant nomes EXE. ... . ...
