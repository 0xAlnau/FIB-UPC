# PROP Grup 32.3
Projecte de Programació, Grup 32, subgrup 32.3.  
Professor: Ignasi Gómez (ignasi.gomez@upc.edu).

## Membres del grup
· Alegre Conchello, Gabriel (gabriel.alegre@estudiantat.upc.edu)  
· Cullell Martínez, Arnau (arnau.cullell@estudiantat.upc.edu)  
· Domínguez Buira, Àngel (angel.dominguez@estudiantat.upc.edu)  
· Lluzar Frías, Santiago (santiago.lluzar@estudiantat.upc.edu)

---

## Elements del directori

### **DOCS**
Conté tota la documentació del projecte:  
- Diagrama de casos d’ús i la descripció de cadascun  
- Diagrama estàtic complet de la capa Domini en versió de disseny
- Diagrama estàtic complet de la capa Presentació en versió de disseny  
- Diagrama estàtic complet de la capa Persistència en versió de disseny    
- Descripció dels atributs i mètodes de les classes  
- Relació de les classes implementades per cada membre  
- Descripció d’estructures de dades i algorismes utilitzats

### **EXE**
Conté tots els scripts .sh per executar tots els testos del projecte.

### **FONTS**
Conté tots els .java del projecte. Aquests estan dividits en diferents carpetes depenent de a quina capa pertanyen:
- Domini: hi ha classes com Cluster, AnalisiCluster, Usuari, Pregunta, Enquesta, CtrlDominio, ...
- Presentació: conté CtrlPresentacio, VistaLogin, VistaMenu, VistaCrear, ...
- Persistència: podem trobar classes com CtrlPersistencia, CtrlPersistenciaEnquesta i CtrlPersistenciaUsuari. També hi ha els fitxers .csv on es guarda la informació.

### **LIBS**
Llibreries externes necessàries, especialment per a l’ús de JUnit i Mockito.



