# Extractor de prototipus de comportaments o perfils
· Integrants del grup:

    · Alegre Conchello, Gabriel

    · Cullell Martínez, Arnau

    · Domínguez Buira, Àngel

    · Lluzar Frías, Santiago

· E-mail's dels integrants:

    · gabriel.alegre@estudiantat.upc.edu

    · arnau.cullell@estudiantat.upc.edu

    · angel.dominguez@estudiantat.upc.edu

    · santiago.lluzar@estudiantat.upc.edu
