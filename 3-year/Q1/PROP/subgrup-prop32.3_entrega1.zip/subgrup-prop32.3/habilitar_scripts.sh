#!/bin/bash

chmod +x compilar_tot.sh
sed -i 's/\r$//' compilar_tot.sh

chmod +x compilar_domini.sh
sed -i 's/\r$//' compilar_domini.sh

chmod +x compilar_drivers.sh
sed -i 's/\r$//' compilar_drivers.sh

chmod +x compilar_interactiu.sh
sed -i 's/\r$//' compilar_interactiu.sh

chmod +x run_all_tests.sh
sed -i 's/\r$//' run_all_tests.sh

chmod +x run_analisiCluster_tests.sh
sed -i 's/\r$//' run_analisiCluster_tests.sh

chmod +x run_enquesta_tests.sh
sed -i 's/\r$//' run_enquesta_tests.sh

chmod +x run_respostes_tests.sh
sed -i 's/\r$//' run_respostes_tests.sh

chmod +x run_preguntes_tests.sh
sed -i 's/\r$//' run_preguntes_tests.sh

chmod +x run_usuari_tests.sh
sed -i 's/\r$//' run_usuari_tests.sh

chmod +x run_driverInteractiu_tests.sh
sed -i 's/\r$//' run_driverInteractiu_tests.sh

chmod +x run_main.sh
sed -i 's/\r$//' run_main.sh
