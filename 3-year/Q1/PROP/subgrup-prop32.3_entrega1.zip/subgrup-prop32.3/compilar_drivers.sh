#!/bin/bash

# el mateix amb els .java de EXE, agafa les llibreries de Junit4 i els .class dels .java del domini
javac -cp "LIBS/*:CLASSES" -d CLASSES EXE/*/*.java