#!/bin/bash

java -cp "LIBS/*:CLASSES" org.junit.runner.JUnitCore EXE.driversUsuari.driverUsuari
