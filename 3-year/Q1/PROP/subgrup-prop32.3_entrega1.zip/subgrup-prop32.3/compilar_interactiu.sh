#!/bin/bash

# test interactiu
javac -cp "LIBS/*:CLASSES" -d CLASSES TESTS/*.java
