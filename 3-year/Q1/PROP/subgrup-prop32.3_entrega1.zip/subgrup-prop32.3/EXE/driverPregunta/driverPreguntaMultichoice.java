/*    +----------------------------------------------------------+
      |             driverPreguntaMultichoice.java               |
      +----------------------------------------------------------+
      | Repositori:                                              |
      |   ·subgrup-prop32.3                                      |
      +----------------------------------------------------------+
      | Aquest mòdul ha sigut programat per:                     |
      |   ·Santiago Lluzar                                       |
      +----------------------------------------------------------+
      | *Versió 1.1: Driver JUnit per a PreguntaMultichoice      |
      |              Prova els casos erronis del constructor,    |
      |              incloent els de la superclasse.             |
      +----------------------------------------------------------+
*/

package EXE.driverPregunta;

import FONTS.*; 
import static org.junit.Assert.*;
import org.junit.Test;
import java.util.List; 
import java.util.ArrayList;

/** @class driverPreguntaMultichoice
    @brief Driver de JUnit per a la classe PreguntaMultichoice.
*/
public class driverPreguntaMultichoice {

//--------------------COMPROVAR LA SUPERCLASSE (Pregunta)--------------------

    @Test(expected = InvalidPreguntaException.class)
    public void testConstructorTextBuit() throws InvalidPreguntaException {
        // Comprova if (text.trim().isEmpty())
        List<String> opcions = List.of("A", "B", "C"); 
        new PreguntaMultichoice("   ", opcions, 1);  
    }

    @Test(expected = InvalidPreguntaException.class)
    public void testConstructorTextNul() throws InvalidPreguntaException {
        // Comprova if (text == null ...)
        List<String> opcions = List.of("A", "B", "C"); 
        new PreguntaMultichoice(null, opcions, 1); 
    }

//------------------------------------------------------------------------

    @Test
    public void testConstructorCasValid() throws InvalidPreguntaException {
        List<String> opcions = List.of("A", "B", "C"); 
        PreguntaMultichoice preg = new PreguntaMultichoice("Tria", opcions, 2);
        
        assertNotNull(preg);
        assertEquals(2, preg.getLimitOpcions());
        assertEquals(3, preg.getOpcions().size());
    }

    @Test(expected = InvalidPreguntaException.class)
    public void testConstructorOpcionsBuides() throws InvalidPreguntaException {
        // Cas erroni: llista d'opcions buida
        List<String> opcionsBuides = new ArrayList<>();
        new PreguntaMultichoice("Tria", opcionsBuides, 1);
    }

    @Test(expected = InvalidPreguntaException.class)
    public void testConstructorOpcionsNules() throws InvalidPreguntaException {
        // Cas erroni: llista d'opcions és nul·la
        new PreguntaMultichoice("Tria", null, 1);
    }

    @Test(expected = InvalidPreguntaException.class)
    public void testConstructorLimitInvalid() throws InvalidPreguntaException {
        List<String> opcions = List.of("A", "B", "C");
        // Cas erroni: límit 0 o negatiu
        new PreguntaMultichoice("Tria", opcions, 0);
    }
    
    @Test(expected = InvalidPreguntaException.class)
    public void testConstructorLimitExcedit() throws InvalidPreguntaException {
        List<String> opcions = List.of("A", "B", "C"); // Mida = 3
        // Cas erroni: límit més gran que el nombre d'opcions
        new PreguntaMultichoice("Tria", opcions, 4); // Limit 4, Opcions 3
    }
}