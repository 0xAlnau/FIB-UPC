/* +----------------------------------------------------------+
      |               driverAnalisiCluster.java                  |
      +----------------------------------------------------------+
      | Repositori:                                              |
      |   ·subgrup-prop32.3                                      |
      +----------------------------------------------------------+
      | Aquest mòdul ha sigut programat per:                     |
      |   Angel Dominguez                                        |
      +----------------------------------------------------------+
      | *Versió 1.1: Corregits imports i tipus de dades.         |
      |              Inicialitzat 'nullList' per evitar NPE.     |
      +----------------------------------------------------------+
*/

package EXE.driversAnalisiCluster;

// --- Imports ---
import FONTS.*; 
import static org.junit.Assert.*;
import org.junit.Test;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
// -------------------------

public class driverAnalisiCluster {

    /* ------------------------------------------------------------- */
    /* ----------------- FUNCIONES AUXILIARES (STUBS) ----------------- */
    /* ------------------------------------------------------------- */

    // Stub per a preguntes numèriques (cas vàlid)
    private PreguntaLliure crearPreguntaNumStub() throws InvalidPreguntaException {
        return new PreguntaLliure("StubNum", 20, true);
    }
    
    // Stub per a preguntes de text (cas vàlid)
    private PreguntaLliure crearPreguntaTextStub() throws InvalidPreguntaException {
        return new PreguntaLliure("StubText", 80, false);
    }

    // Aquestes funcions ara necessiten una Pregunta real per no fallar
    private RespostaInd rn(Pregunta p, float v) throws InvalidRespostaException {
        return new RespostaNum(p, "stubUser", v);
    }

    private RespostaInd rt(Pregunta p, String s) throws InvalidRespostaException {
        return new RespostaText(p, "stubUser", s);
    }

    /* Crea matriz NxM de RespostaNum */
    private RespostaInd[][] matrizNum(float[][] data) throws Exception {
        int n = data.length;
        int m = data[0].length;
        RespostaInd[][] r = new RespostaInd[n][m];
        
        // Creem M preguntes stub (una per a cada columna)
        Pregunta[] preguntaStubs = new Pregunta[m];
        for (int j = 0; j < m; j++) {
            preguntaStubs[j] = crearPreguntaNumStub();
        }

        for (int i = 0; i < n; ++i)
            for (int j = 0; j < m; ++j)
                r[i][j] = rn(preguntaStubs[j], data[i][j]); // Passem el stub
        return r;
    }

    /* Crea matriz NxM de texto */
    private RespostaInd[][] matrizText(String[][] data) throws Exception {
        int n = data.length;
        int m = data[0].length;
        RespostaInd[][] r = new RespostaInd[n][m];
        
        // Creem M preguntes stub (una per a cada columna)
        Pregunta[] preguntaStubs = new Pregunta[m];
        for (int j = 0; j < m; j++) {
            preguntaStubs[j] = crearPreguntaTextStub();
        }

        for (int i = 0; i < n; ++i)
            for (int j = 0; j < m; ++j)
                r[i][j] = rt(preguntaStubs[j], data[i][j]); // Passem el stub
        return r;
    }

    
    private Boolean[] crearNullList(int n) {
        Boolean[] nullList = new Boolean[n];
        Arrays.fill(nullList, false); // Inicialitzem tots a 'false' 
        return nullList;
    }

    /* ------------------------------------------------------------- */
    /* ----------------------- TESTS BÁSICOS ------------------------ */
    /* ------------------------------------------------------------- */

    @Test
    public void testCreacion() throws Exception {
        float[][] data = {
                {1, 1, 1},
                {2, 2, 2},
                {9, 9, 9}
        };
        int n = data.length; int m = data[0].length;
        Boolean[] nullList = crearNullList(n); 

        AnalisiCluster ac = new AnalisiCluster(matrizNum(data), 2, nullList, n, m);
        assertNotNull(ac);
    }

    @Test
    public void testAsignacionesValidas() throws Exception {
        float[][] data = {
                {1, 1},
                {2, 2},
                {8, 8},
                {9, 9}
        };
        int n = data.length; int m = data[0].length;
        Boolean[] nullList = crearNullList(n); 

        AnalisiCluster ac = new AnalisiCluster(matrizNum(data), 2, nullList, n, m);
        Integer[] assig = ac.getAssignacions(); 

        assertEquals(4, assig.length);
        for (Integer x : assig) 
            if (x != null) assertTrue(x == 0 || x == 1);
    }

    /* ------------------------------------------------------------- */
    /* -------------------- TESTS DE COHERENCIA -------------------- */
    /* ------------------------------------------------------------- */

    @Test
    public void testGruposSeparados() throws Exception {
        float[][] data = {
                {1, 1},
                {2, 2},
                {10, 10},
                {11, 11}
        };
        int n = data.length; int m = data[0].length;
        Boolean[] nullList = crearNullList(n); 

        AnalisiCluster ac = new AnalisiCluster(matrizNum(data), 2, nullList, n, m);
        Integer[] a = ac.getAssignacions(); 

        // 1er cluster
        assertEquals(a[0], a[1]);

        // 2º cluster
        assertEquals(a[2], a[3]);

        // Deben ser distintos entre ellos
        assertNotEquals(a[0], a[2]);
    }

    @Test
    public void testValoresIdenticos() throws Exception {
        float[][] data = {
                {5,5},
                {5,5},
                {5,5},
                {5,5}
        };
        int n = data.length; int m = data[0].length;
        Boolean[] nullList = crearNullList(n); 

        AnalisiCluster ac = new AnalisiCluster(matrizNum(data), 2, nullList, n, m);
        Integer[] a = ac.getAssignacions(); 

        // no importa qué cluster asignen, pero debe ser consistente
        assertNotNull(a);
        assertEquals(4, a.length);
    }

    @Test
    public void testCentroidesCorrectos() throws Exception {
        float[][] data = {
                {1, 1},
                {2, 2},
                {100, 100}
        };
        int n = data.length; int m = data[0].length;
        Boolean[] nullList = crearNullList(n); 

        AnalisiCluster ac = new AnalisiCluster(matrizNum(data), 2, nullList, n, m);
        RespostaInd[][] cent = ac.getCentroides();

        assertNotNull(cent);

        // centroides tienen tamaño k x nPreg
        assertEquals(2, cent.length);
        assertEquals(2, cent[0].length);
    }

    /* ------------------------------------------------------------- */
    /* ---------------------- TESTS DE TEXTO ------------------------ */
    /* ------------------------------------------------------------- */

    @Test
    public void testTextoSimple() throws Exception {
        String[][] data = {
                {"Hola"},
                {"hola"},
                {"Adios"},
                {"adios"},
        };
        int n = data.length; int m = data[0].length;
        Boolean[] nullList = crearNullList(n); 

        AnalisiCluster ac = new AnalisiCluster(matrizText(data), 2, nullList, n, m);
        Integer[] a = ac.getAssignacions(); 

        assertEquals(4, a.length);
    }

    @Test
    public void testClusterTextoFrec() throws Exception {
        String[][] data = {
                {"gato"},
                {"gato"},
                {"perro"},
                {"perro"},
                {"perro"}
        };
        int n = data.length; int m = data[0].length;
        Boolean[] nullList = crearNullList(n); 

        AnalisiCluster ac = new AnalisiCluster(matrizText(data), 2, nullList, n, m);
        RespostaInd[][] c = ac.getCentroides();

        assertNotNull(c);
    }

    /* ------------------------------------------------------------- */
    /* ------------------- TESTS DE MEZCLA TIPOS ------------------- */
    /* ------------------------------------------------------------- */

    @Test
    public void testMixtoNumYTexto() throws Exception {
        
        Pregunta pNum = crearPreguntaNumStub();
        Pregunta pText = crearPreguntaTextStub();

        RespostaInd[][] r = {
            { rn(pNum, 1), rt(pText, "hola") },
            { rn(pNum, 2), rt(pText, "hola") },
            { rn(pNum, 100), rt(pText, "adios") }
        };
        int n = r.length; int m = r[0].length;
        Boolean[] nullList = crearNullList(n); 

        AnalisiCluster ac = new AnalisiCluster(r, 2, nullList, n, m);
        Integer[] a = ac.getAssignacions(); 

        assertNotNull(a);
        assertEquals(3, a.length);
    }

    /* ------------------------------------------------------------- */
    /* ------------------- TESTS DE CLUSTERS VACÍOS ---------------- */
    /* ------------------------------------------------------------- */

    @Test
    public void testNoClustersVacios() throws Exception {
        float[][] data = {
                {1}, {2}, {3}, {100}
        };
        int n = data.length; int m = data[0].length;
        Boolean[] nullList = crearNullList(n); 

        AnalisiCluster ac = new AnalisiCluster(matrizNum(data), 3, nullList, n, m);
        Integer[] a = ac.getAssignacions(); 

        // Ningún cluster debería quedar vacío (en teoría)
        boolean[] usado = new boolean[3];
        for (Integer x : a) {
            if (x != null) usado[x] = true;
        }

        int usados = 0;
        for (boolean u : usado) if (u) usados++;

        assertTrue(usados >= 2);
    }

    /* ------------------------------------------------------------- */
    /* -------------------- TESTS DE REPRODUCCIÓN ------------------ */
    /* ------------------------------------------------------------- */

    @Test
    public void testRepetibilidad() throws Exception {
        float[][] data = {
                {1}, {2}, {3}, {100}
        };
        int n = data.length; int m = data[0].length;
        Boolean[] nullList = crearNullList(n); 

        AnalisiCluster ac1 = new AnalisiCluster(matrizNum(data), 2, nullList, n, m);
        AnalisiCluster ac2 = new AnalisiCluster(matrizNum(data), 2, nullList, n, m);

        assertEquals(ac1.getAssignacions().length, ac2.getAssignacions().length);
    }

    /* ------------------------------------------------------------- */
    /* ---------------------- TESTS AVANZADOS ----------------------- */
    /* ------------------------------------------------------------- */

    @Test
    public void testClonesIndependientes() throws Exception {
        float[][] data = {
                {1,1},
                {100,100}
        };
        int n = data.length; int m = data[0].length;
        Boolean[] nullList = crearNullList(n); 

        AnalisiCluster ac = new AnalisiCluster(matrizNum(data), 2, nullList, n, m);
        RespostaInd[][] c = ac.getCentroides();

        // cambiar un valor del centroide no debe modificar el original
        float before = ((RespostaNum)c[0][0]).getValor();
        ((RespostaNum)c[0][0]).setValor(999);

        float after = ((RespostaNum)c[0][0]).getValor();

        assertNotEquals(before, after);
    }
}