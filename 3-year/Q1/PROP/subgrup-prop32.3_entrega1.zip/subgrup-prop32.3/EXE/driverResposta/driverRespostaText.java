/*    +----------------------------------------------------------+
      |                 driverRespostaText.java                  |
      +----------------------------------------------------------+
      | Repositori:                                              |
      |   ·subgrup-prop32.3                                      |
      +----------------------------------------------------------+
      | Aquest mòdul ha sigut programat per:                     |
      |   ·santi lluzar                                          |
      +----------------------------------------------------------+
      | *Versió 1.0: Driver JUnit per a RespostaText.            |
      |              Prova el constructor, la distància i        |
      |              la clonació.                                |
      +----------------------------------------------------------+
*/

package EXE.driverResposta;

import FONTS.*; 
import static org.junit.Assert.*;
import org.junit.Test;
import java.util.Set; 
import java.util.HashSet;
import java.util.List;
import java.util.ArrayList;


/** @class driverRespostaText
    @brief Driver de JUnit per a la classe RespostaText.
*/
public class driverRespostaText {

    // Stub per a preguntes de text (cas vàlid)
    private PreguntaLliure crearPreguntaTextStub(int maxCar) throws InvalidPreguntaException {
        return new PreguntaLliure("Pregunta Stub Text", maxCar, false);
    }
    
    // Stub per a preguntes numèriques (cas invàlid)
    private PreguntaLliure crearPreguntaNumStub() throws InvalidPreguntaException {
        return new PreguntaLliure("Pregunta Stub Numèrica", 20, true);
    }

//--------------------COMPROVAR LA SUPERCLASSE---------------------------

    @Test(expected = InvalidRespostaException.class)
    public void testConstructorIdUsuariNull() throws Exception {
        // Comprova (idUsuari == null...) de RespostaInd
        new RespostaText(crearPreguntaTextStub(10), null, "hola");
    }

    @Test(expected = InvalidRespostaException.class)
    public void testConstructorPreguntaNull() throws Exception {
        // Comprova (preguntaAssociada == null) de RespostaInd
        new RespostaText(null, "usuari1", "hola");
    }

//------------------------------------------------------------------------

    @Test(expected = InvalidRespostaException.class)
    public void testConstructorSuperaCaracters() throws Exception {
        // Cas erroni: el text és més llarg que el permès
        new RespostaText(crearPreguntaTextStub(5), "u1", "HolaMon"); // Llargada 7, Max 5
    }

    @Test(expected = InvalidRespostaException.class)
    public void testConstructorPreguntaIncorrecta() throws Exception {
        // Cas erroni: intentem crear RespostaText amb una Pregunta numèrica
        new RespostaText(crearPreguntaNumStub(), "u1", "un text");
    }

    @Test
    public void testConstructorConverteixAMinuscules() throws Exception {
        RespostaText r = new RespostaText(crearPreguntaTextStub(20), "u1", "HOLA");
        assertEquals("hola", r.getValor());
    }

    @Test
    public void testCalcularDistanciaNormalitzada() throws Exception {
        RespostaText r1 = new RespostaText(crearPreguntaTextStub(10), "u1", "casa"); // len=4
        RespostaText r2 = new RespostaText(crearPreguntaTextStub(10), "u2", "cara"); // len=4
        
        // lev = 1; diffAbs = 0; denominador = max(4,4) - 0 = 4
        // Resultat esperat = (1 - 0) / 4 = 0.25
        assertEquals(0.25f, r1.calcularDistancia(r2), 0.001);
    }
    
    @Test
    public void testCalcularDistanciaIguals() throws Exception {
        RespostaText r1 = new RespostaText(crearPreguntaTextStub(10), "u1", "test");
        RespostaText r2 = new RespostaText(crearPreguntaTextStub(10), "u2", "test");
        // Cas límit: són iguals
        assertEquals(RespostaInd.MIN_DISTANCIA, r1.calcularDistancia(r2), 0.001);
    }
    
    @Test
    public void testCalcularDistanciaBuit() throws Exception {
        RespostaText r1 = new RespostaText(crearPreguntaTextStub(10), "u1", "test");
        RespostaText r2 = new RespostaText(crearPreguntaTextStub(10), "u2", "");
        // Cas límit: un és buit
        assertEquals(RespostaInd.MAX_DISTANCIA, r1.calcularDistancia(r2), 0.001);
    }

    @Test
    public void testCalcularDistanciaTipusDiferent() throws Exception {
        RespostaText rText = new RespostaText(crearPreguntaTextStub(10), "u1", "hola");
        RespostaNum rNum = new RespostaNum(crearPreguntaNumStub(), "u2", 123f);

        // Cas erroni: comparar RespostaText amb RespostaNum
        assertEquals(RespostaInd.MAX_DISTANCIA, rText.calcularDistancia(rNum), 0.001);
    }

    @Test
    public void testCalcularDistanciaAmbNul() throws Exception {
        RespostaText r1 = new RespostaText(crearPreguntaTextStub(10), "u1", "test");
        // Cas erroni: comparar amb null
        assertEquals(RespostaInd.MAX_DISTANCIA, r1.calcularDistancia(null), 0.001);
    }
    
    @Test
    public void testClone() throws Exception {
        RespostaText original = new RespostaText(crearPreguntaTextStub(10), "u1", "Hola");
        RespostaText clon = (RespostaText) original.clone();
        
        assertNotSame(original, clon); // Són objectes diferents
        assertEquals(original.getValor(), clon.getValor()); // Tenen el mateix valor
    }
}