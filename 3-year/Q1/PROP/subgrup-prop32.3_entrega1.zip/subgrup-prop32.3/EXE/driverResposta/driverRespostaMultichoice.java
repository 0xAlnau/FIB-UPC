/*    +----------------------------------------------------------+
      |             driverRespostaMultichoice.java               |
      +----------------------------------------------------------+
      | Repositori:                                              |
      |   ·subgrup-prop32.3                                      |
      +----------------------------------------------------------+
      | Aquest mòdul ha sigut programat per:                     |
      |   ·Santiago Lluzar                                       |
      +----------------------------------------------------------+
      | *Versió 1.1: Driver JUnit per a RespostaMultichoice.     |
      |              Prova el constructor, la distància i        |
      |              la clonació.                                |
      +----------------------------------------------------------+
*/

package EXE.driverResposta;

import FONTS.*; 
import static org.junit.Assert.*;
import org.junit.Test;
import java.util.Set; 
import java.util.HashSet;
import java.util.List;
import java.util.ArrayList;

/** @class driverRespostaMultichoice
    @brief Driver de JUnit per a la classe RespostaMultichoice.
*/
public class driverRespostaMultichoice {

    // Stub
    private PreguntaMultichoice crearPreguntaStub() throws InvalidPreguntaException {
        List<String> opcions = List.of("Op0", "Op1", "Op2", "Op3"); // Mida 4
        return new PreguntaMultichoice("Pregunta Stub Multi", opcions, 3); // Limit 3
    }

//--------------------COMPROVAR LA SUPERCLASSE---------------------------

    @Test(expected = InvalidRespostaException.class)
    public void testConstructorIdUsuariNull() throws Exception {
        // Comprova (idUsuari == null...) de RespostaInd
        new RespostaMultichoice(crearPreguntaStub(), null, Set.of(1));
    }

    @Test(expected = InvalidRespostaException.class)
    public void testConstructorPreguntaNull() throws Exception {
        // Comprova (preguntaAssociada == null) de RespostaInd
        new RespostaMultichoice(null, "usuari1", Set.of(1));
    }

//------------------------------------------------------------------------

    @Test(expected = InvalidRespostaException.class)
    public void testConstructorExcedeixLimit() throws Exception {
        // Cas erroni: selecciona més opcions que el límit
        Set<Integer> opcionsTriaes = Set.of(0, 1, 2, 3); // Tria 4, límit 3
        new RespostaMultichoice(crearPreguntaStub(), "u1", opcionsTriaes);
    }

    @Test(expected = InvalidRespostaException.class)
    public void testConstructorIndexInvalid() throws Exception {
        // Cas erroni: tria un índex que no existeix
        Set<Integer> opcionsTriaes = Set.of(1, 5); // Tria índex 5, max és 3
        new RespostaMultichoice(crearPreguntaStub(), "u1", opcionsTriaes);
    }

    @Test
    public void testCalcularDistanciaJaccard() throws Exception {
        PreguntaMultichoice pStub = crearPreguntaStub();
        RespostaMultichoice r1 = new RespostaMultichoice(pStub, "u1", Set.of(0, 1));
        RespostaMultichoice r2 = new RespostaMultichoice(pStub, "u2", Set.of(1, 2));
        
        // Unió = {0, 1, 2} (mida 3)
        // Intersecció = {1} (mida 1)
        // Similitud = 1 / 3
        // Distància = 1 - (1/3) = 0.666...
        assertEquals(1.0f - (1.0f / 3.0f), r1.calcularDistancia(r2), 0.001);
    }

    @Test
    public void testCalcularDistanciaIguals() throws Exception {
        PreguntaMultichoice pStub = crearPreguntaStub();
        RespostaMultichoice r1 = new RespostaMultichoice(pStub, "u1", Set.of(0, 1));
        RespostaMultichoice r2 = new RespostaMultichoice(pStub, "u2", Set.of(0, 1));
        // Cas límit: són iguals
        assertEquals(RespostaInd.MIN_DISTANCIA, r1.calcularDistancia(r2), 0.001);
    }

    @Test
    public void testCalcularDistanciaTotalmentDiferents() throws Exception {
        PreguntaMultichoice pStub = crearPreguntaStub();
        RespostaMultichoice r1 = new RespostaMultichoice(pStub, "u1", Set.of(0, 1));
        RespostaMultichoice r2 = new RespostaMultichoice(pStub, "u2", Set.of(2, 3));
        
        // Unió = 4, Intersecció = 0. Distància = 1.0
        assertEquals(RespostaInd.MAX_DISTANCIA, r1.calcularDistancia(r2), 0.001);
    }

    @Test
    public void testCalcularDistanciaAmbdosBuits() throws Exception {
        PreguntaMultichoice pStub = crearPreguntaStub();
        // Cas límit: ambdós usuaris no han triat cap opció
        RespostaMultichoice r1 = new RespostaMultichoice(pStub, "u1", new HashSet<>());
        RespostaMultichoice r2 = new RespostaMultichoice(pStub, "u2", new HashSet<>());
        
        // Unió = 0, Intersecció = 0. Són idèntics.
        assertEquals(RespostaInd.MIN_DISTANCIA, r1.calcularDistancia(r2), 0.001);
    }

    @Test
    public void testCalcularDistanciaAmbNul() throws Exception {
        PreguntaMultichoice pStub = crearPreguntaStub();
        RespostaMultichoice r1 = new RespostaMultichoice(pStub, "u1", Set.of(1));
        
        // Cas erroni: comparar amb null
        assertEquals(RespostaInd.MAX_DISTANCIA, r1.calcularDistancia(null), 0.001);
    }
    
    @Test
    public void testCalcularDistanciaTipusDiferent() throws Exception {
        PreguntaMultichoice pStub = crearPreguntaStub();
        RespostaMultichoice rMulti = new RespostaMultichoice(pStub, "u1", Set.of(1));
        RespostaNum rNum = new RespostaNum(new PreguntaLliure("stub",10,true), "u2", 123f);

        // Cas erroni: comparar RespostaMultichoice amb RespostaNum
        assertEquals(RespostaInd.MAX_DISTANCIA, rMulti.calcularDistancia(rNum), 0.001);
    }
    
    @Test
    public void testCloneDeepCopy() throws Exception {
        //  Prova de còpia profunda (es fa el clone del Set intern que al ser un objecte mutable
        //  podria ser modificat des del clon i afectar a l'original).

        PreguntaMultichoice pStub = crearPreguntaStub();
        Set<Integer> opcionsOriginals = new HashSet<>();
        opcionsOriginals.add(1);
        
        RespostaMultichoice original = new RespostaMultichoice(pStub, "u1", opcionsOriginals);
        RespostaMultichoice clon = (RespostaMultichoice) original.clone();
        
        // Comprova que són objectes diferents
        assertNotSame(original, clon);
        // Comprova que el Set NO és el mateix objecte
        assertNotSame(original.getValor(), clon.getValor());
        
        // Modifiquem el Set de la còpia
        clon.getValor().add(2);

        // Comprovem que el Set ORIGINAL no ha canviat
        assertEquals(1, original.getValor().size()); // L'original ha de tenir 1 element
        assertEquals(2, clon.getValor().size());     // El clon ha de tenir 2 elements
    }
}