/*
    +----------------------------------------------------------+
    |              driverTotesFuncionsEnquesta.java            |
    +----------------------------------------------------------+ 
    | Repositori:                                              |
    |   ·subgrup-prop32.3                                      |
    +----------------------------------------------------------+
    | Aquest mòdul ha sigut programat per:                     |
    |   ·Arnau Cullell Martínez                                |
    +----------------------------------------------------------+
    | *Versió 1.0: Driver complet per a totes les funcions de  |
    |              la classe Enquesta, incloent constructores, |
    |              modificadores i excepcions.                 |
    |                                                          |
    +----------------------------------------------------------+
  */

/** @class driverTotesFuncionsEnquesta
    @brief Driver que permet comprobar que totes les funcions d'Enquesta funcionen bé.
*/

package EXE.driversEnquesta;

import FONTS.*;
import java.util.*;

import org.junit.*;
import org.mockito.*;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.*;
import java.io.*;

public class driverTotesFuncionsEnquesta {
    @BeforeClass
    public static void beforeClass() {
        System.out.println("Testos de: driversTotesFuncionsEnquesta");
    }

    @Before
    public void initMocks() //iniciar el mockito
    {
        MockitoAnnotations.initMocks(this);
    }

    @Mock
    Usuari u;

    @Mock
    HashMap<String,Usuari> usuarios; // Utilitzem un sol HashMap mockejat

    //constructores

    @Test
    public void CrearEnquesta1() // constructora 1 d'enquesta: Enquesta(String titol, Usuari admin, Integer valorK)
    {
        Enquesta enquesta_prova = new Enquesta("EnquestaPROP", u, 2);
        
        assertNotNull("L'objecte Enquesta no s'hauria de crear nul.", enquesta_prova);
        assertEquals("El títol ha de ser 'EnquestaPROP'.", "EnquestaPROP", enquesta_prova.getTitolEnquesta());
        assertEquals("El nombre de preguntes ha de ser 0 inicialment.", (Integer)0, enquesta_prova.getNumPreguntes());
        assertEquals("El nombre de respostes ha de ser 0 inicialment.", (Integer)0, enquesta_prova.getNumRespostes());
    }

    @Test
    public void CrearEnquesta2() // constructora 2 (amb fitxer): Enquesta(String titol, String nomFitxer, HashMap<String, Usuari> usuarios, Scanner scMain)
    {
        
        String tempFileName = "temp_test_enquesta.csv"; // creem un fitxer temporal per al test
        String fileContent = 
            "2\n" + // valorK
            "AdminUser,pass\n" + // admin
            "Usuari,Pregunta Lliure NumericaN?,Pregunta Lliure TextT?,Pregunta Multichoice~Opcio1~Opcio2~!1!,Cluster\n" + // Capçalera de preguntes
            "Usuari1,10.5,text_resp,1\n" +
            "Usuari2,NULL,NULL,NULL";

        try {
            // Escrivim el contingut al fitxer temporal
            FileWriter writer = new FileWriter(tempFileName);
            writer.write(fileContent);
            writer.close();

            Scanner scM = new Scanner(new ByteArrayInputStream("n\n".getBytes())); //no volem importar respostes

            // Stubbing de Mocks
            when(usuarios.get(eq("AdminUser"))).thenReturn(u); // retornem usuari u
            when(u.getName()).thenReturn("AdminUser");
            doNothing().when(u).crearEnquesta(anyString(), any(Enquesta.class));

            Enquesta enquesta_prova = new Enquesta("EnquestaImportada", tempFileName, usuarios, scM);
            
            assertNotNull("L'objecte Enquesta no s'hauria de crear nul.", enquesta_prova);
            assertEquals("El títol ha de ser 'EnquestaImportada'.", "EnquestaImportada", enquesta_prova.getTitolEnquesta());
            assertEquals("S'han d'haver importat 3 preguntes.", (Integer)3, enquesta_prova.getNumPreguntes());
            
        } catch (ExcepcioObrirArxiu e) {
            fail("No s'esperava ExcepcioObrirArxiu per un fitxer creat.");
        } catch (IOException e) {
            fail("Error d'E/S durant la creació del fitxer de prova.");
        }
        finally {
            // Neteja: eliminem el fitxer temporal
            new File(tempFileName).delete();
        }
    }

    @Test(expected = ExcepcioObrirArxiu.class)
    public void CrearEnquesta2Excepcio() throws ExcepcioObrirArxiu // *** CANVI AQUÍ: Afegit throws ExcepcioObrirArxiu ***
    {
        Scanner scM = new Scanner(new ByteArrayInputStream("s\n".getBytes()));
        
        new Enquesta("EnquestaPROP", "FONTS/Enquestes/FitxerInexistent.csv", usuarios, scM);
    }

    // modificadores

    @Test
    public void registrarPregunta_Nova() {
        Enquesta enquesta = new Enquesta("TestRegPreg", u, 2);
        PreguntaLliure preg1 = mock(PreguntaLliure.class);
        when(preg1.getText()).thenReturn("Nova Pregunta Lliure");
        
        enquesta.registrarPregunta(preg1);
        
        assertEquals("S'ha d'haver incrementat el nombre de preguntes a 1.", (Integer)1, enquesta.getNumPreguntes());
        assertEquals("La pregunta ha d'estar a l'índex 1 de l'array.", preg1, enquesta.getPreguntes()[1]);
    }

    @Test
    public void registrarPregunta_Duplicada() {
        Enquesta enquesta = new Enquesta("TestRegPregDup", u, 2);
        PreguntaLliure preg1 = mock(PreguntaLliure.class);
        when(preg1.getText()).thenReturn("Pregunta Unica");
        enquesta.registrarPregunta(preg1);

        enquesta.registrarPregunta(preg1); // registem la mateixa pregunta una altra vegada
        
        assertEquals("El nombre de preguntes ha de continuar sent 1.", (Integer)1, enquesta.getNumPreguntes());
    }

    @Test
    public void eliminarPregunta_Existenta() {
        Enquesta enquesta = new Enquesta("TestDelPreg", u, 2);
        
        PreguntaLliure preg1 = mock(PreguntaLliure.class);
        when(preg1.getText()).thenReturn("Pregunta 1");
        enquesta.registrarPregunta(preg1);

        PreguntaLliure preg2 = mock(PreguntaLliure.class);
        when(preg2.getText()).thenReturn("Pregunta 2");
        enquesta.registrarPregunta(preg2);
        
        assertEquals("Inicialment hi ha 2 preguntes.", (Integer)2, enquesta.getNumPreguntes());
        
        enquesta.eliminarPregunta("Pregunta 1");
        
        assertEquals("Després d'eliminar-ne 1, hi ha d'haver 1 pregunta.", (Integer)1, enquesta.getNumPreguntes());
    
        assertEquals("La Pregunta 2 ha de ser ara a l'índex 1.", preg2, enquesta.getPreguntes()[1]);
    }

    @Test
    public void eliminarPregunta_Inexistent() {
        Enquesta enquesta = new Enquesta("TestDelInex", u, 2);
        PreguntaLliure preg1 = mock(PreguntaLliure.class);
        when(preg1.getText()).thenReturn("Pregunta Existent");
        enquesta.registrarPregunta(preg1);
        
        assertEquals("Inicialment hi ha 1 pregunta.", (Integer)1, enquesta.getNumPreguntes());
        
        enquesta.eliminarPregunta("Pregunta Inexistent"); // intentem eliminar una que no hi és
        
        assertEquals("El nombre de preguntes ha de continuar sent 1.", (Integer)1, enquesta.getNumPreguntes());
    }

    @Test
    public void registrarResposta_NouUsuari() {
        Enquesta enquesta = new Enquesta("TestRegResp", u, 2);
        PreguntaLliure preg1 = mock(PreguntaLliure.class);
        when(preg1.getText()).thenReturn("P1");
        enquesta.registrarPregunta(preg1);
        
        RespostaText resp = mock(RespostaText.class);
        when(resp.getIdUsuari()).thenReturn("UsuariNou");
        when(resp.getPreguntaAssociada()).thenReturn(preg1);
        when(resp.getRespostaText()).thenReturn("R1");
        
        enquesta.registrarResposta(resp);
        
        assertEquals("S'ha d'haver incrementat el nombre de respostes a 1 (nou usuari).", (Integer)1, enquesta.getNumRespostes());
        RespostaInd[][] respostes = enquesta.getRespostes();
        assertEquals("La resposta ha d'estar a la posició [0][0].", resp, respostes[0][0]);
    }

    @Test
    public void registrarResposta_UsuariExistent() {
        Enquesta enquesta = new Enquesta("TestRegRespExist", u, 2);
        
        PreguntaLliure preg1 = mock(PreguntaLliure.class);
        when(preg1.getText()).thenReturn("P1");
        enquesta.registrarPregunta(preg1);
        
        PreguntaLliure preg2 = mock(PreguntaLliure.class);
        when(preg2.getText()).thenReturn("P2");
        enquesta.registrarPregunta(preg2); // 2 preguntes
        
        //resposta a P1 per UsuariA
        RespostaText resp1 = mock(RespostaText.class);
        when(resp1.getIdUsuari()).thenReturn("UsuariA");
        when(resp1.getPreguntaAssociada()).thenReturn(preg1);
        when(resp1.getRespostaText()).thenReturn("R1");
        enquesta.registrarResposta(resp1);
        
        //resposta a P2 pel mateix UsuariA
        RespostaText resp2 = mock(RespostaText.class);
        when(resp2.getIdUsuari()).thenReturn("UsuariA");
        when(resp2.getPreguntaAssociada()).thenReturn(preg2);
        when(resp2.getRespostaText()).thenReturn("R2");
        enquesta.registrarResposta(resp2);
        
        assertEquals("El nombre de respostes (usuaris) ha de continuar sent 1.", (Integer)1, enquesta.getNumRespostes());
        RespostaInd[][] respostes = enquesta.getRespostes();
        assertEquals("La resposta a P1 ha d'estar a [0][0].", resp1, respostes[0][0]);
        assertEquals("La resposta a P2 ha d'estar a [0][1].", resp2, respostes[0][1]);
    }
    
    @Test
    public void generarCluster_SenseExcepcio() {
        // valor K=0 per evitar InvalidClusterException en el test de crida bàsica
        Enquesta enquesta = new Enquesta("TestCluster", u, 0); 
        
        try {
            enquesta.generarCluster();
            assertTrue(true); 
        }
        catch (Exception e) {
            fail("Es va llançar una excepció inesperada en generarCluster: " + e.getMessage());
        }
    }


    @Test
    public void exportarEnquesta_SenseRespostes() {
        String nomFitxer = "test_export_sense_respostes";
        Enquesta enquesta = new Enquesta("EnquestaExport", u, 2);
        PreguntaLliure preg1 = mock(PreguntaLliure.class);
        when(preg1.getText()).thenReturn("P1");
        when(preg1.esNumerica()).thenReturn(true);
        enquesta.registrarPregunta(preg1);
        
        Scanner scM = new Scanner(new ByteArrayInputStream("n\n".getBytes()));
        
        when(u.getName()).thenReturn("AdminTest"); 

        File exportedFile = new File("FONTS/CtrlPersistencia/Enquestes/" + nomFitxer + ".csv");
        if (exportedFile.exists()) exportedFile.delete(); 

        try {
            enquesta.exportarEnquesta(nomFitxer, scM);
            
            assertTrue("El fitxer d'exportació ha d'existir.", exportedFile.exists());

            Scanner fileScanner = new Scanner(exportedFile);
            assertEquals("La primera línia ha de ser el valor K.", "2", fileScanner.nextLine());
            assertEquals("La segona línia ha de ser l'usuari admin.", "AdminTest,null", fileScanner.nextLine()); 
            assertEquals("La tercera línia ha de ser la capçalera de preguntes.", "Usuaris,P1N?,Cluster", fileScanner.nextLine());
            assertFalse("No ha d'haver més línies (sense respostes).", fileScanner.hasNextLine());
            fileScanner.close();

        } catch (ExcepcioGenerarArxiu e) {
            fail("No s'esperava ExcepcioGenerarArxiu.");
        } catch (IOException e) {
            fail("Error d'E/S durant l'exportació o lectura del fitxer.");
        }
        finally {
            exportedFile.delete();
        }
    }
    
    @Test
    public void exportarEnquesta_AmbRespostes() {
        String nomFitxer = "test_export_amb_respostes";
        Enquesta enquesta = new Enquesta("EnquestaExportResp", u, 2);
        
        //pregunta Multichoice (ID 1)
        PreguntaMultichoice preg1 = mock(PreguntaMultichoice.class);
        when(preg1.getText()).thenReturn("P1MC");
        when(preg1.getLimitOpcions()).thenReturn(2);
        when(preg1.getOpcions()).thenReturn(Arrays.asList("A", "B"));
        enquesta.registrarPregunta(preg1);

        //pregunta Lliure Text (ID 2)
        PreguntaLliure preg2 = mock(PreguntaLliure.class);
        when(preg2.getText()).thenReturn("P2L");
        when(preg2.esNumerica()).thenReturn(false);
        enquesta.registrarPregunta(preg2);
        
        //resposta UsuariA
        Set<Integer> opcions_A = new HashSet<>(Arrays.asList(0, 1));
        RespostaMultichoice respA1 = mock(RespostaMultichoice.class);
        when(respA1.getIdUsuari()).thenReturn("UsuariA");
        when(respA1.getPreguntaAssociada()).thenReturn(preg1);
        when(respA1.getRespostaText()).thenReturn("0,1"); 
        when(respA1.getValor()).thenReturn(opcions_A); 
        enquesta.registrarResposta(respA1);
        
        RespostaText respA2 = mock(RespostaText.class);
        when(respA2.getIdUsuari()).thenReturn("UsuariA");
        when(respA2.getPreguntaAssociada()).thenReturn(preg2);
        when(respA2.getRespostaText()).thenReturn("Hola"); 
        enquesta.registrarResposta(respA2);

        //resposta UsuariB
        RespostaText respB2 = mock(RespostaText.class);
        when(respB2.getIdUsuari()).thenReturn("UsuariB");
        when(respB2.getPreguntaAssociada()).thenReturn(preg2);
        when(respB2.getRespostaText()).thenReturn("Adeu"); 
        enquesta.registrarResposta(respB2);
        
        Scanner scM = new Scanner(new ByteArrayInputStream("s\n".getBytes()));
        
        //stubbing per a l'exportació
        when(u.getName()).thenReturn("AdminTest"); 

        File exportedFile = new File("FONTS/CtrlPersistencia/Enquestes/" + nomFitxer + ".csv");
        if (exportedFile.exists()) exportedFile.delete(); 

        try {
            enquesta.exportarEnquesta(nomFitxer, scM);
            
            assertTrue("El fitxer d'exportació ha d'existir.", exportedFile.exists());

            Scanner fileScanner = new Scanner(exportedFile);
            fileScanner.nextLine(); // 2
            fileScanner.nextLine(); // AdminTest,null
            
            //capçalera de Preguntes
            String expected_preg_line = "Usuaris,P1MC~A~B~!2!,P2LT?,Cluster"; // P2LT de tipus Text (per defecte)
            assertEquals("La línia de preguntes ha de tenir el format correcte.", expected_preg_line, fileScanner.nextLine());
            
            //línies de Respostes
            fileScanner.nextLine();
            assertEquals("Línia 5: Respostes UsuariB (NULL per MC, Adeu per LT).", "UsuariB,NULL,Adeu,null", fileScanner.nextLine());
            assertFalse("No ha d'haver més línies.", fileScanner.hasNextLine());
            fileScanner.close();

        } catch (ExcepcioGenerarArxiu e) {
            fail("No s'esperava ExcepcioGenerarArxiu.");
        } catch (IOException e) {
            fail("Error d'E/S durant l'exportació o lectura del fitxer.");
        }
        finally {
            exportedFile.delete();
        }
    }


    //escriure
    
    @Test
    public void veureRespostes_Buit() {
        Enquesta enquesta = new Enquesta("TestVeureRespBuit", u, 2);
        
        //redirigim la sortida estàndard per a la verificació
        PrintStream originalOut = System.out;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        System.setOut(new PrintStream(bos));

        enquesta.veureRespostes();

        System.setOut(originalOut); //restaurar la sortida
        String output = bos.toString();
        assertTrue("La sortida ha de contenir el títol.", output.contains("TestVeureRespBuit"));
        assertTrue("La sortida ha de contenir la capçalera 'Usuari'.", output.contains("Usuari"));
        assertFalse("No ha de mostrar respostes d'usuaris (segIdFila=1).", output.contains("NULL")); 
    }

    @AfterClass
    public static void afterClass() {
        System.out.println();
        System.out.println("Acaba testos de: driversTotesFuncionsEnquesta");
    }
}