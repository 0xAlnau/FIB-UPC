
/*
   +----------------------------------------------------------+
   |                      CtrlPresentacion                    |
   +----------------------------------------------------------+
   | Repositori:                                              |
   |   ·subgrup-prop32.3                                      |
   +----------------------------------------------------------+
   | Aquest mòdul ha sigut programat per:                     |
   |   ·Gabriel Alegre Conchello                              |
   | Cooperador:                                              |
   |   ·Arnau Cullell Martínez                                |
   +----------------------------------------------------------+
   | Versió 1.0 : S'encarrega de la comunicació amb l'usuari  |
   |              de la app i la lógica per decidir que cal   |
   |              fer.                                        |
   |                                                          |
   +----------------------------------------------------------+
 */

/** @file CtrlPresentacion.java
 @brief Codi de la classe CtrlPresentacion.
 */

/** @class CtrlPresentacion
 @brief Controlador encarregat de gestionar tota la interacció amb l'usuari
 des de la capa de presentació. Coordina l'entrada i sortida per terminal i
 delega totes les operacions de lògica al controlador de domini.

 <b>-Constructora:</b> Inicialitza el controlador de presentació i crea una
 instància de CtrlDominio per gestionar totes les operacions internes.

 <b>-Flux principal:</b> Mitjançant iniciarApp(), presenta el menú principal,
 permet registrar usuaris, iniciar sessió i accedir a funcionalitats internes.

 <b>-Operacions d’usuari:</b> Registre, accés i validació d’identitat. Un cop
 autenticat, ofereix un menú d’accions disponibles sobre enquestes.

 <b>-Gestió d’enquestes:</b> Permet crear enquestes, importar-les, afegir-hi
 preguntes, contestar-les, veure'n els resultats, eliminar preguntes i
 exportar-les. Totes les operacions són derivades al controlador de domini.

 <b>-Interacció per terminal:</b> Gestiona la lectura d’entrades amb Scanner i
 la visualització de missatges, així com el control d’errors bàsics.
 */

package FONTS;

import java.util.*;

public class CtrlPresentacion {

    /** @brief Atribut que serveix per iniciar CtrlDominio.*/
    private CtrlDominio CD;

    /** @brief Atribut que serveix per imprimir per pantalla.*/
    private final Scanner sc = new Scanner(System.in);

    /** @brief Crea el controlador i inicialitza el CtrlDominio i el lector d’entrada.*/
    public CtrlPresentacion() {
        CD = new CtrlDominio();
        CD.setSc(sc);
    }

    public CtrlDominio getCD() {
        return CD;
    }

    /** @brief Mostra el menú inicial (registrar-se, accedir, sortir) i
     * gestiona l'entrada de l’usuari.*/
    public void iniciarApp() {
        String op = "-1";
        sc.useLocale(Locale.US); //pels floats, per poder usar el . i fer 3.14

        //importa informació d'altres execucions
        try {
            CD.importaUsuaris();
        }
        catch (ExcepcioObrirArxiu e) {
            System.err.println(e.getMessage());
        }
        
        try { 
            CD.importaEnquestes();
        }
        catch (ExcepcioObrirArxiu e) {
            System.err.println(e.getMessage());
        }

        while (!op.equals("0")) {
            System.out.println("\n--- MENÚ PRINCIPAL ---");
            System.out.println("Vols sortir, registrar-te o accedir?");
            System.out.println("0 - Sortir");
            System.out.println("1 - Registrar-te");
            System.out.println("2 - Accedir");
            op = sc.nextLine();
            while (!op.equals("0") && !op.equals("1")  && !op.equals("2")) {
                System.err.println("Entrada incorrecta. Escull una de les opcions.");
                op = sc.nextLine();
            }
            if (op.equals("1")) registrarse();
            else if (op.equals("2")) acceder();
            else if (op.equals("0")) sortir();

        }

    }

    /** @brief Demana nom i contrasenya, comprova que el nom no existeixi i crea un usuari nou.*/
    public void registrarse() {
        String name, password;
        System.out.print("Escriu el nom de l'usuari: ");
        name = sc.nextLine();
        if (name.equals("")) {
            System.err.println("El nombre debe contener almenos un caracter");
        } else if (CD.nombreEnUso(name)) {
            System.err.println("Ja existeix un usuari amb aquest nom.");
            //vuelve a registrarse o acceder
        } else {
            System.out.print("Escriu el password de l'usuari:");
            password = sc.nextLine();
            if (password.equals("")) {
                System.err.println("El password debe contener almenos un caracter");
            } else {
                CD.crearUsuari(name, password);
                acceso(name);
            }
        }

    }

    /** @brief Demana nom i contrasenya i valida l’accés d’un usuari existent.*/
    public void acceder() {
        System.out.println("Escribe el nombre del usuario:");
        String name = sc.nextLine();
        if (!CD.nombreEnUso(name)) {
            System.err.println("No existe ningún usuario con ese nombre");
        } else {
            System.out.println("Escribe el password del usuario: ");
            String password = sc.nextLine();
            if (!CD.comprovarPassword(name, password)) {
                System.err.println("el password es incorrecto");
            } else acceso(name);
        }

    }

    /** @brief Tanca l'aplicació i guarda tota la informació de l'execució fins ara.*/
    private void sortir() {
        try {
            CD.exportarUsuaris();
        }
        catch (ExcepcioGenerarArxiu e) {
            System.err.println(e.getMessage());
        }

        //controla excepcions dintre seu
        CD.exportarEnquestes();
    
        return;
    }

    /** @brief Mostra el menú principal després d’iniciar sessió i redirigeix a
     * les funcions d’enquestes.*/
    private void acceso(String name) {
        String op = "-1";
        while (!op.equals("0")) {
            System.out.println("Escull que vols fer:");
            System.out.println("0 - Sortir");
            System.out.println("1 - Crear nova enquesta");
            System.out.println("2 - Contestar a una enquesta");
            System.out.println("3 - Veure resultats d'una enquesta");
            System.out.println("4 - Eliminar pregunta d'una enquesta");
            System.out.println("5 - Exportar enquesta");
            System.out.println("6 - Afegir pregunta a una enquesta");
            System.out.println("7 - Eliminar enquesta");
            op = sc.nextLine();
            if (op.equals("1")) crearEnquesta(name);
            else if (op.equals("2")) contestar(name);
            else if (op.equals("3")) veureResultats(name);
            else if (op.equals("4")) eliminarPreguntes();
            else if (op.equals("5")) exportarEnquesta();
            else if (op.equals("6")) afegirPregunta();
            else if (op.equals("7")) eliminarEnquesta(name);
            else {
                if (!op.equals("0"))
                    System.err.println("Entrada incorrecta. Escull una de les opcions.");
            }
        }
    }

    /** @brief Permet crear una enquesta nova: important-la o afegint preguntes manualment.*/
    public void crearEnquesta(String name) {
        System.out.println("Nom de l'enquesta a crear: ");
        String titol = sc.nextLine();

        CD.crearEnquestaBuida(titol, name);
        System.err.println("Posa 'ext' quan no vulguis posar més preguntes.");
        System.out.println("Pregunta lliure (ll) o multichoice (mc)? ");
        String resp = sc.nextLine();
        while (!resp.contentEquals("ext")) {
            if (resp.equalsIgnoreCase("ll")) {
                System.out.print("Enunciat: ");
                resp = sc.nextLine();
                System.out.print("Numèrica? s/n ");
                String numerica = sc.nextLine();
                Boolean bNumerica = false;
                if (numerica.contentEquals("s")) bNumerica = true;
                if (!numerica.contentEquals("s") && !numerica.contentEquals("n")) {
                    System.err.println("·Error: no has escollit una opció vàlida entre 's' o 'n'.");
                }
                else {
                    try {
                        CD.crearPreguntaLliure(titol, resp, 20, bNumerica);
                    }
                    catch (InvalidPreguntaException e) {
                        System.err.println(e.getMessage());                                
                    }
                }
            }
            else if (resp.equalsIgnoreCase("mc")) {
                System.out.print("Enunciat: ");
                resp = sc.nextLine();

                System.out.print("Quantes respostes possibles: ");
                int n_opcions = sc.nextInt();
                sc.nextLine(); //consumeix el salt de linia!
                List<String> opcions = new ArrayList<>();
                for (int i = 0; i < n_opcions; ++i) {
                    System.out.print("·Opció " + (i) + ": ");
                    String opcio_x = sc.nextLine();
                    opcions.add(opcio_x);
                }
                System.out.print("Quantes pot marcar com a màxim un usuari: ");
                int max_opcions = sc.nextInt();
                sc.nextLine();
                CD.crearPreguntaMultichoice(titol, resp, opcions, max_opcions);

            }
            else {
                System.err.println("Error: Escriu una de les opcions o \"ext\" per sortir.");
            }
            System.out.println("Pregunta lliure (ll) o multichoice (mc)? ");
            resp = sc.nextLine();
        }
    } 

    /** @brief Mostra enquestes disponibles i permet contestar-ne una.*/
    public void contestar(String name) {
        System.out.println("Aquestes son les enquestes disponibles:");
        CD.listarEnquestes();
        System.out.print("Títol de l'enquesta a contestar: ");
        String titol = sc.nextLine();
        if (CD.existeEnquesta(titol)) CD.contestarEnquesta(titol, name);
        else System.err.println("Error: no existeix l'enquesta!");
    }

    /** @brief Mostra una llista d'enquestes i permet veure'n els resultats.*/
    public void veureResultats(String name) {
        System.out.println("Aquestes son les teves enquestes:");
        CD.listarEnquestesUsuari(name);
        System.out.print("Nom de l'enquesta a veure: ");
        String titol = sc.nextLine();
        if (CD.existeEnquestaUsuari(name, titol)) CD.veureResultatsEnquesta(titol);
        else System.err.println("Error: no ets admin de l'enquesta!");
    }

    /** @brief Permet eliminar una pregunta concreta d’una enquesta.*/
    public void eliminarPreguntes() {
        String enq, preg;
        System.out.print("Nom de l'enquesta a eliminar una pregunta: ");
        enq = sc.nextLine();
        System.out.print("Nom de la pregunta a eliminar: ");
        preg = sc.nextLine();
        if (CD.existeEnquesta(enq)) CD.eliminarPreguntes(enq, preg);
        else System.err.println("Error: no existeix l'enquesta!");
    }

    /** @brief Exporta una enquesta a un fitxer amb el nom indicat.*/
    public void exportarEnquesta() {
        String titol, nouNomFitxer;
        System.out.print("Nom de l'enquesta a exportar: ");
        titol = sc.nextLine();
        System.out.print("Nom del nou fitxer enquesta: ");
        nouNomFitxer = sc.nextLine();
        if (CD.existeEnquesta(titol)) CD.exportarEnquesta(titol, nouNomFitxer, sc);
        else System.err.println("Error: no existeix l'enquesta!");
    }

    /** @brief Afegeix una pregunta nova (lliure o multiresposta) a una enquesta existent.*/
    public void afegirPregunta() {
        System.out.print("Nom de l'enquesta a afegir una pregunta: ");
        String titol = sc.nextLine();
        System.out.print("Pregunta lliure (ll) o multichoice (mc)? ");
        String resp = sc.nextLine();
        if (resp.equalsIgnoreCase("ll")) {
            System.out.print("Enunciat: ");
            resp = sc.nextLine();
            System.out.print("Numèrica? s/n ");
            String numerica = sc.nextLine();
            Boolean bNumerica = false;
            if (numerica.contentEquals("s")) bNumerica = true;
                if (!numerica.contentEquals("s") && !numerica.contentEquals("n")) {
                    System.err.println("·Error: no has escollit una opció vàlida entre 's' o 'n'.");
                }
                else {
                    try {
                       CD.crearPreguntaLliure(titol, resp, 20, bNumerica);
                    }
                    catch (InvalidPreguntaException e) {
                        System.err.println(e.getMessage());                                
                    }
                }
        }
        else if (resp.equalsIgnoreCase("mc")) {
            System.out.print("Enunciat: ");
            resp = sc.nextLine();

            System.out.print("Quantes respostes possibles: ");
            int n_opcions = sc.nextInt();
            sc.nextLine(); //consumeix el salt de linia!
            List<String> opcions = new ArrayList<>();
            for (int i = 0; i < n_opcions; ++i) {
                System.out.print("·Opció " + (i) + ": ");
                String opcio_x = sc.nextLine();
                opcions.add(opcio_x);
            }
            System.out.print("Quantes pot marcar com a màxim un usuari: ");
            int max_opcions = sc.nextInt();
            sc.nextLine();
            CD.crearPreguntaMultichoice(titol, resp, opcions, max_opcions);

        }
        else {
            System.err.println("Error: Escriu una de les opcions.");
        }
    }

    /** @brief Eliminar una enquesta amb el nom indicat.*/
    public void eliminarEnquesta(String name) {
        CD.listarEnquestesUsuari(name);
        System.out.print("Selecciona l'enquesta a eliminar: ");
        String titol = sc.nextLine();
        CD.eliminarEnquesta(name, titol);
    }

}
