/*    +----------------------------------------------------------+
      |                   TipusPregunta.java                     |
      +----------------------------------------------------------+
      | Repositori:                                              |
      |   ·subgrup-prop32.3                                      |
      +----------------------------------------------------------+
      | Aquest mòdul ha sigut programat per:                     |
      |   ·santi lluzar                                          |
      +----------------------------------------------------------+
      | Versió 1.0 : package FONTS;                              |
      +----------------------------------------------------------+
*/

/** @file TipusPregunta.java
    @brief Codi de l'enum TipusPregunta.
*/

/** @class TipusPregunta
    @brief Enumeració que representa els dos tipus de Pregunta
    segons el diagrama de classes.
*/

package FONTS;


public enum TipusPregunta {
    /** @brief Pregunta de tipus opció múltiple.*/
    MULTICHOICE,
    /** @brief Pregunta de tipus resposta lliure (text o numèrica).*/
    LLIURE
}