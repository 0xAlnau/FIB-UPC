/*    +----------------------------------------------------------+
      |                      Pregunta.java                       |
      +----------------------------------------------------------+
      | Repositori:                                              |
      |   ·subgrup-prop32.3                                      |
      +----------------------------------------------------------+
      | Aquest mòdul ha sigut programat per:                     |
      |   ·Santiago Lluzar                                       |
      +----------------------------------------------------------+
      | Versió 1.0 : package FONTS;                              |
      +----------------------------------------------------------+
*/

/** @file Pregunta.java
    @brief Codi de la classe abstracta Pregunta.
*/

/** @class Pregunta
    @brief Classe abstracta que representa una pregunta genèrica.
    Correspon a la classe 'Pregunta' del diagrama UML.
*/
package FONTS;

public abstract class Pregunta {

    /** @brief El text de la pregunta.*/
    protected String text;

    /** @brief El tipus de pregunta.*/
    protected TipusPregunta tipus;

    /** @brief Constructor per a una Pregunta.
     * @param text El text de la pregunta.
     * @param tipus El tipus de pregunta.
     * @throws InvalidPreguntaException Si el text és nul o buit.
     */
    public Pregunta(String text, TipusPregunta tipus) throws InvalidPreguntaException {
        if (text == null || text.trim().isEmpty()) {
            throw new InvalidPreguntaException("El text de la pregunta no pot ser nul o buit.");
        }
        this.text = text;
        this.tipus = tipus;
    }
    /** @brief Obté el text de la pregunta.
     * @return El text (enunciat) de la pregunta.
     */
    public String getText() {
        return text;
    }

    /** @brief Obté el tipus de la pregunta.
     * @return El valor de l'enum TipusPregunta.
     */
    public TipusPregunta getTipus() {
        return tipus;
    }
}