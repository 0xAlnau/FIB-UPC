 /*
    +----------------------------------------------------------+
    |                Cluster.java                              |
    +----------------------------------------------------------+
    | Repositori:                                              |
    |   ·subgrup-prop32.3                                      |
    +----------------------------------------------------------+
    | Aquest mòdul ha sigut programat per:                     |
    |   · Angel Dominguez Buira                                |
    +----------------------------------------------------------+
  */

package FONTS;

import java.util.ArrayList;

/**
 * @file Cluster.java
 * @brief Implementació d'una classe que gestiona la configuració i execució
 *        d'un procés de clustering sobre una enquesta.
 */

/**
 * @class Cluster
 * @brief Classe encarregada de preparar i executar l'anàlisi de clustering
 *        d'una enquesta mitjançant l'algoritme k-means.
 *
 * @details Aquesta classe és un embolcall senzill que:
 *          - Emmagatzema una instància d'Enquesta.
 *          - Permet definir el nombre de clusters (k).
 *          - Executa l'anàlisi de clustering generant un objecte AnalisiCluster.
 */
public class Cluster {

    /** @brief Enquesta sobre la qual es realitzarà el clustering. */
    private  Enquesta e;

    /** @brief Nombre de grups (clusters) que es volen generar. */
    private int k;

    /** @brief Nombre mínim de respostes necessàries per fer clustering */
    private static final int MIN_RESPOSTES = 2;

    /** 
     * @brief Llista booleana que indica quines respostes contenen algun valor nul.
     * 
     * @details Cada posició representa una resposta concreta de l’enquesta.
     *          Si nullList[i] és true, significa que la resposta i conté 
     *          algun valor nul i queda descartada del càlcul de centroides.
     */
    private Boolean[] nullList;

     /**
     * @brief Constructor amb paràmetre explícit del nombre de clusters.
     *
     * @param enquesta Enquesta que es vol analitzar.
     * @param r Nombre de clusters (k) que es volen generar.
     * @throws InvalidClusterException Si l'enquesta és nul·la o el nombre de clusters és invàlid.
     */
    public Cluster(Enquesta enquesta, int r) throws InvalidClusterException {
        try {
            // Validar que l'enquesta no sigui nul·la
            if (enquesta == null) {
                throw new InvalidClusterException("L'enquesta no pot ser nul·la.");
            }

            // Validar el nombre de clusters
            if (r < MIN_RESPOSTES) {
                throw new InvalidClusterException("El nombre de clusters (k) ha de ser positiu i major o igual que " + MIN_RESPOSTES + ". Valor rebut: " + r);
            }

            this.calcNul(enquesta);
            this.e = enquesta;
            this.k = r;
        } catch (InvalidClusterException e) {
            throw e;
        } catch (Exception e) {
            throw new InvalidClusterException("Error inesperat en el càlcul de distància: " + e.getMessage(), e);
        }
    }

    /**
     * @brief Constructor per defecte, amb k = 3.
     *
     * @param enquesta Enquesta que es vol analitzar.
     * @throws InvalidClusterException Si l'enquesta és nul·la o no compleix els requisits mínims.
     */
    public Cluster(Enquesta enquesta) throws InvalidClusterException {
        this(enquesta, 3);
    }

    
    /**
     * @brief Calcula quines respostes de l'enquesta contenen algun camp nul
     *        i verifica que hi hagi com a mínim tantes respostes vàlides com k.
     *
     * @param enquesta Enquesta de la qual es comprovaran les respostes.
     *
     * @throws InvalidClusterException Si el nombre de respostes vàlides és
     *         menor que k.
     *
     * @details Aquest mètode crea la llista nullList, marcant amb true aquelles
     *          respostes que tenen algun valor nul i que, per tant, no seran
     *          considerades vàlides pel clustering. També comprova que k no superi
     *          el nombre real de respostes vàlides.
     */
    public void calcNul(Enquesta enquesta) throws InvalidClusterException {
        // Validar que k no sigui més gran que el nombre de respostes
        Integer numRespostesValides = enquesta.getNumRespostes();
        nullList = new Boolean[enquesta.getNumRespostes()];
        RespostaInd[][] resp = enquesta.getRespostes();

        for (int i = 0; i < enquesta.getNumRespostes(); i++) {
            nullList[i] = false;
            for (int j = 0; j < enquesta.getNumPreguntes() && !nullList[i]; j++) {
                if (resp[i][j] == null) {
                    nullList[i] = true;
                    numRespostesValides -= 1;
                }
            }
        }
        if (k > numRespostesValides) {
            throw new InvalidClusterException(
                "El nombre de clusters (k=" + k + ") no pot ser més gran que el nombre de respostes vàlides(" +
                numRespostesValides  + ")."
            );
        }
    }

    /**
     * @brief Executa l'anàlisi de clustering sobre l'enquesta.
     *
     * @details Obté totes les respostes de l'enquesta i crea un objecte
     *          AnalisiCluster que aplicarà l'algoritme k-means amb el
     *          nombre de clusters especificat (k).
     *
     * @return Un objecte AnalisiCluster que conté tota la informació sobre
     *         els centroides, assignacions i resultats del clustering.
     * @throws InvalidClusterException Si hi ha errors durant l'anàlisi.
     */
    public AnalisiCluster analitzaCluster() throws InvalidClusterException {
        try {
            this.calcNul(e);
            RespostaInd[][] resp = e.getRespostes();
            AnalisiCluster analisi = new AnalisiCluster(resp, k, nullList, e.getNumRespostes(), e.getNumPreguntes());
            return analisi;
        } catch (InvalidClusterException e) {
            // Re-llançar l'excepció de clustering
            throw e;
        } catch (Exception e) {
            // Capturar qualsevol altra excepció inesperada
            throw new InvalidClusterException(
                "Error inesperat durant l'anàlisi de clustering: " + e.getMessage(),
                e
            );
        }
    }
}
