/*    +----------------------------------------------------------+
      |                     RespostaInd.java                     |
      +----------------------------------------------------------+
      | Repositori:                                              |
      |   ·subgrup-prop32.3                                      |
      +----------------------------------------------------------+
      | Aquest mòdul ha sigut programat per:                     |
      |   ·Santiago lluzar                                       |
      +----------------------------------------------------------+
      | Versió 1.0 : package FONTS;                              |
      +----------------------------------------------------------+
*/

/** @file RespostaMultichoice.java
    @brief Codi de la classe RespostaMultichoice.
*/

package FONTS;
import java.util.Set;
import java.util.HashSet;

/** @class RespostaMultichoice
    @brief Representa una resposta a una pregunta d'opció múltiple.
*/
public class RespostaMultichoice extends RespostaInd {

    /** @brief Conjunt d'índexs de les opcions seleccionades.*/
    private Set<Integer> opcionsTriaes;

    /** @brief Constructora.
     * @param preguntaAssociada La PreguntaMultichoice associada.
     * @param idUsuari L'usuari que respon.
     * @param opcionsTriaes Un Set amb els índexs de les opcions.
     * @throws InvalidRespostaException Si els paràmetres base són invàlids (a la superclasse), si la pregunta no és Multichoice o si les opcions són invàlides.
     */
    public RespostaMultichoice(PreguntaMultichoice preguntaAssociada, String idUsuari, Set<Integer> opcionsTriaes) throws InvalidRespostaException {
        super(preguntaAssociada, idUsuari, (opcionsTriaes != null) ? opcionsTriaes.toString() : null);
        
        // Comprova que la pregunta associada sigui realment Multichoice
        if (!(preguntaAssociada instanceof PreguntaMultichoice)) {
             throw new InvalidRespostaException("Tipus de resposta multichoice no és compatible amb el tipus de pregunta.");
        }
        
        if (opcionsTriaes == null) {
            throw new InvalidRespostaException("El set d'opcions triades no pot ser nul.");
        }
        
        // No es cumpleix la limitació de nombre d'opcions triades
        PreguntaMultichoice pm = (PreguntaMultichoice) preguntaAssociada;
        if (opcionsTriaes.size() > pm.getLimitOpcions()) {
            throw new InvalidRespostaException("S'han seleccionat més opcions (" + opcionsTriaes.size() + ") que el límit permès (" + pm.getLimitOpcions() + ").");
        }
        
        // Comprova que els índexs estiguin dins de rang
        int numOpcions = pm.getOpcions().size();
        for (Integer index : opcionsTriaes) {
            if (index < 0 || index >= numOpcions) {
                throw new InvalidRespostaException("L'índex d'opció " + index + " està fora de rang (0-" + (numOpcions - 1) + ").");
            }
        }
        
        this.opcionsTriaes = opcionsTriaes;
    }

    /** @brief Obté el conjunt d'índexs seleccionats.
     * @return Un Set<Integer> amb els índexs.
     */
    @Override
    public Set<Integer> getValor() {
        return opcionsTriaes;
    }
    
    /**
     * @brief Calcula la distància de Jaccard.
     * @param set1 Conjunt d'opcions de la resposta 1.
     * @param set2 Conjunt d'opcions de la resposta 2.
     * @return Un float entre 0.0 (idèntics) i 1.0 (totalment diferents).
     */
    private float jaccardDistance(Set<Integer> set1, Set<Integer> set2) {
        Set<Integer> unio = new HashSet<>(set1);
        unio.addAll(set2);

        Set<Integer> interseccio = new HashSet<>(set1); 
        interseccio.retainAll(set2);

        if (unio.isEmpty()) {
            return MIN_DISTANCIA; // Dos conjunts buits són idèntics
        }

        // Similitud = Intersecció / Unió
        float similitud = (float) interseccio.size() / (float) unio.size();
        
        // Distància = 1 - Similitud
        return MAX_DISTANCIA - similitud;
    }
    
    /** @brief Calcula la distància d'aquesta resposta a una altra.
     *
     * @param altra La segona resposta.
     * @return La distància de Jaccard normalitzada [0,1].
     */
    @Override
    public float calcularDistancia(RespostaInd altra) {
        // Cas 1: Nuls
        if (altra == null) {
            return MAX_DISTANCIA;
        }

        // Cas 2: Tipus diferents
        if (!(altra instanceof RespostaMultichoice)) {
            return MAX_DISTANCIA;
        }

        // Cas 3: Mateix tipus (Multichoice)
        RespostaMultichoice altraMulti = (RespostaMultichoice) altra;
            
        // Dist = 1 - Jaccard
        return jaccardDistance(this.opcionsTriaes, altraMulti.getValor());
    }

    /** @brief Crea i retorna una còpia d'aquesta resposta multichoice.
     * @return Una nova instància de RespostaMultichoice.
     */
    @Override
    public RespostaInd clone() {
        // Cal fer una còpia independent del Set d'opcions
        Set<Integer> opcionsCopiades = new HashSet<>(this.opcionsTriaes);
        
        // El constructor ja va validar que és PreguntaMultichoice, el cast és segur.
        PreguntaMultichoice preg = (PreguntaMultichoice) this.preguntaAssociada;

        try {
            return new RespostaMultichoice(preg, this.idUsuari, opcionsCopiades);
        } catch (InvalidRespostaException e) {
            // En teoria no passa mai perquè l'objecte original ja era vàlid.
            throw new InternalError(e);
        }
    }
}