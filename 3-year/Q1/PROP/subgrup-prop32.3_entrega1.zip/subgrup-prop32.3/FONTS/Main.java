/*
   +----------------------------------------------------------+
   |                      Main.javs                           |
   +----------------------------------------------------------+
   | Repositori:                                              |
   |   ·subgrup-prop32.3                                      |
   +----------------------------------------------------------+
   | Aquest mòdul ha sigut programat per:                     |
   |   ·Gabriel Alegre Conchello                              |
   +----------------------------------------------------------+
   | Versió 1.0 : El main del programa                        |
   |                                                          |
   +----------------------------------------------------------+
*/


 /** @file main.java
     @brief Codi de la classe main, la que controla la resta.
*/

/** @mainpage
    El programa principal, encarregat d'executar totes les instruccions bàsiques,
    està ubicat en el mòdul de main.java.

    A partir de l'enunciat donat, són necessaris més mòduls per a solucionar tot
    el problema de la millor forma possible, aquests mòduls són:

    ·Cluster

    ·AnalisiCluster

    ·Enquesta

    ·Pregunta

    ·PreguntaLliure

    ·PreguntaMultichoice

    ·RespostaInd

    ·RespostaNum

    ·RespostaText

    ·Usuari
*/
package FONTS;

 public class Main {


     public static void main (String[] args) {

         CtrlPresentacion CP = new CtrlPresentacion();

         CP.iniciarApp();
     }

 }
