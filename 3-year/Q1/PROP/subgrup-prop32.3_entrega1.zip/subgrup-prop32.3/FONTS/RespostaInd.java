/*    +----------------------------------------------------------+
      |                     RespostaInd.java                     |
      +----------------------------------------------------------+
      | Repositori:                                              |
      |   ·subgrup-prop32.3                                      |
      +----------------------------------------------------------+
      | Aquest mòdul ha sigut programat per:                     |
      |   ·Santiago lluzar                                       |
      +----------------------------------------------------------+
      | Versió 1.0 : package FONTS;                              |
      +----------------------------------------------------------+
*/

/** @file RespostaInd.java
    @brief Codi de la classe abstracta RespostaInd.
*/

/** @class RespostaInd
    @brief Classe abstracta que representa una resposta individual a una pregunta.
    Correspon a la classe 'RespostaInd' del diagrama UML.
*/

package FONTS;

public abstract class RespostaInd {

    /** @brief Valor per a distància màxima (quan les
     * respostes no són comparables o una és nul·la).
     */
    public static final float DISTANCIA_INFINITA = Float.POSITIVE_INFINITY;
    
    // Aquestes constants s'usen per Levenshtein i Jaccard
    /** @brief Valor per a distància màxima (interval [0,1]).*/
    public static final float MAX_DISTANCIA = 1.0f;
    /** @brief Valor per a distància mínima (interval [0,1]).*/
    public static final float MIN_DISTANCIA = 0.0f;


    /** @brief El text de la resposta
     */
    protected String respostaText;

    /** @brief L'identificador de l'usuari que ha donat la resposta.
     * Correspon a 'string: idUsuari' del diagrama.
     */
    protected String idUsuari;

    /** @brief La pregunta a la qual aquesta resposta està associada.
     */
    protected Pregunta preguntaAssociada;

    /** @brief Constructor base per a una resposta.
     * @param preguntaAssociada La pregunta que s'està responent.
     * @param idUsuari L'usuari que respon.
     * @param respostaText El text de la resposta.
     * @throws InvalidRespostaException Si la pregunta o l'usuari són nuls/buits.
     */
    public RespostaInd(Pregunta preguntaAssociada, String idUsuari, String respostaText) throws InvalidRespostaException {
        if (preguntaAssociada == null) {
            throw new InvalidRespostaException("La pregunta associada no pot ser nul·la.");
        }
        if (idUsuari == null || idUsuari.trim().isEmpty()) {
            throw new InvalidRespostaException("L'ID d'usuari no pot ser nul o buit.");
        }
        this.preguntaAssociada = preguntaAssociada;
        this.idUsuari = idUsuari;
        this.respostaText = respostaText;
    }
    
    /** @brief Consultora de la pregunta associada.
     * @return L'objecte Pregunta.
     */
    public Pregunta getPreguntaAssociada() {
        return preguntaAssociada;
    }

    /** @brief Consultora de l'ID d'usuari.
     * @return El nom de l'usuari que va respondre.
     */
    public String getIdUsuari() {
        return idUsuari;
    }

    /** @brief Consultora del text de la resposta.
     * @return La resposta en format String.
     */
    public String getRespostaText() {
        return respostaText;
    }

    /** @brief Mètode abstracte per obtenir el valor específic de la resposta
     * (un Float per a Num, un String per a Text, un Set per a Multichoice).
     * @return El valor de la resposta en format Object.
     */
    public abstract Object getValor();
    
    /** @brief Calcula la distància d'aquesta resposta a una altra.
     *
     * @param altra La segona resposta.
     * @return Un float representant la distància.
     */
    public abstract float calcularDistancia(RespostaInd altra);

    /** @brief Crea i retorna una còpia d'aquesta resposta.
     * @return Una nova instància de RespostaInd amb els mateixos valors.
     */
    public abstract RespostaInd clone();
}