 /*
    +----------------------------------------------------------+
    |                      Enquesta.java                       |
    +----------------------------------------------------------+ 
    | Repositori:                                              |
    |   ·subgrup-prop32.3                                      |
    +----------------------------------------------------------+
    | Aquest mòdul ha sigut programat per:                     |
    |   ·Arnau Cullell Martínez                                |
    +----------------------------------------------------------+
    | *Versió 0.5: Començant a implementar funcionalitats      |
    |              bàsiques.                                   |
    | *Versió 1.0: Ja es pot importar, exportar, eliminar,     |
    |              afegir i veure correctament els enquestes   |
    | *Versió 1.5: Pot importar i exportar preguntes de forma  |
    |              correcta, exporta i importa els fitxers de  |
    |              prova.                                      |
    | *Versió 2.0: Ara pot guardar sempre l'execució actual    |
    |            per tal de poder-la seguir en un altre moment,|
    |            a més a més per cada cluster també indica el  |
    |            seu coeficient de Silhouette.                 |                    
    |                                                          |
    +----------------------------------------------------------+
  */

 /** @file Enquesta.java
     @brief Codi de la classe Enquesta.
*/

/** @class Enquesta
    @brief Representa una enquesta amb les seves característiques i
    les seves operacions pròpies, que són:

    <b>-Constructores:</b> té 2 constructores. La primera es la de per defecte, on rep un títol
     i el nom de l'administrador que crea l'Enquesta. La segona permet crear l'Enquesta també amb
     un títol i el nom de l'administrador, però, també permet importar una altra enquesta d'un fitxer
     .csv i agafar les seves preguntes, amb el seu tipus i les seves opcions si és multichoice.

    <b>-Consultores:</b> té 5 consultores. On podem consultar: quantes preguntes té l'enquesta;
     les preguntes en sí; quanta gent ha respòs; totes les respostes; i el títol de l'Enquesta. 

    <b>-Modificadores:</b> té 5 modificadores. Que s'encarreguen de: registrar les preguntes (sigui
     del tipus que siguin); registrar les respostes (siguin del tipus que siguin); exportar l'Enquesta
     en el seu fitxer .csv corresponent; eliminar preguntes; i generar els clusters.

    <b>-Escriure:</b> té 1 funció que escriu per pantalla, i s'encarrega de mostrar de forma visual
     i atractiva les respostes de l'enquesta per cada usuari.
*/
package FONTS; //necessari!! encara que surti vermell esta be!

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

//CSV
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Enquesta 
{
    /** @brief Atribut que serveix per indentificar l'Enquesta.*/
    private String titol;

    /** @brief Atribut que serveix per indicar quants clusters volem.*/
    private int valorK;

    /** @brief Atribut que serveix per indicar quin és el ID que li tocaria al següent usuari sense haver contestat abans.*/
    private int segIdUsu = 1;

    /** @brief Atribut que serveix per indicar quin és el ID que li tocaria a la següent pregunta que caldria registrar.*/
    private int segIdPreg = 1;

    /** @brief Atribut que serveix per indicar quin és el ID de la fila (respostes d'usuari) que caldria omplir si arriba un nou usuari.*/
    private int segIdFila = 1;

    /** @brief Atribut que serveix per indicar quin és el ID de la fila (respostes d'usuari) que caldria omplir si arriba un nou usuari.*/
    private float cSil;

    /** @brief Atribut que serveix per indicar quantes preguntes com a màxim pot tenir l'Enquesta.*/
    private int MAX_PREGUNTES = 3000;

    /** @brief Atribut que serveix per indicar quants usuaris poden contestar com a màxim a l'Enquesta.*/
    private int MAX_USUARIS = 3000;

    /** @brief Indica la llargaria màxima d'una pregunta/resposta.*/
    private int maxAllargadaPreg = 6; // 6 de usuari

    /** @brief Atribut que serveix per comunicar-se amb l'administrador de l'Enquesta.*/
    private Usuari admin;

    /** @brief Atribut que serveix per consultar i manejar les respostes que ha rebut l'Enquesta.
     *  El format és:
     *  IdUsuari | Preg1 | Preg2 | Preg3 | ... | PregN | clusterAlQuePertany
    */
    private RespostaInd[][] respostesCompletes = new RespostaInd[MAX_USUARIS][MAX_PREGUNTES];

    /** @brief Atribut que serveix per anar guardant els enunciats de les preguntes a mesura que arriben.*/
    private String[] fila0 = new String[MAX_PREGUNTES];

    /** @brief Atribut que indica a quina fila de la columna 0 hauria d'anar els usuaris nous de l'Enquesta.*/
    private String[] columna0 = new String[MAX_USUARIS];

    /** @brief Atribut que serveix per dir i guardar el cluster al qual pertany cada usuari una vegada fet l'analisi.*/
    private String[] columnaClusters = new String[MAX_USUARIS];

    /** @brief Atribut que serveix per consultar i manejar les preguntes de l'Enquesta.*/
    private Pregunta[] preguntesDeEnquesta = new Pregunta[MAX_PREGUNTES];

    /** @brief Atribut que serveix per generar el cluster i consultar el seu anàlisi.*/
    private Cluster cluster;

    /** @brief Atribut que serveix per emmagatzemar el resultat donat pel cluster*/
    private AnalisiCluster analisiCluster;

    /** @brief Atribut que permet passar del nom d'un usuari al seu número identificador corresponent*/
    private Map<String,Integer> usuari2num = new HashMap<String, Integer>();

    /** @brief Atribut que permet passar de l'enunciat d'una pregunta al seu número identificador corresponent*/
    private Map<String,Integer> preg2num = new HashMap<String, Integer>();

    /** @brief Atribut que permet passar del nom d'un usuari a la seva fila corresponent en la taula de respostes.*/
    private Map<String,Integer> usari2taula = new HashMap<String, Integer>();


    //Constructores
    /** @brief Creadora per defecte.*/
    public Enquesta (String titol, Usuari admin, Integer valorK) 
    {
        this.admin = admin;
        this.titol = titol;
        this.valorK = valorK;
        fila0[0] = "Usuari";
    }

    /** @throws ExcepcioObrirArxiu 
     * @brief Creadora on l'enquesta creada ja està feta d'abans i s'IMPORTA.*/
    public Enquesta(String titol, String nomFitxer, HashMap<String, Usuari> usuarios, Scanner scMain) throws ExcepcioObrirArxiu 
    {
        this.titol = titol;
        fila0[0] = "Usuari"; 
        try (Scanner sc = new Scanner(new File(nomFitxer))) {
            String vK = sc.nextLine();
            valorK = Integer.parseInt(vK);

            String linia = sc.nextLine();
            String[] fila1 = linia.split(","); //cada preguntes[i] es una pregunta diferent
            admin = new Usuari(fila1[0], fila1[1]);
            admin.crearEnquesta(titol, this);
            usuarios.put(fila1[0], admin);
            if (sc.hasNextLine()) {
                linia = sc.nextLine();
                String[] preguntes = linia.split(","); //cada preguntes[i] es una pregunta diferent
                for (int i = 1; i < preguntes.length-1; ++i) { //comencem per 1 perque sino comença des de 'Usuari', -1 per no agafar Cluster
                    int mida_preg = preguntes[i].length();
                    if (preguntes[i].charAt(mida_preg-1) == '?') { //lliure
                        String enunciat = preguntes[i].substring(0, mida_preg-2); //ens saltem la N/T i la ?
                        if (preguntes[i].charAt(mida_preg-2) == 'N') { //numerica
                            try {
                                PreguntaLliure preg = new PreguntaLliure(enunciat, 20, true);
                                registrarPregunta(preg);
                            }
                            catch (InvalidPreguntaException e) {
                                System.err.println(e.getMessage());
                            }
                            
                        }
                        else {
                            try {
                                PreguntaLliure preg = new PreguntaLliure(enunciat, 20, false);
                                registrarPregunta(preg);
                            }
                            catch (InvalidPreguntaException e) {
                                System.err.println(e.getMessage());
                            }
                        }
                    }
                    else { //multichoice
                        String enunciat = "";
                        String opcio_actual = "";
                        Boolean stop = false;
                        int limit_opcions;
                        List<String> opcions = new ArrayList<>();
                        for (int k = 0; k < mida_preg; ++k) { //creem l'enunciat, opcions i limit opcions
                            if (preguntes[i].charAt(k) != '~' && !stop) { //enunciat
                                enunciat += preguntes[i].charAt(k);
                            }
                            else if (preguntes[i].charAt(k) == '~') {
                                stop = true;
                                while (preguntes[i].charAt(k) != '!') {
                                    if (preguntes[i].charAt(k) == '~') {
                                        if (!opcio_actual.contentEquals("")) opcions.add(opcio_actual);
                                        opcio_actual = "";
                                        ++k;
                                    }
                                    else {
                                        opcio_actual += preguntes[i].charAt(k);
                                        ++k;
                                    }
                                }
                            }
                        }
                        limit_opcions = preguntes[i].charAt(mida_preg-2) - '0'; //a enter
                        try {
                            PreguntaMultichoice preg = new PreguntaMultichoice(enunciat, opcions, limit_opcions);
                            registrarPregunta(preg);
                        }
                        catch (InvalidPreguntaException e) {
                            System.err.println(e.getMessage());
                        }
                        

                    }
                }
            }
            else {
                System.err.println("Error: no té preguntes.");
            }

            System.out.print( "Enquesta: " + titol +".csv -> vols també importar les respostes? s/n ");
            String impRespostes = scMain.nextLine();
            if (impRespostes.equalsIgnoreCase("s")) {
                if (!sc.hasNextLine()) {
                    System.err.println("Error: no hi ha respostes a importar!");
                }
                else {
                    while (sc.hasNextLine()) {
                        linia = sc.nextLine();
                        String[] respostes = linia.split(",");
                        String usuari = respostes[0]; //primer element indica quin usuari es
                        for (int i = 1; i < respostes.length-1; ++i) {
                            if (respostes[i].equalsIgnoreCase("NULL")) {
                                //no cal fer res :)
                            }
                            else if (preguntesDeEnquesta[i] instanceof PreguntaMultichoice) {
                                PreguntaMultichoice preg = (PreguntaMultichoice) preguntesDeEnquesta[i];
                                Set<Integer> opcionsEscollides = new HashSet<Integer>();

                                for(int k = 0; k < respostes[i].length(); ++k) {
                                    char c = respostes[i].charAt(k);
                                    if (c != '~') opcionsEscollides.add(c - '0');
                                }

                                try {
                                    RespostaMultichoice resp = new RespostaMultichoice(preg, usuari, opcionsEscollides);
                                    registrarResposta(resp);
                                }
                                catch (InvalidRespostaException e) {
                                    System.err.println(e.getMessage());
                                }
                                
                            }
                            else { //lliure, de tipus text o numerica
                                PreguntaLliure preg = (PreguntaLliure) preguntesDeEnquesta[i];
                                if (preg.esNumerica()) {
                                    try {
                                        RespostaNum resp = new RespostaNum(preg, usuari, Float.parseFloat(respostes[i]));
                                        registrarResposta(resp);
                                    }
                                    catch (InvalidRespostaException e) {
                                        System.err.println(e.getMessage());
                                    }
                                    
                                }
                                else {
                                    try {
                                        RespostaText resp = new RespostaText(preg, usuari, respostes[i]);
                                        registrarResposta(resp);
                                    }
                                    catch (InvalidRespostaException e) {
                                        System.err.println(e.getMessage());
                                    }
                                    
                                }
                            }
                        }                    
                    } 
                }
            }
        } 
        catch (FileNotFoundException e) {
            throw new ExcepcioObrirArxiu(nomFitxer);
        }
    }


    //Consultores
    /** @brief Consultora del nombre de preguntes que té l'Enquesta.*/
    public Integer getNumPreguntes() 
    {
        return segIdPreg - 1;
    }

    /** @brief Consultora del nombre de respostes que ha rebut l'Enquesta.*/
    public Integer getNumRespostes() 
    {
        return segIdUsu - 1;
    }

    /** @brief Consultora del nom de l'Enquesta.*/
    public String getTitolEnquesta() 
    {
        return titol;
    }

    /** @brief Consultora de les respostes de l'Enquesta en forma de matriu.*/
    public RespostaInd[][] getRespostes() 
    {
        return respostesCompletes;
    }

    /** @brief Consultora de les preguntes a l'Enquesta.*/
    public Pregunta[] getPreguntes()
    {
        return preguntesDeEnquesta;
    }


    //Modificadores
    /** @brief Permet generar els clusters i veure els seus resultats.*/
    public void generarCluster()  throws InvalidClusterException
    {
        if (getNumRespostes() > 0) {
            try {
                cluster = new Cluster(this, valorK);
                AnalisiCluster analisiCluster = cluster.analitzaCluster();
                Integer[] assig = analisiCluster.getAssignacions();
                int size = assig.length;
                columnaClusters = new String[size];
                for (int i = 0; i < size; ++i) { //passem els valor a strings per comoditat després
                    columnaClusters[i] = String.valueOf(assig[i]);
                }
                try{
                    cSil = analisiCluster.calculaSilhouette();
                }
                catch (InvalidClusterException e) {
                    System.err.println(e.getMessage());
                }
                catch (InvalidRespostaException e) {
                    System.err.println(e.getMessage());
                }
            }
            catch (InvalidClusterException e) {
                throw e;
            }
        }
        else {
            System.out.println("No es pot fer un cluster sense respostes");
        }
    }

    /** @brief Permet registrar una nova pregunta a l'Enquesta, sigui lliure o multichoice. */
    public void registrarPregunta(Pregunta preg)  
    {
        String enunciatPreg = preg.getText();
        if (preg2num.get(enunciatPreg) != null) { //pregunta feta abans o pot ser error

        }
        else {
            preg2num.put(enunciatPreg, segIdPreg);
            ++segIdPreg;
        }
        
        if (enunciatPreg.length() > maxAllargadaPreg) maxAllargadaPreg = enunciatPreg.length();
        int i = preg2num.get(enunciatPreg);
        if (fila0[i] == null) fila0[i] = enunciatPreg;
        preguntesDeEnquesta[i] = preg;
    }

    /** @brief Permet eliminar una pregunta de l'Enquesta. */
    public void eliminarPregunta(String preg)  
    {
        if (preg2num.get(preg) == null) { //pregunta no existeix

        }
        else {
            int i = preg2num.get(preg);
            preg2num.remove(preg);
            --segIdPreg;

            //movem indexos
            for (Map.Entry<String, Integer> pair : preg2num.entrySet()) {
                if (pair.getValue() > i) preg2num.put(pair.getKey(), pair.getValue() - 1);
            }
            for (int j = i; j < MAX_PREGUNTES; ++j) {
                    if (j + 1 < MAX_PREGUNTES) {
                        fila0[j] = fila0[j+1];
                        preguntesDeEnquesta[j] = preguntesDeEnquesta[j+1];
                    }
            }

            for (int k = 0; k < MAX_USUARIS; ++k) {
                for (int l = i; l < MAX_PREGUNTES; ++l) {
                    if (l + 1 < MAX_PREGUNTES) {
                        respostesCompletes[k][l] = respostesCompletes[k][l+1];
                    }        
                }
            }
        }
    }


    /** @brief Permet anar registrant les respostes de la gent en el seu array.*/
    public void registrarResposta(RespostaInd resp) 
    {
        Pregunta preg = resp.getPreguntaAssociada();
        String nomUsuari = resp.getIdUsuari();

        if (usuari2num.get(nomUsuari) == null) { // l'usuari no estava enregistrat
            usuari2num.put(nomUsuari, segIdUsu);
            ++segIdUsu;
        }

        String enunciatPreg = preg.getText();
        if (preg2num.get(enunciatPreg) == null) {}//throw error, preg d'una altra enquesta o no existeix
        
        if (usari2taula.get(nomUsuari) == null) { //usuari no té assignada una fila en la taula
            usari2taula.put(nomUsuari, segIdFila);
            ++segIdFila;
        }

        int i = usari2taula.get(nomUsuari);
        int j = preg2num.get(enunciatPreg);
        if (columna0[i] == null) columna0[i] = nomUsuari; //posem el nom de l'usuari a la nova fila
        if (respostesCompletes[i-1][j-1] == null) respostesCompletes[i-1][j-1] = resp;
        if (respostesCompletes[i-1][j-1].getRespostaText().length() > maxAllargadaPreg) maxAllargadaPreg = respostesCompletes[i][j].getRespostaText().length(); 
    }

    /**@throws ExcepcioGenerarArxiu 
     * @brief Permet generar el fitxer .csv corresponent en la carpeta Enquestes.*/
    public void exportarEnquesta(String nomNouFitxer, Scanner sc) throws ExcepcioGenerarArxiu
    {
        try (PrintWriter pw = new PrintWriter(new FileWriter("FONTS/CtrlPersistencia/Enquestes/" + nomNouFitxer + ".csv"))) {
            pw.println(valorK);
            pw.println(admin.getName() + "," + admin.getPassword());
            // escriu les preguntes
            pw.print("Usuaris,");
            int n_preg = getNumPreguntes();
            for (int i = 1; i <= n_preg; ++i) {
                if (i < n_preg) {
                    if (preguntesDeEnquesta[i] instanceof PreguntaLliure) {
                        PreguntaLliure preg = (PreguntaLliure) preguntesDeEnquesta[i];
                        if (preg.esNumerica()) { //numèrica
                            pw.print(fila0[i] + "N" + "?" + ","); //pregunta lliure i numerica
                        }
                        else { //text
                            pw.print(fila0[i] + "T" + "?" + ","); //pregunta lliure i de text
                        }
                    }
                    else { //multichoice
                        PreguntaMultichoice preg = (PreguntaMultichoice) preguntesDeEnquesta[i];
                        List<String> opcions = preg.getOpcions();
                        String aux = "~"; //farem que les opcions siguien entre 'x'
                        int size = opcions.size();
                        for (int k = 0; k < size; ++k) {
                            aux += opcions.get(k) + "~";
                        }
                        int limit_opcions = preg.getLimitOpcions();
                        pw.print(fila0[i] + aux + "!" + limit_opcions + "!" + ","); //pregunta multichoice
                    }
                }
                else { //ultima pregunta no cal coma
                    if (preguntesDeEnquesta[i] instanceof PreguntaLliure) {
                        PreguntaLliure preg = (PreguntaLliure) preguntesDeEnquesta[i];
                        if (preg.esNumerica()) { //numèrica
                            pw.print(fila0[i] + "N" + "?"); //pregunta lliure i numerica
                        }
                        else { //text
                            pw.print(fila0[i] + "T" + "?"); //pregunta lliure i de text
                        }
                    }
                    else { //multichoice
                        PreguntaMultichoice preg = (PreguntaMultichoice) preguntesDeEnquesta[i];
                        List<String> opcions = preg.getOpcions();
                        String aux = "~"; //farem que les opcions siguien entre 'x'
                        int size = opcions.size();
                        for (int k = 0; k < size; ++k) {
                            aux += opcions.get(k) + "~";
                        }
                        int limit_opcions = preg.getLimitOpcions();
                        pw.print(fila0[i] + aux + "!" + limit_opcions + "!"); //pregunta multichoice
                    }
                }
            }
            pw.print(",Cluster");

            System.out.print("Vols també exportar les respostes? s/n ");
            String consulta = sc.nextLine();

            if (consulta.equalsIgnoreCase("s")) {
                if (segIdFila == 1) System.err.println("Error: no hi ha respostes a exportar!");
                else {
                    pw.println();
                    for (int i = 1; i <= segIdFila-1; ++i) {
                        pw.print(columna0[i] + ",");
                        for (int j = 1; j <= segIdPreg-1; ++j) {
                            if (j < segIdPreg-1) { //cal comes
                                if (respostesCompletes[i-1][j-1] == null) pw.print("NULL,");
                                else if (respostesCompletes[i-1][j-1] instanceof RespostaMultichoice) {
                                    RespostaMultichoice resp = (RespostaMultichoice) respostesCompletes[i-1][j-1];
                                    Set<Integer> respostes = resp.getValor();
                                    Iterator<Integer> namesIterator = respostes.iterator();
                                    while(namesIterator.hasNext()) {
                                       Integer num = namesIterator.next();
                                       pw.print(num + ",");
                                    }
                                }
                                else {
                                    String resp = respostesCompletes[i-1][j-1].getRespostaText();
                                    pw.print(resp + ",");
                                }
                            }
                            else { //ultima resposta no cal comes
                                if (respostesCompletes[i-1][j-1] == null) pw.print("NULL");
                                else if (respostesCompletes[i-1][j-1] instanceof RespostaMultichoice) {
                                    RespostaMultichoice resp = (RespostaMultichoice) respostesCompletes[i-1][j-1];
                                    Set<Integer> respostes = resp.getValor();
                                    Iterator<Integer> namesIterator = respostes.iterator();
                                    while(namesIterator.hasNext()) {
                                       Integer num = namesIterator.next();
                                       if (namesIterator.hasNext()) pw.print(num + "~");
                                       else pw.print(num);
                                    }
                                }
                                else {
                                    String resp = respostesCompletes[i-1][j-1].getRespostaText();
                                    pw.print(resp);
                                }
                                if (columnaClusters != null) {
                                    pw.print("," + columnaClusters[i-1]);
                                }
                                else {
                                    pw.print(",NULL");
                                }
                            }
                        }
                        if (i < segIdFila-1)  {
                            pw.println();
                        }
                    }
                }

            }

            System.out.println("Enquesta exportada correctament a la carpeta 'Enquestes' amb el nom " + nomNouFitxer);

        } 
        catch (IOException e) {
            throw new ExcepcioGenerarArxiu(nomNouFitxer);
        }
    }


    //Escriure
    /** @brief Permet veure les respostes registrades de la gent.*/
    public void veureRespostes() 
    {
        try{
            if (segIdFila > 1) generarCluster();
            System.out.println();
            System.out.println(titol);
            Boolean stop = false;
            String espai;
            String guions = "-".repeat(maxAllargadaPreg + 1) + "+-";
            String linia = "";
            fila0[segIdPreg] = "Cluster"; //per indicar a quin cluster pertany
            for (int n = 0; n < getNumPreguntes() + 2; n = n + 1) linia += guions; 
            linia = linia.substring(0, linia.length()-1); //eliminar ultim guio
            for (int i = 0; !stop && i < MAX_USUARIS; ++i) {
                for (int j = 0; !stop && j < MAX_PREGUNTES; ++j) {
                    if (i == 0) {
                        if (fila0[j] != null) {
                            int num_espais = (1 + maxAllargadaPreg) - fila0[j].length();
                            espai = " ".repeat(num_espais);
                            System.out.print(fila0[j] + espai + "| ");
                        }
                    }
                    else {
                        if (j == 0) {
                            if (columna0[i] != null) {
                                int num_espais = (1 + maxAllargadaPreg) - columna0[i].length();
                                espai = " ".repeat(num_espais);
                                System.out.print(columna0[i] + espai + "| ");
                            }
                            else stop = true;
                        }
                        else if (j == segIdPreg) { //cluster
                            if (columnaClusters[j] == null) {
                                int num_espais = (1 + maxAllargadaPreg) - 4;
                                espai = " ".repeat(num_espais);
                                System.out.print("NULL" + espai + "| ");
                            }
                            else {
                                int num_espais = (1 + maxAllargadaPreg) - columnaClusters[i - 1].length();
                                espai = " ".repeat(num_espais);
                                System.out.print(columnaClusters[i - 1] + espai + "| ");
                            }
                            
                        }
                        else {
                            if (respostesCompletes[i-1][j-1] != null) {
                                int num_espais = (1 + maxAllargadaPreg) - respostesCompletes[i-1][j-1].getRespostaText().length();
                                espai = " ".repeat(num_espais);
                                System.out.print(respostesCompletes[i-1][j-1].getRespostaText() + espai + "| ");
                            }
                            else if (fila0[j] != null) {
                                int num_espais = (1 + maxAllargadaPreg) - 4;
                                espai = " ".repeat(num_espais);
                                System.out.print("NULL" + espai + "| ");
                            }
                        }
                    }
                }
                System.out.println();
                if (!stop) {
                    System.out.println(linia);
                }
            }
            fila0[segIdPreg] = null; //treiem cluster
            System.out.println("Valor Coeficient de Silhouette: " + cSil);
        } catch (InvalidClusterException e) {
            System.err.println(e);
        } catch (Exception e) {
            System.err.println("Error inesperat en el càlcul de distància: " + e.getMessage());
        }
    }
}