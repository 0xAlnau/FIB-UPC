/*    +----------------------------------------------------------+
      |                     RespostaInd.java                     |
      +----------------------------------------------------------+
      | Repositori:                                              |
      |   ·subgrup-prop32.3                                      |
      +----------------------------------------------------------+
      | Aquest mòdul ha sigut programat per:                     |
      |   ·Santiago lluzar                                       |
      +----------------------------------------------------------+
      | Versió 1.0 : package FONTS;                              |
      +----------------------------------------------------------+
*/

/** @file RespostaNum.java
    @brief Codi de la classe RespostaNum.
*/


/** @class RespostaNum
    @brief Representa una resposta numèrica.
    S'utilitza 'float' per emmagatzemar el valor.
*/

package FONTS;


public class RespostaNum extends RespostaInd {

    /** @brief El valor numèric de la resposta.*/
    private float valor;

    /** @brief Constructor.
     * @param preguntaAssociada La Pregunta associada.
     * @param idUsuari L'usuari que respon.
     * @param valor El valor numèric respost (float).
     * @throws InvalidRespostaException Si els paràmetres base són invàlids (a la superclasse) o si la pregunta no és de tipus Lliure-Numèrica.
     */
    public RespostaNum(Pregunta preguntaAssociada, String idUsuari, float valor) throws InvalidRespostaException {
        super(preguntaAssociada, idUsuari, String.valueOf(valor));
        
        if (!(preguntaAssociada instanceof PreguntaLliure) || !((PreguntaLliure) preguntaAssociada).esNumerica()) {
            throw new InvalidRespostaException("Tipus de resposta numèrica no és compatible amb el tipus de pregunta.");
        }
        
        this.valor = valor;
    }

    /** @brief Obté el valor numèric.
     * @return El valor (Float).
     */
    @Override
    public Float getValor() {
        return valor;
    }

    /** @brief Estableix el valor numèric.
     * @param valor El nou valor (float).
     */
    public void setValor(float valor) {
        this.valor = valor;
        // Actualitzem també el valor a la classe base
        this.respostaText = String.valueOf(valor);
    }
    
    /** @brief Calcula la distància d'aquesta resposta a una altra.
     *
     * @param altra La segona resposta.
     * @return La distància absoluta (SENSE NORMALITZAR).
     */
    @Override
    public float calcularDistancia(RespostaInd altra) {
        // Cas 1: Nuls
        if (altra == null) {
            return DISTANCIA_INFINITA;
        }
        
        // Cas 2: Tipus diferents
        if (!(altra instanceof RespostaNum)) {
            return DISTANCIA_INFINITA; 
        }

        // Cas 3: Mateix tipus (Num)
        RespostaNum altraNum = (RespostaNum) altra;
            
        // Dist = |x_ik - x_jk|
        float distBruta = Math.abs(this.valor - altraNum.getValor());
            

        return distBruta;
    }

    /** @brief Crea i retorna una còpia d'aquesta resposta numèrica.
     * @return Una nova instància de RespostaNum.
     */
    @Override
    public RespostaInd clone() {
        try {
            return new RespostaNum(this.preguntaAssociada, this.idUsuari, this.valor);
        } catch (InvalidRespostaException e) {
            // En teoria no passa mai perquè l'objecte original ja era vàlid
            throw new InternalError(e);
        }
    }
}