/*    +----------------------------------------------------------+
      |                  PreguntaLliure.java                     |
      +----------------------------------------------------------+
      | Repositori:                                              |
      |   ·subgrup-prop32.3                                      |
      +----------------------------------------------------------+
      | Aquest mòdul ha sigut programat per:                     |
      |   ·Santiago Lluzar                                       |
      +----------------------------------------------------------+
      | Versió 1.0 : package FONTS;                              |
      +----------------------------------------------------------+
*/

/** @file PreguntaLliure.java
    @brief Codi de la classe PreguntaLliure.
*/

/** @class PreguntaLliure
    @brief Representa una pregunta de resposta lliure,
    que pot ser de text (string) o numèrica (float).
*/
package FONTS;

public class PreguntaLliure extends Pregunta {

    /** @brief El nombre màxim de caràcters permesos a la resposta.*/
    private int numMaxCaracters;

    /** @brief Flag per indicar si la resposta s'ha de tractar
     * com un número (true) o com a text (false).
     */
    private boolean esNumerica;

    /** @brief Constructor per a una pregunta de text lliure.
     * @param text El text de la pregunta.
     * @param numMaxCaracters El límit de caràcters.
     * @param esNumerica 'true' si la resposta és un float,
     * 'false' si és un string.
     * @throws InvalidPreguntaException Si el text és invàlid (a la superclasse) o el numMaxCaracters és negatiu o 0.
     */
    public PreguntaLliure(String text, int numMaxCaracters, boolean esNumerica) throws InvalidPreguntaException {
        super(text, TipusPregunta.LLIURE);
        
        if (numMaxCaracters <= 0) {
            throw new InvalidPreguntaException("El nombre màxim de caràcters ha de ser positiu major a 0.");
        }
        this.numMaxCaracters = numMaxCaracters;
        this.esNumerica = esNumerica;
    }
    /** @brief Consultora del límit de caràcters.
     * @return El nombre màxim de caràcters.
     */
    public int getNumMaxCaracters() {
        return numMaxCaracters;
    }

    /** @brief Comprova si la pregunta espera una resposta numèrica.
     * @return 'true' si és numèrica, 'false' si és de text.
     */
    public boolean esNumerica() {
        return esNumerica;
    }
}