
/*
   +----------------------------------------------------------+
   |                      CtrlDominio                         |
   +----------------------------------------------------------+
   | Repositori:                                              |
   |   ·subgrup-prop32.3                                      |
   +----------------------------------------------------------+
   | Aquest mòdul ha sigut programat per:                     |
   |   ·Gabriel Alegre Conchello                              |
   | Cooperador:                                              |
   |   ·Arnau Cullell Martínez                                |
   +----------------------------------------------------------+
   | Versió 1.0 : S'encarrega de la comunicació amb les       |
   |              clases i retorna els valor que vol la clase |
   |              CtrlPresentacio                             |
   |                                                          |
   +----------------------------------------------------------+
 */

package FONTS;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Stream;

public class CtrlDominio {

    /** @brief Atribut que serveix per guardar usuaris.*/
    private HashMap<String, Usuari> usuarios; //registro de los Usuarios;

    /** @brief Atribut que serveix per guardar enquestes.*/
    private HashMap<String, Enquesta> titol2Enquesta;

    /** @brief Atribut que serveix per imprimir per pantalla.*/
    private Scanner sc = new Scanner(System.in);

    /** @brief Creadora del controlador de domini.*/
    public CtrlDominio() {
        usuarios = new HashMap<String, Usuari>();
        titol2Enquesta = new HashMap<String, Enquesta>();
    }

    /** @brief Asigna el scanner de CtrlPresentación. S'usa en els tests.*/
    public void setSc(Scanner scP) {
        this.sc = scP;
    }

    /** @brief Comprova si un nom d'usuari ja està registrat.*/
    public boolean nombreEnUso(String name) {
        if (usuarios == null) return false;
        return usuarios.containsKey(name);
    }

    /** @brief Crea un nou usuari amb nom i contrasenya dels paràmetres.*/
    public void crearUsuari(String name, String password) {
        Usuari u = new Usuari(name, password);
        usuarios.put(name, u);
        u.setPassword(password);
    }

    /** @brief Comprova que la contrasenya d’un usuari coincideix amb la del paràmetre.*/
    public boolean comprovarPassword(String name, String password) {
        Usuari u = usuarios.get(name);
        return u.checkPassword(password);
    }

    /** @brief Indica si no existeix cap enquesta amb el títol del paràmetre.*/
    public boolean noExisteixEnquesta(String titol) {
        return (titol2Enquesta.get(titol) == null);
    }

    /** @brief Crea una enquesta buida associada a un usuari creador.*/
    public void crearEnquestaBuida(String titol, String name) {
        Usuari u = usuarios.get(name);
        System.out.print("Valor de K que vols: ");
        Integer k = sc.nextInt();
        sc.nextLine();
        Enquesta enq = new Enquesta(titol, u, k);
        u.crearEnquesta(titol, enq);
        titol2Enquesta.put(titol, enq);
    }

    /** @brief Afegeix una pregunta de resposta lliure a una enquesta.*/
    public void crearPreguntaLliure(String titol, String resp, int n, boolean bNumerica) throws InvalidPreguntaException {
        PreguntaLliure preg = new PreguntaLliure(resp, 20, bNumerica);
        titol2Enquesta.get(titol).registrarPregunta(preg);     
    }

    /** @brief Afegeix una pregunta amb opcions com respostes a una enquesta.*/
    public void crearPreguntaMultichoice(String titol, String resp, List<String> opcions, int max_opcions) {
        try {
            PreguntaMultichoice preg = new PreguntaMultichoice(resp, opcions, max_opcions);
            titol2Enquesta.get(titol).registrarPregunta(preg);
        }
        catch (InvalidPreguntaException e) {
            System.err.println(e.getMessage());
        }
        
    }

    /** @brief Mostra per pantalla tots els títols de les enquestes registrades.*/
    public void listarEnquestes() {
        for (HashMap.Entry<String, Enquesta> entry : titol2Enquesta.entrySet()) {
            System.out.println(entry.getKey());
        }
        System.out.println("");
    }

    /** @brief Mostra per pantalla tots els títols de les enquestes creades per l'Usuari.*/
    public void listarEnquestesUsuari(String name) {
        Usuari u = usuarios.get(name);
        u.listarEnquestes();
    }

    /** @brief Comprova si existeix una enquesta amb el títol indicat.*/
    public boolean existeEnquesta(String titol) {
        if (titol2Enquesta == null) return false;
        return titol2Enquesta.containsKey(titol);
    }

    /** @brief Comprova si existeix una enquesta amb el títol indicat en les enquestes de l'Usuari
     * amb nom name.*/
    public boolean existeEnquestaUsuari(String name, String titol) {
        Usuari u = usuarios.get(name);
        return u.existeEnquesta(titol);
    }

    /** @brief Permet que un usuari respongui totes les preguntes d’una enquesta.
     * Gestiona la lectura de respostes per terminal i registra cada resposta.*/
    public void contestarEnquesta(String titol, String name)
    {
        Usuari u = usuarios.get(name);
        System.out.println("Quan vulguis sortir posa: 's' ");
        

        Pregunta[] preguntes = titol2Enquesta.get(titol).getPreguntes();
        int size = titol2Enquesta.get(titol).getNumPreguntes();
        for (int i = 1; i <= size; ++i) {
            System.out.print("·" + preguntes[i].getText() + ": ");
            if (preguntes[i] instanceof PreguntaLliure) {
                PreguntaLliure preg = (PreguntaLliure) preguntes[i];
                if (preg.esNumerica()) {
                    float num = sc.nextFloat();
                    sc.nextLine(); //consumir salt de linia
                    try {
                        RespostaNum respNum = new RespostaNum(preg, u.getName(), num);
                        titol2Enquesta.get(titol).registrarResposta(respNum);
                    }
                    catch (InvalidRespostaException e) {
                        e.getMessage();
                    }
                    
                }
                else {
                    String str = sc.nextLine();
                    try {
                        RespostaText respNum = new RespostaText(preg, u.getName(), str);
                        titol2Enquesta.get(titol).registrarResposta(respNum);
                    }
                    catch (InvalidRespostaException e) {
                        e.getMessage();
                    }
                    
                }
            }
            else {
                PreguntaMultichoice preg = (PreguntaMultichoice) preguntes[i];
                System.out.println();
                System.out.println("Les opcions són:");
                List<String> opcions = preg.getOpcions();
                int n = opcions.size();
                for (int k = 0; k < n; ++k) {
                    System.out.println((k) + "-" + opcions.get(k));
                }
                String str = "";

                int limit_opcions = preg.getLimitOpcions();
                int escollides = 0;
                Set<Integer> opcions_escollides = new HashSet<>();
                System.out.println("Només pots escollir " + limit_opcions + " opcio/ns!");
                System.out.println("Per acabar presiona 's', digues quines opcions esculls: ");
                while (!str.contentEquals("s") && escollides < limit_opcions) {
                    str = sc.nextLine();
                    if (!str.contentEquals("s")) opcions_escollides.add(Integer.parseInt(str));
                    ++escollides;
                }
                try {
                    RespostaMultichoice resp = new RespostaMultichoice(preg, u.getName(), opcions_escollides);
                    titol2Enquesta.get(titol).registrarResposta(resp);
                }
                catch (InvalidRespostaException e) {
                    e.getMessage();
                }
                
            }

        }

        System.out.println();
    }

    /** @brief Mostra totes les respostes d’una enquesta.*/
    public void veureResultatsEnquesta(String titol)
    {
        //ja es comproba que l'Usuari te l'enquesta
        titol2Enquesta.get(titol).veureRespostes();
    }

    /** @brief Elimina una pregunta concreta d’una enquesta.*/
    public void eliminarPreguntes(String titol, String preg) {
        titol2Enquesta.get(titol).eliminarPregunta(preg);
    }

    /** @brief Genera un fitxer CSV amb tota la informació de l’enquesta.*/
    public void exportarEnquesta(String titol, String nomNouFitxer, Scanner sc)
    {
        try {
            titol2Enquesta.get(titol).exportarEnquesta(nomNouFitxer, sc);
        }
        catch (ExcepcioGenerarArxiu e) {
            System.err.println(e.getMessage());
        }
        
    }

    /** @brief Agafa totes les enquestes guardades a la capa de Persistència.*/
    public void importaEnquestes() throws ExcepcioObrirArxiu {
        Path directori = Paths.get("FONTS/CtrlPersistencia/Enquestes");
        try (Stream<Path> paths = Files.list(directori)) {
            paths.filter(Files::isRegularFile).forEach(path -> { //per cada arxiu al directori que faci el següent
                String titol = String.valueOf(path.getFileName());
                String titolEnq = titol.substring(0, titol.length() - 4);
                try {
                    Enquesta e = new Enquesta(titolEnq, "FONTS/CtrlPersistencia/Enquestes/" + titol, usuarios, sc);
                    titol2Enquesta.put(titolEnq, e);
                }
                catch (ExcepcioObrirArxiu e) {
                    System.err.println(e.getMessage());
                }
            });
            System.out.println("Totes les enquestes s'han importat correctament.");
        }
        catch (IOException e) {
            throw new ExcepcioObrirArxiu("Enquestes");
        }
    }

    /** @brief Agafa totes les enquestes que hi ha en el programa i les guarda a la carpeta Enquestes.*/
    public void exportarEnquestes () {
        for (HashMap.Entry<String, Enquesta> entry : titol2Enquesta.entrySet()) {
            exportarEnquesta(entry.getKey(), entry.getKey(), sc);
        }
        System.out.println("S'han exportat totes les enquestes.");
    }

    /** @brief Agafa tots els usuaris guardats a la capa de Persistència.*/
    public void importaUsuaris() throws ExcepcioObrirArxiu {
        try (Scanner scF = new Scanner(new File("FONTS/CtrlPersistencia/Usuaris/usuaris.csv"))) {
            scF.nextLine(); //consumeix Usuari i Password del principi
            while (scF.hasNextLine()) {
                String linia = scF.nextLine();
                String[] usuariContra = linia.split(","); //pos 0 té usuari i pos 1 té la contra
                Usuari u = new Usuari(usuariContra[0], usuariContra[1]);
                usuarios.put(usuariContra[0], u);
            }
            System.out.println("Usuaris anteriors importats.");
        }
        catch (FileNotFoundException e) {
            throw new ExcepcioObrirArxiu("Usuaris");
        }
    }

    /** @brief Agafa tots els usuaris en el programa i els guarda a la capa de Persistència.*/
    public void exportarUsuaris() throws ExcepcioGenerarArxiu {
        try (PrintWriter pw = new PrintWriter(new FileWriter("FONTS/CtrlPersistencia/Usuaris/usuaris.csv"))) {
            pw.println("Usuari,Password");
            for (HashMap.Entry<String, Usuari> entry : usuarios.entrySet()) {
                pw.println(entry.getKey() + "," + entry.getValue().getPassword());
            }
            System.out.println("S'han guardat els usuaris.");
        }
        catch (IOException e) {
            throw new ExcepcioGenerarArxiu(null);
        }
    }

    /** @brief Elimina l'enquesta titol creada per l'usuari amb nom name.*/
    public void eliminarEnquesta(String name, String titol) {
        Usuari u = usuarios.get(name);
        u.eliminarEnquesta(titol);
        titol2Enquesta.remove(titol);
    }

    /** @brief [PER A TESTS] Retorna el nombre de preguntes d'una enquesta. */
    public int getNumPreguntes(String titol) {
        Enquesta e = titol2Enquesta.get(titol);
        if (e == null) return -1;
        // Cridem la consultora de l'enquesta
        return e.getNumPreguntes(); 
    }

    /** @brief [PER A TESTS] Retorna el nombre de respostes que té una enquesta. */
    public int getNumRespostes(String titol) {
        Enquesta e = titol2Enquesta.get(titol);
        if (e == null) return -1;
        // Cridem la consultora de l'enquesta
        return e.getNumRespostes(); 
    }

}
