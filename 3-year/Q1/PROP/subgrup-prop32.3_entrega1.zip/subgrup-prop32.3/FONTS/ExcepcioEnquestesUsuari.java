/*
   +----------------------------------------------------------+
   |                ExcepcioEnquestesUsuari.java               |
   +----------------------------------------------------------+
   | Repositori:                                              |
   |   ·subgrup-prop32.3                                      |
   +----------------------------------------------------------+
   | Aquest mòdul ha sigut programat per:                     |
   |   Gabriel Alegre                                         |
   +----------------------------------------------------------+
   | *Versió 1.0: permet generar una excepció quan no es      |
   |             genera correctament l'arxiu .csv a l'exportar|
   |              una enquesta.                               |
   |                                                          |
   +----------------------------------------------------------+
 */
package FONTS;
public class ExcepcioEnquestesUsuari extends Exception
{
    public ExcepcioEnquestesUsuari()
    {
        super("·Error: no s'ha pogut accedir a les enquestes de l'Usuari.");
    }

}