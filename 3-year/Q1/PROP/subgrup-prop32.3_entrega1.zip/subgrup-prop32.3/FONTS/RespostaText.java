/*    +----------------------------------------------------------+
      |                     RespostaInd.java                     |
      +----------------------------------------------------------+
      | Repositori:                                              |
      |   ·subgrup-prop32.3                                      |
      +----------------------------------------------------------+
      | Aquest mòdul ha sigut programat per:                     |
      |   ·Santiago lluzar                                       |
      +----------------------------------------------------------+
      | Versió 1.0 : package FONTS;                              |
      +----------------------------------------------------------+
*/


/** @file RespostaText.java
    @brief Codi de la classe RespostaText.
*/

/** @class RespostaText
    @brief Representa una resposta de text.
*/

package FONTS;


public class RespostaText extends RespostaInd {

    /** @brief El text de la resposta.*/
    private String text;

    /** @brief Constructor.
     * @param preguntaAssociada La Pregunta associada.
     * @param idUsuari L'usuari que respon.
     * @param text El text respost.
     * @throws InvalidRespostaException Si els paràmetres base són invàlids (a la superclasse), si la pregunta no és Lliure-Text o si el text supera el límit.
     */
    public RespostaText(Pregunta preguntaAssociada, String idUsuari, String text) throws InvalidRespostaException {
        super(preguntaAssociada, idUsuari, text);
        
        // Comprova que la pregunta associada sigui Lliure i no Numèrica
        if (!(preguntaAssociada instanceof PreguntaLliure) || ((PreguntaLliure) preguntaAssociada).esNumerica()) {
            throw new InvalidRespostaException("Tipus de resposta de text no és compatible amb el tipus de pregunta.");
        }

        // Comprova si  la llargada és vàlida
        PreguntaLliure pl = (PreguntaLliure) preguntaAssociada;
        String textValidat = (text != null) ? text : "";
        if (textValidat.length() > pl.getNumMaxCaracters()) {
            throw new InvalidRespostaException("La resposta supera el límit de caràcters (" + pl.getNumMaxCaracters() + ").");
        }
        
        this.text = textValidat.toLowerCase();
        this.respostaText = this.text;
    }

    /** @brief Obté el text de la resposta.
     * @return El text (String) en minúscules.
     */
    @Override
    public String getValor() {
        return text;
    }

    /** @brief Estableix el text de la resposta.
     * @param text El nou text.
     * @throws InvalidRespostaException Si el text supera el límit de caràcters de la pregunta.
     */
    public void setText(String text) throws InvalidRespostaException {
        PreguntaLliure pl = (PreguntaLliure) this.preguntaAssociada;
        String textValidat = (text != null) ? text : "";
        
        if (textValidat.length() > pl.getNumMaxCaracters()) {
            throw new InvalidRespostaException("La resposta supera el límit de caràcters (" + pl.getNumMaxCaracters() + ").");
        }
        
        this.text = textValidat.toLowerCase();
        this.respostaText = this.text;
    }
    
    /**
     * @brief Calcula la distància de Levenshtein (privat).
     * @param s1 Primera cadena de text.
     * @param s2 Segona cadena de text.
     * @return El nombre d'edicions.
     */
    private int levenshteinDistance(String s1, String s2) {
        int[][] dp = new int[s1.length() + 1][s2.length() + 1];

        for (int i = 0; i <= s1.length(); i++) {
            for (int j = 0; j <= s2.length(); j++) {
                if (i == 0) {
                    dp[i][j] = j;
                } else if (j == 0) {
                    dp[i][j] = i;
                } else {
                    int cost = (s1.charAt(i - 1) == s2.charAt(j - 1)) ? 0 : 1;
                    dp[i][j] = Math.min(
                            dp[i - 1][j] + 1,
                            Math.min(
                                    dp[i][j - 1] + 1,
                                    dp[i - 1][j - 1] + cost
                            )
                    );
                }
            }
        }
        return dp[s1.length()][s2.length()];
    }
    
    /** @brief Calcula la distància d'aquesta resposta a una altra.
     *
     * @param altra La segona resposta.
     * @return La distància de Levenshtein normalitzada [0,1].
     */
    @Override
    public float calcularDistancia(RespostaInd altra) {
        // Cas 1: Nuls
        if (altra == null) {
            return MAX_DISTANCIA;
        }
        
        // Cas 2: Tipus diferents
        if (!(altra instanceof RespostaText)) {
            return MAX_DISTANCIA;
        }

        // Cas 3: Mateix tipus (Text)
        String s1 = this.text;
        String s2 = ((RespostaText) altra).getValor();

        if (s1.equals(s2)) {
            return MIN_DISTANCIA;
        }
        
        int len1 = s1.length();
        int len2 = s2.length();
        
        if (len1 == 0 || len2 == 0) {
            return MAX_DISTANCIA;
        }

        int lev = levenshteinDistance(s1, s2);
        int diffAbs = Math.abs(len1 - len2);

        // Denominador:  max(len1,len2) - |len1-len2|
        int denominador = Math.max(len1, len2) - diffAbs;
        
        if (denominador == 0) {
            return MAX_DISTANCIA; 
        }

        // Dist = (lev - |len1-len2|) / denominador
        float numerador = (float) (lev - diffAbs);
        return numerador / (float) denominador;
    }
    
    /** @brief Crea i retorna una còpia d'aquesta resposta de text.
     * @return Una nova instància de RespostaText.
     */   
    @Override
    public RespostaInd clone() {
        try {
            return new RespostaText(this.preguntaAssociada, this.idUsuari, this.text);
        } catch (InvalidRespostaException e) {
            // En teoria no passa mai perquè l'objecte original ja era vàlid
            throw new InternalError(e);
        }
    }
}