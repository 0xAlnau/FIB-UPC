/*
   +----------------------------------------------------------+
   |                      Usuari.java                       |
   +----------------------------------------------------------+
   | Repositori:                                              |
   |   ·subgrup-prop32.3                                      |
   +----------------------------------------------------------+
   | Aquest mòdul ha sigut programat per:                     |
   |   ·Gabriel Alegre Conchello                             |
   +----------------------------------------------------------+
   | Versió 0.5 : Començant a implementar funcionalitats      |
   |              bàsiques                                    |
   | Versió 1.0 : Es pot modificar i usar la clase Usuari     |
   |              per crear, comprovar el log_in i saber      |
   |              quines enquestes ha creat                   |
   |                                                          |
   +----------------------------------------------------------+
 */

/** @file Usuari.java
 @brief Codi de la classe Usuari.
 */



/** @class Usuari
 @brief Representa un usuari amb el seu identificador, i pot ser o admin o contestador.

 <b>-Constructora:</b> només té la constructora per defecte, on s'inicialitza una instància
 de la clase Usuari amb el seu nom. També disposa d'una constructora que permet
 inicialitzar l'usuari amb un nom i una contrasenya.

 <b>-Consultores:</b> Es pot consultar el nom de l'Usuari, així com verificar si la
 contrasenya introduïda coincideix amb la registrada.

 <b>-Modificadores:</b> Permet modificar tant el nom com la contrasenya de l'Usuari.

 <b>-Escriure:</b> Inclou funcionalitats per crear noves enquestes, eliminar-ne,
 i llistar totes les enquestes creades associades a l'Usuari.
 */

package FONTS;

import java.util.*;

public class Usuari
{
    /** @brief Atribut que serveix per identificar Usuari.*/
    private String name; //nombre del Usuario, no se puede cambiar

    /** @brief Atribut que serveix per accedir al mateix Usuari amb una identificació.*/
    private String password;

    /** @brief Atribut que serveix per guardar la llista d'enquestes creades per l'Usuari.*/
    private HashMap<String,Enquesta> enquestes;


    //Constructora
    /** @brief Creadora per defecte.*/
    public Usuari() {
        this.name = "";
        this.password = "";
        enquestes = new HashMap<String, Enquesta>();
    }

    /** @brief Creadora que assigna un nom i un password.*/
    public Usuari(String name, String password) {
        this.name = name;
        this.password = password;
        enquestes = new HashMap<String, Enquesta>();
    }

    //Consultores
    /** @brief Retorna el nom de l'Usuari.*/
    public String getName()
    {
        return this.name;
    }

    /** @brief Retorna el password de l'Usuari.*/
    public String getPassword() {
        return this.password;
    }

    /** @brief Retorna true si l'Usuari té el password igual al paràmetre donat.*/
    public boolean checkPassword(String password)
    {
        return this.password.equals(password);
    }

    /** @brief Asigna el nom a l'Usuari.*/
    public void setName(String name) {
        this.name = name;
    }

    /** @brief Asigna el password a l'Usuari.*/
    public void setPassword(String password) {
        this.password = password;
    }

    /** @brief Asigna les enquestes creades a l'Usuari.*/
    public void setEnquestes(HashMap<String,Enquesta> enquestes) {
        this.enquestes = enquestes;
    }

    /** @brief Retorna true si existeix una enquesta titol en les enquestes creades per l'Usuari*/
    public boolean existeEnquesta(String titol) {
        if (enquestes == null) return false;
        return enquestes.containsKey(titol);
    }

    /** @brief Afegeix una enquesta a la llista de creades de l'Usuari.*/
    public void crearEnquesta(String titol, Enquesta enq) {
        try {
            if (enquestes == null) {
                throw new ExcepcioEnquestesUsuari();
            }
            enquestes.put(titol, enq);
            return;
        } catch (ExcepcioEnquestesUsuari e) {
            System.err.println("Error al crear enquesta." + e.getMessage());
        }
    }

    /** @brief Elimina una enquesta a la llista de creades de l'Usuari.*/
    public void eliminarEnquesta(String titol) {
        try {
            if (!enquestes.containsKey(titol)) {
                throw new IllegalArgumentException("No existeix aquesta enquesta.");
            }
            if (enquestes == null) {
                throw new ExcepcioEnquestesUsuari();
            }
            enquestes.remove(titol);
        } catch (IllegalArgumentException e) {
            System.err.println("Error al eliminar enquesta: " + e.getMessage());
        } catch (ExcepcioEnquestesUsuari e) {
            System.err.println("Error al eliminar enquesta." + e.getMessage());
        }
    }

    /** @brief Llista els titols de llista d'enquestes creades de l'Usuari.*/
    public void listarEnquestes() {
        try {
            if (enquestes == null) {
                throw new ExcepcioEnquestesUsuari();
            }
            for (HashMap.Entry<String, Enquesta> entry : enquestes.entrySet()) {
                System.out.println(entry.getKey());
            }
            System.out.println("");
        } catch (ExcepcioEnquestesUsuari e) {
            System.err.println("Error al llistar enquestes." + e.getMessage());
        }
    }

    /** @brief Retorna el conjunt de titols de les enquestes creades.*/
    public Set<String> getTitulosEnquesta() {
        try {
            if (enquestes == null) {
                throw new ExcepcioEnquestesUsuari();
            }
            return enquestes.keySet();
        } catch (ExcepcioEnquestesUsuari e) {
            System.err.println("Error al obtenir els títols de les enquestes" + e.getMessage());
            return Collections.emptySet();
        }
    }


}