#!/bin/bash

java -cp "LIBS/*:CLASSES" TESTS.TestApp
