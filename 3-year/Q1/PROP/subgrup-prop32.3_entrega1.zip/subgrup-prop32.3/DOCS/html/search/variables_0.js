var searchData=
[
  ['admin_499',['admin',['../classFONTS_1_1Enquesta.html#ae39a7ad9557fd0358d945b8eaf00af20',1,'FONTS::Enquesta']]],
  ['adminstub_500',['adminStub',['../classEXE_1_1driversUsuari_1_1driverUsuari.html#ad0ceeedf8b7b6236a7a7a15c81fede4e',1,'EXE::driversUsuari::driverUsuari']]],
  ['analisicluster_501',['analisiCluster',['../classFONTS_1_1Enquesta.html#a77e42d45366b6a4c91f0fcfb80c69e87',1,'FONTS::Enquesta']]],
  ['assignacions_502',['assignacions',['../classFONTS_1_1AnalisiCluster.html#a206117c093de27e11d4075633a397a24',1,'FONTS::AnalisiCluster']]]
];
