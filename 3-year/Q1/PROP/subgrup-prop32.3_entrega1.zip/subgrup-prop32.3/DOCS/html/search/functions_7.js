var searchData=
[
  ['jaccarddistance_413',['jaccardDistance',['../classFONTS_1_1RespostaMultichoice.html#a09bc4a4726ffda97e9b6a9e06455a69b',1,'FONTS::RespostaMultichoice']]]
];
