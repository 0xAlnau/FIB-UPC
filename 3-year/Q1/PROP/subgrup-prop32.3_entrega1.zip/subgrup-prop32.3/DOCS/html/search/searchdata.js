var indexSectionsWithContent =
{
  0: "abcdefgijklmnoprstuv",
  1: "acdeimprtu",
  2: "ef",
  3: "acdeimprtu",
  4: "abcdegijlmnprstuv",
  5: "acdefiklmnoprstuv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "Tot",
  1: "Classes",
  2: "Namespaces",
  3: "Fitxers",
  4: "Funcions",
  5: "Variables"
};

