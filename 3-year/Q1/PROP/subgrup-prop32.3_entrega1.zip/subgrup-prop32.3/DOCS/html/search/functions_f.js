var searchData=
[
  ['updatecentroids_493',['updateCentroids',['../classFONTS_1_1AnalisiCluster.html#acd0523f3ac7ca2c6378e4a86bc0c81b8',1,'FONTS::AnalisiCluster']]],
  ['usuari_494',['Usuari',['../classFONTS_1_1Usuari.html#a5a1f290425ce0c4a94a3d19d2cb58850',1,'FONTS.Usuari.Usuari()'],['../classFONTS_1_1Usuari.html#a1c9a5409c99ed75625e3a91398b67153',1,'FONTS.Usuari.Usuari(String name, String password)']]]
];
