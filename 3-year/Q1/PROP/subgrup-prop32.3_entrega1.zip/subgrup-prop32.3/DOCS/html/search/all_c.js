var searchData=
[
  ['name_151',['name',['../classFONTS_1_1Usuari.html#a77d71c6e801270882bbb5251259cce5d',1,'FONTS::Usuari']]],
  ['noexisteixenquesta_152',['noExisteixEnquesta',['../classFONTS_1_1CtrlDominio.html#a2e3693efdd7959a7a1f1f6a1b99c2a7b',1,'FONTS::CtrlDominio']]],
  ['nom_5farxiu_153',['nom_arxiu',['../classFONTS_1_1ExcepcioGenerarArxiu.html#aa9d51ad19cbb3a6e8dd9f0483026f576',1,'FONTS.ExcepcioGenerarArxiu.nom_arxiu()'],['../classFONTS_1_1ExcepcioObrirArxiu.html#a7e79c227c06a754ba40cf259b72eb632',1,'FONTS.ExcepcioObrirArxiu.nom_arxiu()']]],
  ['nombreenuso_154',['nombreEnUso',['../classFONTS_1_1CtrlDominio.html#a7bf95414c00697e0ccbaf501b674a28d',1,'FONTS::CtrlDominio']]],
  ['npreg_155',['nPreg',['../classFONTS_1_1AnalisiCluster.html#a434b7b8b7bdcee3aa8fb01d53c7f6a49',1,'FONTS::AnalisiCluster']]],
  ['nresp_156',['nResp',['../classFONTS_1_1AnalisiCluster.html#abe81bea301a9f9b31645586017d1fe78',1,'FONTS::AnalisiCluster']]],
  ['nulllist_157',['nullList',['../classFONTS_1_1AnalisiCluster.html#ace65eb74008940551321f21563563531',1,'FONTS.AnalisiCluster.nullList()'],['../classFONTS_1_1Cluster.html#ad2d5cadfaec09c2c6794ca127fea5aab',1,'FONTS.Cluster.nullList()']]],
  ['nummaxcaracters_158',['numMaxCaracters',['../classFONTS_1_1PreguntaLliure.html#a69da4df98c46c449e59841bef89ae869',1,'FONTS::PreguntaLliure']]]
];
