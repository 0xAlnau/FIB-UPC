var searchData=
[
  ['sc_543',['sc',['../classFONTS_1_1CtrlDominio.html#a2bfc05142ded0618377c054f95c345fd',1,'FONTS.CtrlDominio.sc()'],['../classFONTS_1_1CtrlPresentacion.html#a205d8b418084dadcef46d1ab7ba8a41c',1,'FONTS.CtrlPresentacion.sc()']]],
  ['segidfila_544',['segIdFila',['../classFONTS_1_1Enquesta.html#ab779c2623bdb6eafed11e2ca36258640',1,'FONTS::Enquesta']]],
  ['segidpreg_545',['segIdPreg',['../classFONTS_1_1Enquesta.html#a65233519f191690493b4bd3922449baa',1,'FONTS::Enquesta']]],
  ['segidusu_546',['segIdUsu',['../classFONTS_1_1Enquesta.html#a40b7e3bf1669b227129cc1fdc1521ad1',1,'FONTS::Enquesta']]]
];
