var searchData=
[
  ['veurerespostes_495',['veureRespostes',['../classFONTS_1_1Enquesta.html#adf75b3fc226b0ab40c770147c211e33a',1,'FONTS::Enquesta']]],
  ['veurerespostes_5fbuit_496',['veureRespostes_Buit',['../classEXE_1_1driversEnquesta_1_1driverTotesFuncionsEnquesta.html#a792f195253d2be2d354ae570cb430971',1,'EXE::driversEnquesta::driverTotesFuncionsEnquesta']]],
  ['veureresultats_497',['veureResultats',['../classFONTS_1_1CtrlPresentacion.html#ac7ab990f7846d0ea4bbce7bb2feeedb5',1,'FONTS::CtrlPresentacion']]],
  ['veureresultatsenquesta_498',['veureResultatsEnquesta',['../classFONTS_1_1CtrlDominio.html#a6a8a48b1e32e29b35abd510995af57d5',1,'FONTS::CtrlDominio']]]
];
