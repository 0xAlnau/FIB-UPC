var searchData=
[
  ['limitopcions_519',['limitOpcions',['../classFONTS_1_1PreguntaMultichoice.html#a567302851473cded7356d3ff070c0f4d',1,'FONTS::PreguntaMultichoice']]],
  ['lliure_520',['LLIURE',['../enumFONTS_1_1TipusPregunta.html#a50d7888dead1c8245023290ebc714902',1,'FONTS::TipusPregunta']]]
];
