var searchData=
[
  ['tipuspregunta_297',['TipusPregunta',['../enumFONTS_1_1TipusPregunta.html',1,'FONTS']]]
];
