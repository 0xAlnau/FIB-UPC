var searchData=
[
  ['valor_555',['valor',['../classFONTS_1_1RespostaNum.html#ad0f5cf23f7d1695a8699b1e501620d56',1,'FONTS::RespostaNum']]],
  ['valork_556',['valorK',['../classFONTS_1_1Enquesta.html#a6c5a4304816137bc72c75b56426aa7ed',1,'FONTS::Enquesta']]]
];
