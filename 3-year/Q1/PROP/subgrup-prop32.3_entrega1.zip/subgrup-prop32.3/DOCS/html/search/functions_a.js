var searchData=
[
  ['noexisteixenquesta_420',['noExisteixEnquesta',['../classFONTS_1_1CtrlDominio.html#a2e3693efdd7959a7a1f1f6a1b99c2a7b',1,'FONTS::CtrlDominio']]],
  ['nombreenuso_421',['nombreEnUso',['../classFONTS_1_1CtrlDominio.html#a7bf95414c00697e0ccbaf501b674a28d',1,'FONTS::CtrlDominio']]]
];
