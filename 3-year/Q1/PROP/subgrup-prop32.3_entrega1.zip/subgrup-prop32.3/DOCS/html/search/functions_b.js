var searchData=
[
  ['pregunta_422',['Pregunta',['../classFONTS_1_1Pregunta.html#a673fe0d43ccfdaafac92a9414aada5cf',1,'FONTS::Pregunta']]],
  ['preguntalliure_423',['PreguntaLliure',['../classFONTS_1_1PreguntaLliure.html#a585fe31a922c4e19b7dda44ceb7fd7bd',1,'FONTS::PreguntaLliure']]],
  ['preguntamultichoice_424',['PreguntaMultichoice',['../classFONTS_1_1PreguntaMultichoice.html#ab73fba99ddff34c391aa3597fcc9d68e',1,'FONTS::PreguntaMultichoice']]]
];
