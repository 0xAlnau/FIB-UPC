var searchData=
[
  ['sc_192',['sc',['../classFONTS_1_1CtrlDominio.html#a2bfc05142ded0618377c054f95c345fd',1,'FONTS.CtrlDominio.sc()'],['../classFONTS_1_1CtrlPresentacion.html#a205d8b418084dadcef46d1ab7ba8a41c',1,'FONTS.CtrlPresentacion.sc()']]],
  ['segidfila_193',['segIdFila',['../classFONTS_1_1Enquesta.html#ab779c2623bdb6eafed11e2ca36258640',1,'FONTS::Enquesta']]],
  ['segidpreg_194',['segIdPreg',['../classFONTS_1_1Enquesta.html#a65233519f191690493b4bd3922449baa',1,'FONTS::Enquesta']]],
  ['segidusu_195',['segIdUsu',['../classFONTS_1_1Enquesta.html#a40b7e3bf1669b227129cc1fdc1521ad1',1,'FONTS::Enquesta']]],
  ['setenquestes_196',['setEnquestes',['../classFONTS_1_1Usuari.html#a0c8368ded595d60dc076e65f9c6b7477',1,'FONTS::Usuari']]],
  ['setname_197',['setName',['../classFONTS_1_1Usuari.html#ace712088c6354fc3f7c12b0373945242',1,'FONTS::Usuari']]],
  ['setpassword_198',['setPassword',['../classFONTS_1_1Usuari.html#ae1e4d8de78925df7b73ef6d29454603b',1,'FONTS::Usuari']]],
  ['setsc_199',['setSc',['../classFONTS_1_1CtrlDominio.html#aeba52919f84a153e638771383fe647cb',1,'FONTS::CtrlDominio']]],
  ['settext_200',['setText',['../classFONTS_1_1RespostaText.html#af3c2c715a1e965cc9c7b0b33b6d72a89',1,'FONTS::RespostaText']]],
  ['setup_201',['setUp',['../classEXE_1_1driversUsuari_1_1driverUsuari.html#a45c51db81c483d80b4d17b2c581710b2',1,'EXE::driversUsuari::driverUsuari']]],
  ['setvalor_202',['setValor',['../classFONTS_1_1RespostaNum.html#ae9792a22f91e4f06a2e03ed45eac9a74',1,'FONTS::RespostaNum']]],
  ['sortir_203',['sortir',['../classFONTS_1_1CtrlPresentacion.html#a9acef40477351aa9159070a6b266496f',1,'FONTS::CtrlPresentacion']]]
];
