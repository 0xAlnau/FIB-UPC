var searchData=
[
  ['fila0_516',['fila0',['../classFONTS_1_1Enquesta.html#ad9d0d9a449aba9d1ee67218e11827469',1,'FONTS::Enquesta']]]
];
