var searchData=
[
  ['eliminarenquesta_365',['eliminarEnquesta',['../classFONTS_1_1CtrlPresentacion.html#ada2b8789f14746e4ff03cd730f9b8378',1,'FONTS.CtrlPresentacion.eliminarEnquesta()'],['../classFONTS_1_1Usuari.html#afa045c4580d525201613bfb6023840dd',1,'FONTS.Usuari.eliminarEnquesta()'],['../classFONTS_1_1CtrlDominio.html#a0897347ff8151d389ee87cb37b41c357',1,'FONTS.CtrlDominio.eliminarEnquesta()']]],
  ['eliminarpregunta_366',['eliminarPregunta',['../classFONTS_1_1Enquesta.html#a4eca0b2b2130a2219a4db0d6d14fc71a',1,'FONTS::Enquesta']]],
  ['eliminarpregunta_5fexistenta_367',['eliminarPregunta_Existenta',['../classEXE_1_1driversEnquesta_1_1driverTotesFuncionsEnquesta.html#a5947090b841a5873ad459115c287278d',1,'EXE::driversEnquesta::driverTotesFuncionsEnquesta']]],
  ['eliminarpregunta_5finexistent_368',['eliminarPregunta_Inexistent',['../classEXE_1_1driversEnquesta_1_1driverTotesFuncionsEnquesta.html#a87467306509c33ac17d4b2912d5cb175',1,'EXE::driversEnquesta::driverTotesFuncionsEnquesta']]],
  ['eliminarpreguntes_369',['eliminarPreguntes',['../classFONTS_1_1CtrlDominio.html#a32ebabffaed596ebc1098ca109a4e8e8',1,'FONTS.CtrlDominio.eliminarPreguntes()'],['../classFONTS_1_1CtrlPresentacion.html#aa9638252e62c1fa030d4754d5c3a4b48',1,'FONTS.CtrlPresentacion.eliminarPreguntes()']]],
  ['enquesta_370',['Enquesta',['../classFONTS_1_1Enquesta.html#a5f9e9d9a4a6099c6fe36c4adb0ba73ec',1,'FONTS.Enquesta.Enquesta(String titol, Usuari admin, Integer valorK)'],['../classFONTS_1_1Enquesta.html#a92286899a9e39ca81f404fe593b07385',1,'FONTS.Enquesta.Enquesta(String titol, String nomFitxer, HashMap&lt; String, Usuari &gt; usuarios, Scanner scMain)']]],
  ['esnumerica_371',['esNumerica',['../classFONTS_1_1PreguntaLliure.html#a2608b0136bd12ecfe0edf05c4902f53f',1,'FONTS::PreguntaLliure']]],
  ['excepcioenquestesusuari_372',['ExcepcioEnquestesUsuari',['../classFONTS_1_1ExcepcioEnquestesUsuari.html#ae0666407908e891aea306a5ed239d4f7',1,'FONTS::ExcepcioEnquestesUsuari']]],
  ['excepciogenerararxiu_373',['ExcepcioGenerarArxiu',['../classFONTS_1_1ExcepcioGenerarArxiu.html#a9b5f95d27c3211f14fbb04ffbabe81b6',1,'FONTS::ExcepcioGenerarArxiu']]],
  ['excepcioobrirarxiu_374',['ExcepcioObrirArxiu',['../classFONTS_1_1ExcepcioObrirArxiu.html#a68aa29f947c8e11df824ac117ed0ca88',1,'FONTS::ExcepcioObrirArxiu']]],
  ['existeenquesta_375',['existeEnquesta',['../classFONTS_1_1CtrlDominio.html#aca022fb294aef37884eba4bbb8fe970d',1,'FONTS.CtrlDominio.existeEnquesta()'],['../classFONTS_1_1Usuari.html#adf5175716077cf89ee9e741bcd3fa748',1,'FONTS.Usuari.existeEnquesta()']]],
  ['existeenquestausuari_376',['existeEnquestaUsuari',['../classFONTS_1_1CtrlDominio.html#a92e4381d38854a9f3b1ccdbbe876139b',1,'FONTS::CtrlDominio']]],
  ['exportarenquesta_377',['exportarEnquesta',['../classFONTS_1_1CtrlDominio.html#adf6a31798093569c99edbaad8a03fc9a',1,'FONTS.CtrlDominio.exportarEnquesta()'],['../classFONTS_1_1CtrlPresentacion.html#ae0ad87f4ba6e7d1ef2f83b76ab828293',1,'FONTS.CtrlPresentacion.exportarEnquesta()'],['../classFONTS_1_1Enquesta.html#ae2866af67a14bd79f025df5e0939c7e1',1,'FONTS.Enquesta.exportarEnquesta()']]],
  ['exportarenquesta_5fambrespostes_378',['exportarEnquesta_AmbRespostes',['../classEXE_1_1driversEnquesta_1_1driverTotesFuncionsEnquesta.html#aa81554ad0edd44b03514f79d07d67290',1,'EXE::driversEnquesta::driverTotesFuncionsEnquesta']]],
  ['exportarenquesta_5fsenserespostes_379',['exportarEnquesta_SenseRespostes',['../classEXE_1_1driversEnquesta_1_1driverTotesFuncionsEnquesta.html#af6eac99af932bf1abe0bef2fbcad1147',1,'EXE::driversEnquesta::driverTotesFuncionsEnquesta']]],
  ['exportarenquestes_380',['exportarEnquestes',['../classFONTS_1_1CtrlDominio.html#aac9bba31510b13f0356af3cd4c6d8695',1,'FONTS::CtrlDominio']]],
  ['exportarusuaris_381',['exportarUsuaris',['../classFONTS_1_1CtrlDominio.html#a635ceb9156b459e81ce885552516f21b',1,'FONTS::CtrlDominio']]]
];
