var searchData=
[
  ['name_528',['name',['../classFONTS_1_1Usuari.html#a77d71c6e801270882bbb5251259cce5d',1,'FONTS::Usuari']]],
  ['nom_5farxiu_529',['nom_arxiu',['../classFONTS_1_1ExcepcioGenerarArxiu.html#aa9d51ad19cbb3a6e8dd9f0483026f576',1,'FONTS.ExcepcioGenerarArxiu.nom_arxiu()'],['../classFONTS_1_1ExcepcioObrirArxiu.html#a7e79c227c06a754ba40cf259b72eb632',1,'FONTS.ExcepcioObrirArxiu.nom_arxiu()']]],
  ['npreg_530',['nPreg',['../classFONTS_1_1AnalisiCluster.html#a434b7b8b7bdcee3aa8fb01d53c7f6a49',1,'FONTS::AnalisiCluster']]],
  ['nresp_531',['nResp',['../classFONTS_1_1AnalisiCluster.html#abe81bea301a9f9b31645586017d1fe78',1,'FONTS::AnalisiCluster']]],
  ['nulllist_532',['nullList',['../classFONTS_1_1AnalisiCluster.html#ace65eb74008940551321f21563563531',1,'FONTS.AnalisiCluster.nullList()'],['../classFONTS_1_1Cluster.html#ad2d5cadfaec09c2c6794ca127fea5aab',1,'FONTS.Cluster.nullList()']]],
  ['nummaxcaracters_533',['numMaxCaracters',['../classFONTS_1_1PreguntaLliure.html#a69da4df98c46c449e59841bef89ae869',1,'FONTS::PreguntaLliure']]]
];
