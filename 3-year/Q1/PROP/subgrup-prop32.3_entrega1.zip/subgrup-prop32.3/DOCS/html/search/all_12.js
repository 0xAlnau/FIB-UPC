var searchData=
[
  ['u_257',['u',['../classEXE_1_1driversUsuari_1_1driverUsuari.html#af55f4b55ec3c797bb7522854aa474cdb',1,'EXE::driversUsuari::driverUsuari']]],
  ['updatecentroids_258',['updateCentroids',['../classFONTS_1_1AnalisiCluster.html#acd0523f3ac7ca2c6378e4a86bc0c81b8',1,'FONTS::AnalisiCluster']]],
  ['usari2taula_259',['usari2taula',['../classFONTS_1_1Enquesta.html#aa0da1150089b5704ac07d5b2a7f61da1',1,'FONTS::Enquesta']]],
  ['usuari_260',['Usuari',['../classFONTS_1_1Usuari.html',1,'FONTS.Usuari'],['../classFONTS_1_1Usuari.html#a5a1f290425ce0c4a94a3d19d2cb58850',1,'FONTS.Usuari.Usuari()'],['../classFONTS_1_1Usuari.html#a1c9a5409c99ed75625e3a91398b67153',1,'FONTS.Usuari.Usuari(String name, String password)']]],
  ['usuari_2ejava_261',['Usuari.java',['../Usuari_8java.html',1,'']]],
  ['usuari2num_262',['usuari2num',['../classFONTS_1_1Enquesta.html#a366afaeba4d05ef3035829984991daac',1,'FONTS::Enquesta']]],
  ['usuarios_263',['usuarios',['../classFONTS_1_1CtrlDominio.html#aef53ede8d4e80c7fe2d20bc59f6bdcd5',1,'FONTS::CtrlDominio']]]
];
