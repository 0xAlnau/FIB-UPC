var searchData=
[
  ['usuari_2ejava_333',['Usuari.java',['../Usuari_8java.html',1,'']]]
];
