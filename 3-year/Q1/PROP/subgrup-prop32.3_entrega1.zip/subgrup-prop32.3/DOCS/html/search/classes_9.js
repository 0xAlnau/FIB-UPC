var searchData=
[
  ['usuari_298',['Usuari',['../classFONTS_1_1Usuari.html',1,'FONTS']]]
];
