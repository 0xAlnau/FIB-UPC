var searchData=
[
  ['text_547',['text',['../classFONTS_1_1Pregunta.html#a773e700eb7f25275046763a819a75455',1,'FONTS.Pregunta.text()'],['../classFONTS_1_1RespostaText.html#a19dc7a32a610762deabaa5b8aef4b1c6',1,'FONTS.RespostaText.text()']]],
  ['tipus_548',['tipus',['../classFONTS_1_1Pregunta.html#aa1f4f6e8eaf9f1be6a87ed08f8662aa7',1,'FONTS::Pregunta']]],
  ['titol_549',['titol',['../classFONTS_1_1Enquesta.html#a2679f652d2501e7584cb8cd71e8adb3a',1,'FONTS::Enquesta']]],
  ['titol2enquesta_550',['titol2Enquesta',['../classFONTS_1_1CtrlDominio.html#abf738db1db533c70d522fef34708eeb0',1,'FONTS::CtrlDominio']]]
];
