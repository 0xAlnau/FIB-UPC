var searchData=
[
  ['tipuspregunta_2ejava_332',['TipusPregunta.java',['../TipusPregunta_8java.html',1,'']]]
];
