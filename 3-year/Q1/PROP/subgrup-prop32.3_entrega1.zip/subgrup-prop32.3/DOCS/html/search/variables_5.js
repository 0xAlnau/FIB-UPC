var searchData=
[
  ['idusuari_517',['idUsuari',['../classFONTS_1_1RespostaInd.html#ad7b7dc775e5a9629ef72f7a151fc4473',1,'FONTS::RespostaInd']]]
];
