var searchData=
[
  ['k_518',['k',['../classFONTS_1_1AnalisiCluster.html#a82135ba14b22491746067b74d31592e2',1,'FONTS.AnalisiCluster.k()'],['../classFONTS_1_1Cluster.html#ac9bd488fd14d632effa6effbabd29efd',1,'FONTS.Cluster.k()']]]
];
