var searchData=
[
  ['max_5fdistancia_521',['MAX_DISTANCIA',['../classFONTS_1_1RespostaInd.html#a52f22a04b6e42edb202be92beaf3c5d6',1,'FONTS::RespostaInd']]],
  ['max_5fpreguntes_522',['MAX_PREGUNTES',['../classFONTS_1_1Enquesta.html#ad733a32f0674a0fc436c355e78222630',1,'FONTS::Enquesta']]],
  ['max_5fusuaris_523',['MAX_USUARIS',['../classFONTS_1_1Enquesta.html#ab924572320c870ec0b3716320032a831',1,'FONTS::Enquesta']]],
  ['maxallargadapreg_524',['maxAllargadaPreg',['../classFONTS_1_1Enquesta.html#a8209bfc974b03be1223b62ff4d3b77dc',1,'FONTS::Enquesta']]],
  ['min_5fdistancia_525',['MIN_DISTANCIA',['../classFONTS_1_1RespostaInd.html#afb283690bf2f5956dd5cfe5e6c4fbfc5',1,'FONTS::RespostaInd']]],
  ['min_5frespostes_526',['MIN_RESPOSTES',['../classFONTS_1_1Cluster.html#aad550f1555954d1eca5fa8ad126ee936',1,'FONTS::Cluster']]],
  ['multichoice_527',['MULTICHOICE',['../enumFONTS_1_1TipusPregunta.html#a61e51ce30ea3738e8dc41d27d21f27c0',1,'FONTS::TipusPregunta']]]
];
