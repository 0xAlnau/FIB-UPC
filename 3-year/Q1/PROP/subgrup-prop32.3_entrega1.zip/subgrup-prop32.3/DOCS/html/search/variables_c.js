var searchData=
[
  ['respostatext_540',['respostaText',['../classFONTS_1_1RespostaInd.html#acb8b652aa7997369e03b77b6a13838cf',1,'FONTS::RespostaInd']]],
  ['respostes_541',['respostes',['../classFONTS_1_1AnalisiCluster.html#ab361d6692ffbe7e1831c8451c90e2437',1,'FONTS::AnalisiCluster']]],
  ['respostescompletes_542',['respostesCompletes',['../classFONTS_1_1Enquesta.html#ae5b717c0ed0f02ae196f9763cd79ed4a',1,'FONTS::Enquesta']]]
];
