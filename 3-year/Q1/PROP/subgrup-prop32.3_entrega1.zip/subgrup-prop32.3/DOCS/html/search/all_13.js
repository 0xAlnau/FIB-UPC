var searchData=
[
  ['valor_264',['valor',['../classFONTS_1_1RespostaNum.html#ad0f5cf23f7d1695a8699b1e501620d56',1,'FONTS::RespostaNum']]],
  ['valork_265',['valorK',['../classFONTS_1_1Enquesta.html#a6c5a4304816137bc72c75b56426aa7ed',1,'FONTS::Enquesta']]],
  ['veurerespostes_266',['veureRespostes',['../classFONTS_1_1Enquesta.html#adf75b3fc226b0ab40c770147c211e33a',1,'FONTS::Enquesta']]],
  ['veurerespostes_5fbuit_267',['veureRespostes_Buit',['../classEXE_1_1driversEnquesta_1_1driverTotesFuncionsEnquesta.html#a792f195253d2be2d354ae570cb430971',1,'EXE::driversEnquesta::driverTotesFuncionsEnquesta']]],
  ['veureresultats_268',['veureResultats',['../classFONTS_1_1CtrlPresentacion.html#ac7ab990f7846d0ea4bbce7bb2feeedb5',1,'FONTS::CtrlPresentacion']]],
  ['veureresultatsenquesta_269',['veureResultatsEnquesta',['../classFONTS_1_1CtrlDominio.html#a6a8a48b1e32e29b35abd510995af57d5',1,'FONTS::CtrlDominio']]]
];
