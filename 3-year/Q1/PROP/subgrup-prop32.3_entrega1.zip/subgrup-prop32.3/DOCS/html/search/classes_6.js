var searchData=
[
  ['pregunta_290',['Pregunta',['../classFONTS_1_1Pregunta.html',1,'FONTS']]],
  ['preguntalliure_291',['PreguntaLliure',['../classFONTS_1_1PreguntaLliure.html',1,'FONTS']]],
  ['preguntamultichoice_292',['PreguntaMultichoice',['../classFONTS_1_1PreguntaMultichoice.html',1,'FONTS']]]
];
