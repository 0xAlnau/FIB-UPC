var searchData=
[
  ['opcions_534',['opcions',['../classFONTS_1_1PreguntaMultichoice.html#a51012ea1cb8a9b7f600744ffcd161b02',1,'FONTS::PreguntaMultichoice']]],
  ['opcionstriaes_535',['opcionsTriaes',['../classFONTS_1_1RespostaMultichoice.html#ac72be37f793dd0b6451043b203f0da43',1,'FONTS::RespostaMultichoice']]]
];
