var searchData=
[
  ['levenshteindistance_134',['levenshteinDistance',['../classFONTS_1_1RespostaText.html#a8e26c91927be18ad8db2be6f15227f61',1,'FONTS::RespostaText']]],
  ['limitopcions_135',['limitOpcions',['../classFONTS_1_1PreguntaMultichoice.html#a567302851473cded7356d3ff070c0f4d',1,'FONTS::PreguntaMultichoice']]],
  ['listarenquestes_136',['listarEnquestes',['../classFONTS_1_1CtrlDominio.html#ad1dd9cec7dfba0ba6ae39a9b2fe0b15c',1,'FONTS.CtrlDominio.listarEnquestes()'],['../classFONTS_1_1Usuari.html#a4cc37ad0591dcaf9fb867ff7fbb3415c',1,'FONTS.Usuari.listarEnquestes()']]],
  ['listarenquestesusuari_137',['listarEnquestesUsuari',['../classFONTS_1_1CtrlDominio.html#a150a198f9baba455260bcf65b7adf53c',1,'FONTS::CtrlDominio']]],
  ['lliure_138',['LLIURE',['../enumFONTS_1_1TipusPregunta.html#a50d7888dead1c8245023290ebc714902',1,'FONTS::TipusPregunta']]]
];
