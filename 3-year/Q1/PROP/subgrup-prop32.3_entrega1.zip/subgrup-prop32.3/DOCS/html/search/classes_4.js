var searchData=
[
  ['invalidclusterexception_286',['InvalidClusterException',['../classFONTS_1_1InvalidClusterException.html',1,'FONTS']]],
  ['invalidpreguntaexception_287',['InvalidPreguntaException',['../classFONTS_1_1InvalidPreguntaException.html',1,'FONTS']]],
  ['invalidrespostaexception_288',['InvalidRespostaException',['../classFONTS_1_1InvalidRespostaException.html',1,'FONTS']]]
];
