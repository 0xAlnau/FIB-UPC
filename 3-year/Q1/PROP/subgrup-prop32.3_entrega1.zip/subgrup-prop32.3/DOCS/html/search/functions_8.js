var searchData=
[
  ['levenshteindistance_414',['levenshteinDistance',['../classFONTS_1_1RespostaText.html#a8e26c91927be18ad8db2be6f15227f61',1,'FONTS::RespostaText']]],
  ['listarenquestes_415',['listarEnquestes',['../classFONTS_1_1CtrlDominio.html#ad1dd9cec7dfba0ba6ae39a9b2fe0b15c',1,'FONTS.CtrlDominio.listarEnquestes()'],['../classFONTS_1_1Usuari.html#a4cc37ad0591dcaf9fb867ff7fbb3415c',1,'FONTS.Usuari.listarEnquestes()']]],
  ['listarenquestesusuari_416',['listarEnquestesUsuari',['../classFONTS_1_1CtrlDominio.html#a150a198f9baba455260bcf65b7adf53c',1,'FONTS::CtrlDominio']]]
];
