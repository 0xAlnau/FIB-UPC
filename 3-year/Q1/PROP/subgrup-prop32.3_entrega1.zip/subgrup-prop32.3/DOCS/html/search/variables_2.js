var searchData=
[
  ['distancia_5finfinita_509',['DISTANCIA_INFINITA',['../classFONTS_1_1RespostaInd.html#a4edab8c263abe20a2ac7d70b33067814',1,'FONTS::RespostaInd']]],
  ['distmaxs_510',['distMaxs',['../classFONTS_1_1AnalisiCluster.html#a32e274f8d46c10f861ffa42ad876c1d8',1,'FONTS::AnalisiCluster']]]
];
