/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var menudata={children:[
{text:"Pàgina principal",url:"index.html"},
{text:"Paquets",url:"namespaces.html",children:[
{text:"Paquets",url:"namespaces.html"}]},
{text:"Classes",url:"annotated.html",children:[
{text:"Llista de Classes",url:"annotated.html"},
{text:"Índex de Classes",url:"classes.html"},
{text:"Jerarquia de Classes",url:"inherits.html"},
{text:"Membres de Classes",url:"functions.html",children:[
{text:"Tot",url:"functions.html",children:[
{text:"a",url:"functions.html#index_a"},
{text:"b",url:"functions_b.html#index_b"},
{text:"c",url:"functions_c.html#index_c"},
{text:"d",url:"functions_d.html#index_d"},
{text:"e",url:"functions_e.html#index_e"},
{text:"f",url:"functions_f.html#index_f"},
{text:"g",url:"functions_g.html#index_g"},
{text:"i",url:"functions_i.html#index_i"},
{text:"j",url:"functions_j.html#index_j"},
{text:"k",url:"functions_k.html#index_k"},
{text:"l",url:"functions_l.html#index_l"},
{text:"m",url:"functions_m.html#index_m"},
{text:"n",url:"functions_n.html#index_n"},
{text:"o",url:"functions_o.html#index_o"},
{text:"p",url:"functions_p.html#index_p"},
{text:"r",url:"functions_r.html#index_r"},
{text:"s",url:"functions_s.html#index_s"},
{text:"t",url:"functions_t.html#index_t"},
{text:"u",url:"functions_u.html#index_u"},
{text:"v",url:"functions_v.html#index_v"}]},
{text:"Funcions",url:"functions_func.html",children:[
{text:"a",url:"functions_func.html#index_a"},
{text:"b",url:"functions_func_b.html#index_b"},
{text:"c",url:"functions_func_c.html#index_c"},
{text:"d",url:"functions_func_d.html#index_d"},
{text:"e",url:"functions_func_e.html#index_e"},
{text:"g",url:"functions_func_g.html#index_g"},
{text:"i",url:"functions_func_i.html#index_i"},
{text:"j",url:"functions_func_j.html#index_j"},
{text:"l",url:"functions_func_l.html#index_l"},
{text:"m",url:"functions_func_m.html#index_m"},
{text:"n",url:"functions_func_n.html#index_n"},
{text:"p",url:"functions_func_p.html#index_p"},
{text:"r",url:"functions_func_r.html#index_r"},
{text:"s",url:"functions_func_s.html#index_s"},
{text:"t",url:"functions_func_t.html#index_t"},
{text:"u",url:"functions_func_u.html#index_u"},
{text:"v",url:"functions_func_v.html#index_v"}]},
{text:"Variables",url:"functions_vars.html",children:[
{text:"a",url:"functions_vars.html#index_a"},
{text:"c",url:"functions_vars.html#index_c"},
{text:"d",url:"functions_vars.html#index_d"},
{text:"e",url:"functions_vars.html#index_e"},
{text:"f",url:"functions_vars.html#index_f"},
{text:"i",url:"functions_vars.html#index_i"},
{text:"k",url:"functions_vars.html#index_k"},
{text:"l",url:"functions_vars.html#index_l"},
{text:"m",url:"functions_vars.html#index_m"},
{text:"n",url:"functions_vars.html#index_n"},
{text:"o",url:"functions_vars.html#index_o"},
{text:"p",url:"functions_vars.html#index_p"},
{text:"r",url:"functions_vars.html#index_r"},
{text:"s",url:"functions_vars.html#index_s"},
{text:"t",url:"functions_vars.html#index_t"},
{text:"u",url:"functions_vars.html#index_u"},
{text:"v",url:"functions_vars.html#index_v"}]}]}]},
{text:"Fitxers",url:"files.html",children:[
{text:"Llista dels Fitxers",url:"files.html"}]}]}
