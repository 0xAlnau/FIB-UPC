#!/bin/bash

java -cp "LIBS/*:CLASSES" org.junit.runner.JUnitCore EXE.driverPregunta.driverPreguntaMultichoice

java -cp "LIBS/*:CLASSES" org.junit.runner.JUnitCore EXE.driverPregunta.driverPreguntaLliure
