#!/bin/bash
java -cp CLASSES FONTS/Main
