# PROP Grup 32.3
Projecte de Programació, Grup 32.3, subgrup 32.3.  
Professor: Ignasi Gómez (ignasi.gomez@upc.edu).

## Membres del grup
· Alegre Conchello, Gabriel (gabriel.alegre@estudiantat.upc.edu)  
· Cullell Martínez, Arnau (arnau.cullell@estudiantat.upc.edu)  
· Domínguez Buira, Àngel (angel.dominguez@estudiantat.upc.edu)  
· Lluzar Frías, Santiago (santiago.lluzar@estudiantat.upc.edu)

---

## Elements del directori

### **DOCS**
Conté tota la documentació del projecte:  
- Diagrama de casos d’ús i la descripció de cadascun  
- Diagrama estàtic complet del model conceptual en versió de disseny  
- Descripció dels atributs i mètodes de les classes  
- Relació de les classes implementades per cada membre  
- Descripció d’estructures de dades i algorismes utilitzats

### **EXE**
Drivers de totes les classes que permeten provar les funcionalitats implementades.  
Inclou subdirectoris per:
- driverAnalisiCluster
- driverPregunta  
- driverResposta
- driverUsuari
- driversEnquesta

Cada driver"x" comprova el funcionament correcte de les funcions de aquesta classe "x".  

### **FONTS**
Conté tot el codi de les classes de domini associades a les funcionalitats desenvolupades fins ara.  
Inclou també una carpeta "CtrlPersistència" on es guarden i escriuen les dades del codi.

### **LIBS**
Llibreries externes necessàries, especialment per a l’ús de JUnit i Mockito.

### **INPUT**
Conté tots els arxius d'entrada del TestApp.java, un per cada funcionalitat, menys la funcionalitat cluster que en té 5. 

### **TESTS**
En aquesta carpeta es troba TestApp.java que permet provar les funcionalitats principals implementades en el codi, mitjançant drivers interactius. 

### **Scripts**
El projecte inclou scripts per facilitar compilació i proves:
- `compilar_domini.sh`: compila només les classes del domini.
- `compilar_drivers.sh`: compila les classes dels drivers.
- `compilar_interactiu.sh`: compila el driver interactiu.
- `compilar_tot.sh`: compilen tot el programa en linux.
- `run_analisiCluster_tests.sh`: executa el driver unitari de AnalisiCluster.
- `run_enquesta_tests.sh`: executa el driver unitari d'Enquesta.
- `run_usuari_tests.sh`: executa el driver unitari d'Usuari.
- `run_preguntes_tests.sh`: executa els drivers unitaris de Pregunta i els dels seus fills.
- `run_respostes_tests.sh`: executa els drivers unitaris de Resposta i els dels seus fills.
- `run_driverInteractiu_tests.sh`: executa el driver interactiu.
- `run_all_tests.sh`:  executa tots els drivers.

---

## Provar el programa
1- Inicialment no caldria aquest pas, però, en alguns ordinadors abans de fer les altres passes cal posar a la terminal: "sed -i 's/\r$//' habilitar_scripts.sh" i després: "chmod +x habilitar_scripts.sh" per poder usar els altres scripts. 

2- Després s'ha de posar a la terminal: './compilar_tot.sh'

3- Seguidament cal escriure: './run_x_tests.sh' per executar tots el testd de la classe dessitjada.

