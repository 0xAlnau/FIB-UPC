package TESTS;

import FONTS.CtrlPresentacion;
import FONTS.CtrlDominio;
import java.io.*;
import java.util.*;
import FONTS.*;


public class TestApp {

    static private Scanner sc = new Scanner(System.in);
    static private final InputStream originalIn = System.in;

    // Helper per redirigir l'input
    private static void setInput(String fileName) throws FileNotFoundException {
        File inputFile = new File(fileName);
        FileInputStream fis = new FileInputStream(inputFile);
        System.setIn(fis);
    }


    public static void main(String[] args) throws Exception {

        String op = "-1";


        while (!op.equals("0")) {
            System.setIn(originalIn);
            sc = new Scanner(originalIn);

            System.out.println("\n--- MENÚ PRINCIPAL PROVES ---");
            System.out.println("Escogeix quin test vols provar:");
            System.out.println("0 - Sortir");
            System.out.println("1 - Registre");
            System.out.println("2 - Accedir");
            System.out.println("3 - Crear nova enquesta");
            System.out.println("4 - Contestar a una enquesta");
            System.out.println("5 - Veure resultats");
            System.out.println("6 - Eliminar pregunta");
            System.out.println("7 - Exportar enquesta");
            System.out.println("8 - Afegir pregunta");
            System.out.println("9 - Eliminar enquesta");
            System.out.print("Escull una opció (0-9): ");
            op = sc.nextLine();
            
            if (op.equals("1")) pruebaRegistro();
            else if (op.equals("2")) pruebaAcceso();
            else if (op.equals("3")) pruebaCrearEncuesta();
            else if (op.equals("4")) pruebaContestarEncuesta();
            else if (op.equals("5")) pruebaCluster(); 
            else if (op.equals("6")) pruebaEliminarPregunta();
            else if (op.equals("7")) pruebaExportarEnquesta();
            else if (op.equals("8")) pruebaAfegirPregunta();
            else if (op.equals("9")) pruebaEliminarEnquesta();
            else {
                if (!op.equals("0"))
                    System.err.println("Entrada incorrecta. Escull una de les opcions.");
            }
        }
    }

    // Helper per imprimir el resultat del test
    private static void printTestResult(String testName, boolean success) {
        if (success) {
            System.out.println(testName + ": OK");
        } else {
            System.out.println(testName + ": ERROR");
        }
    }

    static public void pruebaRegistro() {
        try {
            setInput("INPUT/test_input_registro.txt");
        } catch (FileNotFoundException e) {
            System.err.println("No s'ha trobat l'arxiu: " + e.getMessage());
            return;
        }
        CtrlPresentacion cp = new CtrlPresentacion();
        cp.registrarse(); // Input: "userReg", "pass", "0" (per sortir)
        
        CtrlDominio cd = cp.getCD();
        printTestResult("1 - Registre", cd.nombreEnUso("userReg"));
    }

    static public void pruebaAcceso() {
        try {
            setInput("INPUT/test_input_acceso.txt");
        } catch (FileNotFoundException e) {
            System.err.println("No s'ha trobat l'arxiu: " + e.getMessage());
            return;
        }
        CtrlPresentacion cp = new CtrlPresentacion();
        CtrlDominio cd = cp.getCD();
        cd.crearUsuari("userAcc", "12345"); // Setup

        cp.acceder(); // Input: "userAcc", "12345", "0" (per sortir)
        
        printTestResult("2 - Accés", cd.comprovarPassword("userAcc", "12345"));
    }

    static public void pruebaCrearEncuesta() {
        try {
            setInput("INPUT/test_input_crear_enquesta.txt");
        } catch (FileNotFoundException e) {
            System.err.println("No s'ha trobat l'arxiu: " + e.getMessage());
            return;
        }
        CtrlPresentacion cp = new CtrlPresentacion();
        CtrlDominio cd = cp.getCD();
        String usuario = "adminCrea";
        cd.crearUsuari(usuario, "12345");

        // Input: "enqCrea", "3", "ll", "P1", "n", "ext"
        cp.crearEnquesta(usuario); 

        printTestResult("3 - Crear Enquesta", cd.existeEnquesta("enqCrea") && cd.existeEnquestaUsuari(usuario, "enqCrea"));
    }

    static public void pruebaContestarEncuesta() {
        try {
            setInput("INPUT/test_input_contestar.txt");
        } catch (FileNotFoundException e) {
            System.err.println("No s'ha trobat l'arxiu: " + e.getMessage());
            return;
        }
        CtrlPresentacion cp = new CtrlPresentacion();
        CtrlDominio cd = cp.getCD();
        String admin = "adminCont";
        String respondent = "userCont";
        String titol = "enqContestar";
        
        // Setup
        cd.crearUsuari(admin, "123");
        cd.crearUsuari(respondent, "123");
        
        
        // Input: "3" (per K), "enqContestar", "Resposta 1", "s"
        cd.crearEnquestaBuida(titol, admin); // Llegeix K=3
        try {
            cd.crearPreguntaLliure(titol, "Pregunta 1", 20, false);
        } catch (InvalidPreguntaException e) {}

        int respostesAbans = cd.getNumRespostes(titol); // 0
        
        cp.contestar(respondent); // Llegeix titol, resposta, 's'
        
        // Verificació
        int respostesDespres = cd.getNumRespostes(titol); // 1
        printTestResult("4 - Contestar Enquesta", respostesAbans == 0 && respostesDespres == 1);
    }
    
    static public void pruebaCluster() {
        
        System.out.println("\n---  Proves de Cluster ---");
        System.out.println("Quin joc de proves vols executar?");
        System.out.println("1 - Test K=3, N=6 (Grups A, B, C)");
        System.out.println("2 - Test K=3, N=3 (Cada usuari un cluster)");
        System.out.println("3 - Test K=3, N=2 (Error: K > N)");
        System.out.println("4 - Test K=2, N=6 (Dos grups: baixos/alts)");
        System.out.println("5 - Test K=2, N=4 (Dos grups: 50/100)");
        System.out.println("0 - Tornar al menú principal");
        System.out.print("Opció: ");

        String op = sc.nextLine();

        String fileName = "";
        String admin = "adminClust";
        String titol = "enqCluster";
        int numUsers = 0;
        
        switch (op) {
            case "1": 
                fileName = "INPUT/test_input_cluster_1.txt";
                numUsers = 6;
                System.out.println("\nExecutant Test 5.1 (K=3, N=6)...");
                break;
            case "2":
                fileName = "INPUT/test_input_cluster_2.txt";
                numUsers = 3;
                System.out.println("\nExecutant Test 5.2 (K=3, N=3)...");
                break;
            case "3":
                fileName = "INPUT/test_input_cluster_3.txt";
                numUsers = 2;
                System.out.println("\nExecutant Test 5.3 (K=3, N=2)...");
                System.out.println("... S'ESPERA UN ERROR 'InvalidClusterException' ...");
                break;
            case "4":
                fileName = "INPUT/test_input_cluster_4.txt";
                numUsers = 6;
                System.out.println("\nExecutant Test 5.4 (K=2, N=6)...");
                break;
            case "5":
                fileName = "INPUT/test_input_cluster_5.txt";
                numUsers = 4;
                System.out.println("\nExecutant Test 5.5 (K=2, N=4)...");
                break;
            default:
                System.out.println("Tornant al menú principal...");
                return; 
        }

        try {
            setInput(fileName); 
        } catch (FileNotFoundException e) {
            System.err.println("No se encontró el archivo: " + fileName + " (" + e.getMessage() + ")");
            return; 
        }

        CtrlPresentacion cp = new CtrlPresentacion();
        CtrlDominio cd = cp.getCD();

        // Creem l'admin
        cd.crearUsuari(admin, "123");
        // Creem el nombre N d'usuaris necessaris per aquest test
        for (int i = 1; i <= numUsers; i++) {
            cd.crearUsuari("u" + i, "123");
        }

        // Creem l'enquesta (llegeix K del fitxer)
        cd.crearEnquestaBuida(titol, admin);
        try {
            cd.crearPreguntaLliure(titol, "P1", 20, true); // Numèrica
        } catch (InvalidPreguntaException e) {
            System.err.println("Error afegint pregunta: " + e.getMessage());
        }

        // Fem que N usuaris contestin (llegeix respostes del fitxer)
        for (int i = 1; i <= numUsers; i++) {
            cp.contestar("u" + i); 
        }
        
        // Mostrem resultats (llegeix el títol del fitxer)
        System.out.println("--- Inici de Prova Cluster ---");
        cp.veureResultats(admin); 
        System.out.println("--- Fi de Prova Cluster ---");
        System.out.println("Test 5 - Cluster: OK ");
    }
    

    static public void pruebaEliminarPregunta() {
        try {
            setInput("INPUT/test_input_eliminar_pregunta.txt");
        } catch (FileNotFoundException e) {
            System.err.println("No se encontró el archivo: " + e.getMessage());
            return;
        }
        CtrlPresentacion cp = new CtrlPresentacion();
        CtrlDominio cd = cp.getCD();
        String admin = "adminElim";
        cd.crearUsuari(admin, "123");
        String titol = "enqEliminar";

        // Setup (Input: "3")
        cd.crearEnquestaBuida(titol, admin);
        try {
            cd.crearPreguntaLliure(titol, "P1", 20, false);
            cd.crearPreguntaLliure(titol, "P2", 20, false);
        } catch (InvalidPreguntaException e) {  }

        int preguntesAbans = cd.getNumPreguntes(titol); 

        // Acció (Input: "enqEliminar", "P1")
        cp.eliminarPreguntes();

        // Verificació
        int preguntesDespres = cd.getNumPreguntes(titol); 
        printTestResult("6 - Eliminar Pregunta", preguntesAbans == 2 && preguntesDespres == 1);
    }

    static public void pruebaExportarEnquesta() {
        try {
            setInput("INPUT/test_input_exportar.txt");
        } catch (FileNotFoundException e) {
            System.err.println("No s'ha trobat l'arxiu: " + e.getMessage());
            return;
        }
        CtrlPresentacion cp = new CtrlPresentacion();
        CtrlDominio cd = cp.getCD();
        String admin = "adminExp";
        cd.crearUsuari(admin, "123");
        String titol = "enqExportar";
        String nomFitxer = "exportedSurvey";
        String path = "FONTS/CtrlPersistencia/Enquestes/" + nomFitxer + ".csv";
        
        // Neteja prèvia
        File f = new File(path);
        if (f.exists()) f.delete();

        // Setup (Input: "3")
        cd.crearEnquestaBuida(titol, admin);

        // Acció (Input: "enqExportar", "exportedSurvey", "n")
        cp.exportarEnquesta();

        // Verificació
        printTestResult("7 - Exportar Enquesta", f.exists());
        if (f.exists()) f.delete(); // Neteja
    }

    static public void pruebaAfegirPregunta() {
        try {
            setInput("INPUT/test_input_afegir_pregunta.txt");
        } catch (FileNotFoundException e) {
            System.err.println("No s'ha trobat l'arxiu: " + e.getMessage());
            return;
        }
        CtrlPresentacion cp = new CtrlPresentacion();
        CtrlDominio cd = cp.getCD();
        String admin = "adminAfeg";
        cd.crearUsuari(admin, "123");
        String titol = "enqAfegir";

        // Setup (Input: "3")
        cd.crearEnquestaBuida(titol, admin);
        
        int preguntesAbans = cd.getNumPreguntes(titol); 

        // Acció (Input: "enqAfegir", "ll", "P_Afegida", "n")
        cp.afegirPregunta();

        // Verificació
        int preguntesDespres = cd.getNumPreguntes(titol); // 1
        printTestResult("8 - Afegir Pregunta", preguntesAbans == 0 && preguntesDespres == 1);
    }

    static public void pruebaEliminarEnquesta() {
        try {
            setInput("INPUT/test_input_eliminar_enquesta.txt");
        } catch (FileNotFoundException e) {
            System.err.println("No s'ha trobat l'arxiu: " + e.getMessage());
            return;
        }
        CtrlPresentacion cp = new CtrlPresentacion();
        CtrlDominio cd = cp.getCD();
        String admin = "adminElimEnq";
        cd.crearUsuari(admin, "123");
        String titol = "enqPerEliminar";

        // Setup (Input: "3")
        cd.crearEnquestaBuida(titol, admin);

        boolean existeixAbans = cd.existeEnquesta(titol); // true

        // Acció (Input: "enqPerEliminar")
        cp.eliminarEnquesta(admin);

        // Verificació
        boolean existeixDespres = cd.existeEnquesta(titol); // false
        printTestResult("9 - Eliminar Enquesta", existeixAbans && !existeixDespres);
    }
}