#!/bin/bash

# elimina carpeta anterior i crea una nova per guardar els .class (em els seus packages)
rm -rf CLASSES
mkdir CLASSES

# amb -d guardem els .class generats a la carpeta CLASSES, i crea carpeta FONTS pel package FONTS
javac -d CLASSES FONTS/*.java 

# el mateix amb els .java de EXE, agafa les llibreries de Junit4 i els .class dels .java del domini
javac -cp "LIBS/*:CLASSES" -d CLASSES EXE/*/*.java

# test interactiu
javac -cp "LIBS/*:CLASSES" -d CLASSES TESTS/*.java
