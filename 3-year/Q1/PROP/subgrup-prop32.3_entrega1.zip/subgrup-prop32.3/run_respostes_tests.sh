#!/bin/bash

java -cp "LIBS/*:CLASSES" org.junit.runner.JUnitCore EXE.driverResposta.driverRespostaMultichoice

java -cp "LIBS/*:CLASSES" org.junit.runner.JUnitCore EXE.driverResposta.driverRespostaText

java -cp "LIBS/*:CLASSES" org.junit.runner.JUnitCore EXE.driverResposta.driverRespostaNum
