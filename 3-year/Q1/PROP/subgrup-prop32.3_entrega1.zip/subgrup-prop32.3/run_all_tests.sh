#!/bin/bash
# executa tots els drivers que estan a partir de exe
java -cp "LIBS/*:CLASSES" org.junit.runner.JUnitCore EXE.driversEnquesta.driverTotesFuncionsEnquesta

java -cp "LIBS/*:CLASSES" org.junit.runner.JUnitCore EXE.driverResposta.driverRespostaMultichoice

java -cp "LIBS/*:CLASSES" org.junit.runner.JUnitCore EXE.driverResposta.driverRespostaText

java -cp "LIBS/*:CLASSES" org.junit.runner.JUnitCore EXE.driverResposta.driverRespostaNum

java -cp "LIBS/*:CLASSES" org.junit.runner.JUnitCore EXE.driverPregunta.driverPreguntaMultichoice

java -cp "LIBS/*:CLASSES" org.junit.runner.JUnitCore EXE.driverPregunta.driverPreguntaLliure

java -cp "LIBS/*:CLASSES" org.junit.runner.JUnitCore EXE.driversUsuari.driverUsuari

java -cp "LIBS/*:CLASSES" org.junit.runner.JUnitCore EXE.driversAnalisiCluster.driverAnalisiCluster

java -cp "LIBS/*:CLASSES" TESTS.TestApp


#caldrà posar una linia nova canviant nomes EXE. ... . ...
